import "./src/version.js";
import { checkAndInstallModules, clearDirectory } from "./src/lib/utils.js";

console.log(`[✔] Starting Engine: LaraBot`);

// ─── Cek versi Node ───────────────────────────────
const [major] = process.versions.node.split(".").map(Number);

if (major !== 20) {
  console.error(`❌ Gagal Menjalankan Engine, Node Not Supported`);
  console.error(`📌 Use Node Engine: v20 (current: v${major})`);
  console.error(`⏳ Exiting in 60 seconds...`);
  
  setTimeout(() => process.exit(1), 60_000);
} else {
  process.env.TZ = "Asia/Jakarta"; // Timezone utama

  try {
    const config = (await import("./config.js")).default;
    const BOT_NUMBER = config.phone_number_bot || "";
    
    if (BOT_NUMBER) {
      console.log(`[✔] Bot Number: ${BOT_NUMBER}`);
    }

    // ─── Bersihkan temporary folder ─────────────────
    console.log("[CLEANUP] Clearing temporary directory...");
    await clearDirectory("./storage/tmp");
    console.log('[✔] Temporary directory cleaned');

    // ─── Schedule auto cleanup setiap 15 menit ──────
    const cleanupInterval = setInterval(async () => {
      console.log("[SCHEDULE] Auto cleanup temporary files...");
      await clearDirectory("./storage/tmp");
      console.log("[✔] Temporary directory cleaned");
    }, 5 * 60 * 1000);

    console.log('[✔] Successfully initialized');

    // ─── Check & Install Modules ────────────────────
    await checkAndInstallModules([
      "follow-redirects",
      "jimp@1.6.0",
      "qrcode-reader",
      "wa-sticker-formatter",
      "api-autoresbot@1.0.6",
    ]);

    // ─── Start App ──────────────────────────────────
    const { start_app } = await import("./src/lib/start.js");
    await start_app();

    // ─── Cleanup on exit ────────────────────────────
    const cleanup = () => {
      console.log("[SHUTDOWN] Cleaning up...");
      clearInterval(cleanupInterval);
    };

    process.on("exit", cleanup);
    process.on("SIGINT", () => {
      cleanup();
      process.exit(0);
    });
    process.on("SIGTERM", () => {
      cleanup();
      process.exit(0);
    });

  } catch (err) {
    console.error("❌ Error dalam proses start:", err.message);
    console.error("Stack:", err.stack);
    
    setTimeout(() => {
      console.error("⏳ Exiting due to fatal error...");
      process.exit(1);
    }, 3000);
  }

  // ─── Global Error Handler ─────────────────────────
  const handleFatalError = (type, error) => {
    console.error(`❌ ${type}:`, error);
    if (error.stack) console.error("Stack:", error.stack);
    
    setTimeout(() => {
      console.error("⏳ Exiting due to fatal error...");
      process.exit(1);
    }, 3000);
  };

  process.on("uncaughtException", (err) => handleFatalError("Uncaught Exception", err));
  process.on("unhandledRejection", (reason, promise) => {
    handleFatalError("Unhandled Rejection", reason);
  });
}