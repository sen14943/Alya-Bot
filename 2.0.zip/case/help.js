/**
 * HELP CARD SENDER
 * Kirim gambar allmenu.jpg + card style menucat
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { style } from '../src/lib/utils.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load gambar allmenu.jpg
const MENU_IMAGE_PATH = '../assets/media/allmenu.jpg';
let menuImageBuffer = null;
try {
  menuImageBuffer = fs.readFileSync(path.join(__dirname, MENU_IMAGE_PATH));
} catch (err) {
  console.error('❌ Gagal load allmenu.jpg:', err.message);
}

function formatHelpCard(command, needEmoji, needText_, example, description, notes, saldoText) {
  return `
┌───〔 *BANTUAN COMMAND* 〕
│
│  ✤ *Command* : ${command}
│  ✤ *Butuh* : ${needEmoji} ${needText_}
│  ✤ *Contoh* : ${example}
│
╰────────────────

> Selamat Mencoba!`;
}

async function sendHelpCard(sock, remoteJid, message, data) {
    const {
        prefix,
        command,
        needImage = false,
        needVideo = false,
        needText = false,
        example = "",
        description = "",
        notes = "Selamat Mencoba!",
        limits = ""  // ini adalah deduction dalam bentuk angka
    } = data;
    
    // Tentukan emoji & teks kebutuhan
    let needEmoji = "✨";
    let needText_ = "";
    
    if (needVideo) {
        needEmoji = "🎥";
        needText_ = "Video";
    } else if (needImage && needText) {
        needEmoji = "🖼️📝";
        needText_ = "Gambar + Teks";
    } else if (needImage) {
        needEmoji = "🖼️";
        needText_ = "Gambar";
    } else if (needText) {
        needEmoji = "📝";
        needText_ = "Teks";
    } else {
        needEmoji = "✨";
        needText_ = "-";
    }
    
    // Konversi deduction ke Rupiah (saldo)
    let saldoText = "";
    if (limits && !isNaN(limits)) {
        try {
            const saldo = await import('../src/lib/saldo.js');
            const deductionValue = parseInt(limits);
            const rupiahValue = saldo.default.limitToRupiah(deductionValue);
            saldoText = `Rp ${rupiahValue.toLocaleString('id-ID')}`;
        } catch (err) {
            saldoText = `${limits} (error konversi)`;
        }
    }
    
    const fullCommand = prefix + command;
    const fullExample = `${prefix + command} ${example}`;
    const card = formatHelpCard(fullCommand, needEmoji, needText_, fullExample, description, notes, saldoText);
    
    // Kirim GAMBAR dulu (kayak menu.js)
    if (menuImageBuffer) {
        await sock.sendMessage(remoteJid, {
            image: menuImageBuffer,
            caption: style(card)
        }, { quoted: message });
    } else {
        // Fallback kalau gambar gagal load
        await sock.sendMessage(remoteJid, {
            text: card
        }, { quoted: message });
    }
}

export { sendHelpCard };