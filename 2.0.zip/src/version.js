// jangan di ubah ubah kalau mau nerima update
global.version = "2.0";

import { updateVersionInStrings } from "./lib/utils.js"; // <-- path relatif
updateVersionInStrings();
