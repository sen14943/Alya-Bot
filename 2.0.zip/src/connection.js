import config from '../config.js';
import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} from 'baileys';
import EventEmitter from 'events';
import { Boom } from '@hapi/boom';
import qrcode from 'qrcode-terminal';
import pino from 'pino';

import { updateSocket } from './lib/scheduled.js';
import { sessions } from './lib/cache.js';
import serializeMessage from './lib/packdat.js';
import { updateJadibot, getJadibot } from './lib/jadibot.js';
import { processMessage, participantUpdate, initializeBot } from './main.js';
import {
  createBackup,
  getnumberbot,
  logWithTime,
  setupSessionDirectory,
  isQuotedMessage,
  removeSpace,
  restaring,
  success,
  danger,
  sleep,
  sendMessageWithMentionNotQuoted,
  validations,
  extractNumbers,
  deleteFolderRecursive,
  getSenderType,
} from './lib/utils.js';

const eventBus = new EventEmitter();
const store = { contacts: {} };

// Constants - DIKECILIN dan DISEDERHANAKAN
const CONSTANTS = {
  MAX_RECONNECT: 5,        // dari 10 jadi 5 (kayak kode lama)
  RECONNECT_DELAY: 5000,   // 5 detik (kayak kode lama)
  QR_MAX_DISPLAY: 5,
  PRESENCE_UPDATES: ['unavailable', 'available', 'composing', 'recording', 'paused'],
};

// HAPUS SessionStateManager - BIKIN BOROS RAM!
// Ganti dengan variable sederhana kayak kode lama
let reconnectAttempts = 0;
let reconnecting = false;
let qrCount = 0;

// Utility functions
const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));
const getTimestamp = () => `[${new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false })}]`;

const getLogFileName = () => {
  const now = new Date();
  const folder = path.join(process.cwd(), 'logs_panel');
  if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
  return path.join(folder, `${now.getFullYear()}-${(now.getMonth()+1).toString().padStart(2,'0')}-${now.getDate().toString().padStart(2,'0')}______${now.getHours().toString().padStart(2,'0')}-${now.getMinutes().toString().padStart(2,'0')}.log`);
};

const debugLog = async (msg) => {
  if (typeof msg !== 'object' || msg === null) return;
  try {
    await fs.promises.appendFile(await getLogFileName(), `${getTimestamp()} DEBUGGING\n${JSON.stringify(msg, null, 2)}\n----------------- || ------------------\n`);
  } catch (error) {
    console.error(`Gagal menulis log: ${error.message}`);
  }
};

// Validate config
const validateConfig = () => {
  for (const { key, validValues, validate, errorMessage } of validations) {
    const value = config[key]?.toLowerCase();
    if (validValues && !validValues.includes(value)) return danger('Error config.js', errorMessage);
    if (validate && !validate(config[key])) return danger('Error config.js', errorMessage);
  }
  return true;
};

// ================================
// FUNGSI DESTROY SESSION (WAJIB!)
// ================================
const destroySession = async (folder, sock) => {
  if (!sock) return;
  
  console.log(chalk.yellow(`[${folder}] Membersihkan session...`));
  
  // 1. Hapus SEMUA event listener (INI YANG PALING PENTING!)
  try {
    if (sock.ev) {
      sock.ev.removeAllListeners();
      // Paksa bersihkan internal events
      if (sock.ev._events) sock.ev._events = null;
      if (sock.ev._eventsCount) sock.ev._eventsCount = 0;
    }
  } catch (e) {}
  
  // 2. Tutup WebSocket dengan paksa
  try {
    if (sock.ws && sock.ws.readyState === 1) {
      sock.ws.terminate(); // terminate > close
    }
  } catch (e) {}
  
  // 3. Bersihkan internal timers Baileys
  try {
    if (sock.keepAliveInterval) clearInterval(sock.keepAliveInterval);
    if (sock.msgRetryInterval) clearInterval(sock.msgRetryInterval);
  } catch (e) {}
  
  // 4. Bersihkan store internal
  try {
    if (sock.store) {
      if (sock.store.chats) sock.store.chats.clear?.();
      if (sock.store.contacts) sock.store.contacts.clear?.();
      if (sock.store.messages) sock.store.messages.clear?.();
      sock.store = null;
    }
  } catch (e) {}
  
  // 5. Null-kan semua reference
  try {
    Object.keys(sock).forEach(key => {
      try { sock[key] = null; } catch(e) {}
    });
  } catch (e) {}
  
  console.log(chalk.green(`[${folder}] Session cleaned!`));
};

// ================================
// HAPUS SESSION JADIBOT (SEDERHANA)
// ================================
const autoDeleteJadibotSession = async (folder, reason = 'timeout') => {
  const sessionPath = path.join(process.cwd(), folder);
  const numbersString = extractNumbers(folder);
  
  const dataSession = await getJadibot(numbersString);
  
  // Jangan hapus jika pernah aktif
  if (dataSession?.status === 'active') {
    console.log(chalk.yellow(`[JADIBOT] ${folder} SKIP auto-delete (pernah aktif)`));
    return false;
  }
  
  console.log(chalk.red(`[JADIBOT] Menghapus session ${folder} - Alasan: ${reason}`));
  
  // Hapus folder session
  if (fs.existsSync(sessionPath)) {
    try {
      deleteFolderRecursive(sessionPath);
    } catch (err) {
      console.log(chalk.red(`[JADIBOT] Gagal hapus folder: ${err.message}`));
    }
  }
  
  // Update status ke database
  if (numbersString) {
    await updateJadibot(numbersString, 'stop');
  }
  
  // Hapus dari sessions Map
  sessions.delete(folder);
  
  return true;
};

// ================================
// MAIN CONNECTION FUNCTION (DIREVISI TOTAL)
// ================================
async function connectToWhatsApp(folder = 'session') {
  console.log(chalk.blue(`Menggunakan folder session: ${folder}`));
  
  const isJadibot = folder.includes('db/session_free');
  
  // Cek status untuk jadibot
  if (isJadibot) {
    const numbersString = extractNumbers(folder);
    if (numbersString) {
      const dataSession = await getJadibot(numbersString);
      if (dataSession?.status === 'stop' || dataSession?.status === 'logout') {
        console.log(chalk.yellow(`[JADIBOT] ${folder} status ${dataSession?.status}, skip start`));
        return false;
      }
    }
  }
  
  // Reset reconnect counter untuk session utama
  if (!isJadibot) {
    reconnectAttempts = 0;
    reconnecting = false;
    qrCount = 0;
  }
  
  // Validate config hanya untuk session utama
  if (folder === 'session' && !validateConfig()) return false;
  
  const numbersString = extractNumbers(folder);
  
  // Setup session directory
  const sessionDir = path.join(process.cwd(), folder);
  setupSessionDirectory(sessionDir);
  
  // Variable untuk jadibot QR
  let jadibotQrCount = 0;
  const MAX_JADIBOT_QR = 2;

  try {
    // Initialize socket
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestBaileysVersion();
    
    const sock = makeWASocket({
      version,
      logger: pino({ level: 'silent' }),
      printQRInTerminal: false,
      auth: state,
      browser: ['Ubuntu', 'Chrome', '20.0.04'],
      connectTimeoutMs: 30000,  // kecilin dari 60k
      keepAliveIntervalMs: 20000,
      defaultQueryTimeoutMs: 30000,
    });
    
    sessions.set(folder, sock);
    sock.ev.on('creds.update', saveCreds);
    
    // Handle pairing code
    if (!sock.authState.creds.registered && config.type_connection.toLowerCase() === 'pairing') {
      if (folder !== 'session') {
        logWithTime('Jadibot', `Koneksi "${folder}" tidak support pairing`, 'merah');
        return false;
      }
      const phoneNumber = config.phone_number_bot;
      if (!phoneNumber) {
        logWithTime('System', `Nomor telepon tidak ditemukan`, 'merah');
        return false;
      }
      
      await delay(4000);
      const code = await sock.requestPairingCode(phoneNumber.trim());
      const formattedCode = code.slice(0, 4) + '-' + code.slice(4);
      
      console.log(chalk.blue('PHONE NUMBER: '), chalk.yellow(phoneNumber));
      console.log(chalk.blue('CODE PAIRING: '), chalk.yellow(formattedCode));
    }
    
    // Event: contacts.update
    sock.ev.on('contacts.update', (contacts) => {
      contacts.forEach(contact => store.contacts[contact.id] = contact);
      eventBus.emit('contactsUpdated', store.contacts);
    });
    
    // Event: messages.upsert
    sock.ev.on('messages.upsert', async (m) => {
      try {
        const result = serializeMessage(m, sock);
        if (!result) return;
        
        const { message, remoteJid } = result;
        
        if (config.autoread) await sock.readMessages([message.key]);
        if (CONSTANTS.PRESENCE_UPDATES.includes(config?.PresenceUpdate)) {
          await sock.sendPresenceUpdate(config.PresenceUpdate, remoteJid);
        }
        
        await processMessage(sock, result);
      } catch (error) {
        console.log(chalk.redBright(`Error message upsert: ${error.message}`));
      }
    });
    
    // Event: group-participants.update
    sock.ev.on('group-participants.update', async (m) => {
      if (!m?.id || !m?.participants || !m?.action) return;
      try {
        await participantUpdate(sock, { ...m, store });
      } catch (error) {
        console.log(chalk.redBright(`Error participant update: ${error.message}`));
      }
    });
    
    // Event: call
    sock.ev.on('call', async (calls) => {
      if (!config.anticall) return;
      
      for (let call of calls) {
        if (!call.isGroup && call.status === 'offer') {
          const callType = call.isVideo ? 'VIDEO' : 'SUARA';
          const userTag = `@${call.from.split('@')[0]}`;
          const statusJid = getSenderType(call.from);
          const messageText = `⚠️ _BOT TIDAK DAPAT MENERIMA PANGGILAN ${callType}._\n\n_MAAF ${userTag}, KAMU AKAN DI *BLOCK*._\n_Silakan Hubungi Owner Untuk Membuat Block!_\n_Website: larabot.com/contact_`;
          
          logWithTime('System', `Call from ${call.from}`);
          await sendMessageWithMentionNotQuoted(sock, call.from, messageText, statusJid);
          await sleep(2000);
          await sock.updateBlockStatus(call.from, 'block');
        }
      }
    });
    
    // Event: connection.update (DIREVISI TOTAL - PAKE LOGIC KODE LAMA)
    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;
      
      // Update global phone number
      if (sock?.user?.id) global.phone_number_bot = getnumberbot(sock.user.id);
      
      // ========== QR CODE ==========
      if (qr && config.type_connection.toLowerCase() === 'qr') {
        if (isJadibot) {
          jadibotQrCount++;
          logWithTime('System', `[JADIBOT] ${folder} QR #${jadibotQrCount}`);
          qrcode.generate(qr, { small: true }, (qrcodeStr) => {
            console.log(chalk.green(`[JADIBOT ${folder}] QR #${jadibotQrCount}`) + '\n' + qrcodeStr);
          });
          
          if (jadibotQrCount >= MAX_JADIBOT_QR) {
            console.log(chalk.red(`[JADIBOT] ${folder} QR timeout, menghapus...`));
            await autoDeleteJadibotSession(folder, `QR timeout`);
            return;
          }
        } else {
          qrCount++;
          logWithTime('System', `Menampilkan QR (${qrCount}/${CONSTANTS.QR_MAX_DISPLAY})`);
          qrcode.generate(qr, { small: true });
          
          if (qrCount >= CONSTANTS.QR_MAX_DISPLAY) {
            console.log('Terlalu banyak QR. Stop.');
            process.exit(0);
          }
        }
      }
      
      // ========== CONNECTION OPEN ==========
      if (connection === 'open') {
        // Reset counters
        reconnectAttempts = 0;
        reconnecting = false;
        qrCount = 0;
        global.statusConnected = global.statusConnected || {};
        global.statusConnected[folder] = true;
        
        // Update jadibot status
        if (isJadibot && numbersString) {
          await updateJadibot(numbersString, 'active');
          console.log(chalk.green(`[JADIBOT] ${numbersString} connected!`));
        }
        
        success(folder === 'session' ? 'System' : 'Jadibot', 'Koneksi Terhubung');
        
        // Initialize bot untuk session utama
        if (!isJadibot) {
          initializeBot(sock);
        }
        
        // Handle restart message
        const isRestart = await restaring();
        if (isRestart && !isJadibot) {
          await delay(5000);
          if (sock?.ws?.readyState === 1 && sock?.user) {
            try { await sock.sendMessage(isRestart, { text: '_Bot Berhasil di restart_' }); } catch {}
          }
        } else if (folder === 'session') {
          setTimeout(async () => {
            if (sock?.ws?.readyState === 1) {
              try { await sock.sendMessage(`${config.phone_number_bot}@s.whatsapp.net`, { text: '_LaraBot Connected_' }); } catch {}
            }
          }, 5000);
        }
        
        // Scheduled updates
        if (!isJadibot) {
          try { await updateSocket(sock); } catch (error) {
            console.log(chalk.redBright(`Error updateSocket: ${error.message}`));
          }
        }
        
        // Auto backup
        if (config.autobackup && folder === 'session') {
          try {
            const backupFilePath = await createBackup();
            await sock.sendMessage(`${config.owner_number[0]}@s.whatsapp.net`, {
              document: { url: backupFilePath.path },
              fileName: 'larabot.zip',
              mimetype: 'application/zip',
            });
            logWithTime('System', `Backup berhasil: ${backupFilePath.path}`);
          } catch (error) {
            console.error('Backup error:', error.message);
          }
        }
      }
      
      // ========== CONNECTION CLOSE (DIREVISI PAKE LOGIC KODE LAMA) ==========
      if (connection === 'close') {
        if (reconnecting) return;
        reconnecting = true;
        reconnectAttempts++;
        
        const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
        
        console.log(chalk.yellow(`Reconnect ${reconnectAttempts}/${CONSTANTS.MAX_RECONNECT} | Reason: ${reason}`));
        
        global.statusConnected = global.statusConnected || {};
        global.statusConnected[folder] = false;
        
        // Hapus dari sessions Map
        sessions.delete(folder);
        
        // Handle jadibot failed
        if (isJadibot && reconnectAttempts >= 2) {
          console.log(chalk.red(`[JADIBOT] ${folder} Gagal connect, menghapus...`));
          await autoDeleteJadibotSession(folder, `gagal connect`);
          reconnecting = false;
          return;
        }
        
        // Stop jika logged out atau max reconnect
        if (reason === DisconnectReason.loggedOut) {
          console.log(chalk.bgRed('Session Logged Out. Stop reconnect.'));
          reconnecting = false;
          return;
        }
        
        if (reconnectAttempts >= CONSTANTS.MAX_RECONNECT) {
          console.log(chalk.bgRed('Max reconnect reached. Stop.'));
          reconnecting = false;
          return;
        }
        
        // 🔥🔥🔥 INI YANG PALING PENTING - CLEANUP SEPERTI KODE LAMA 🔥🔥🔥
        try {
          if (sock.ev) {
            sock.ev.removeAllListeners(); // HAPUS SEMUA LISTENER!
          }
          if (sock?.ws?.readyState === 1) {
            sock.ws.close();
          }
        } catch (e) {
          console.log('Cleanup error:', e.message);
        }
        
        // Delay sebelum reconnect
        let delayTime = CONSTANTS.RECONNECT_DELAY;
        if (reason === 403) delayTime = 30000;
        if (reason === 428) delayTime = 15000;
        
        console.log(chalk.yellow(`Reconnect in ${delayTime/1000}s...`));
        await delay(delayTime);
        
        reconnecting = false;
        
        // LANGSUNG PANGGIL, BUKAN SETTIMEOUT!
        return connectToWhatsApp(folder);
      }
    });
    
    return sock;
    
  } catch (error) {
    console.log(chalk.red(`[${folder}] Error saat connect: ${error.message}`));
    
    // Handle error untuk jadibot
    if (isJadibot) {
      await autoDeleteJadibotSession(folder, `error ${error.message}`);
    }
    
    return false;
  }
}

export { connectToWhatsApp };