import { findSewa, deleteSewa } from "../../lib/sewa.js";
import config from "../../../config.js";
import { selisihHari, danger, logTracking } from "../../lib/utils.js";
import { logCustom } from "../../lib/logger.js";
import { getGroupMetadata } from "../../lib/cache.js";
import mess from "../../../case/strings.js";

// ================================
// KONFIGURASI
// ================================
const notificationDays = 1; // Jumlah hari sebelum notifikasi dikirim

// ================================
// CACHE
// ================================
const notifiedGroups = new Set(); // Cache untuk grup yang sudah menerima notifikasi
const nonSewaGroups = new Set();

// ================================
// FUNGSI KELUAR GRUP DENGAN RETRY
// ================================
async function leaveGroupWithRetry(sock, remoteJid, maxRetries = 3) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      logTracking(`Sewa Handler - keluar dari grub ${remoteJid}`);
      await sock.groupLeave(remoteJid);
      console.log(`Berhasil keluar dari grup pada percobaan ke-${attempt}`);
      return;
    } catch (err) {
      console.error(`Gagal keluar dari grup (percobaan ke-${attempt}):`, err);
      
      if (attempt === maxRetries) {
        console.error(`Gagal setelah ${maxRetries} kali mencoba.`);
      } else {
        await new Promise((resolve) => setTimeout(resolve, 1000)); // jeda 1 detik sebelum mencoba lagi
      }
    }
  }
}

// ================================
// FUNGSI KIRIM NOTIFIKASI
// ================================
async function sendNotification(sock, remoteJid, message, participants, type, selisihHariSewa = null) {
  let warningMessage;
  
  if (type === 'warning') {
    warningMessage = mess.handler.sewa_notif?.replace("@date", selisihHariSewa);
  } else if (type === 'expired') {
    warningMessage = mess.handler.sewa_out?.replace("@ownernumber", config.owner_number[0]);
  }
  
  if (!warningMessage) return;
  
  logTracking(`Sewa Handler - Send notif ${type} ke ${remoteJid}`);
  await sock.sendMessage(
    remoteJid,
    { text: warningMessage, mentions: participants.map((p) => p.id) },
    { quoted: message }
  );
}

// ================================
// FUNGSI HAPUS SEWA DAN KELUAR GRUP
// ================================
async function handleExpiredSewa(sock, remoteJid, message, participants) {
  // Kirim notifikasi expired
  await sendNotification(sock, remoteJid, message, participants, 'expired');
  
  // Delete database sewa
  await deleteSewa(remoteJid);
  
  // Keluar dari grup
  try {
    await leaveGroupWithRetry(sock, remoteJid);
    danger("Sewa Habis", `Berhasil keluar Grub : ${remoteJid}`);
  } catch (error) {
    console.error(`Gagal keluar dari grup ${remoteJid}:`, error);
    danger("Sewa Habis", `Gagal keluar grup : ${remoteJid}`);
    logCustom("info", "Gagal keluar grup", `gagal-keluar-grub-sewa-${remoteJid}.txt`);
  }
}

// ================================
// PROSES UTAMA
// ================================
async function process(sock, messageInfo) {
  const { remoteJid, isGroup, message } = messageInfo;

  // Hanya proses untuk grup
  if (!isGroup) {
    return true;
  }

  const dataSewa = await findSewa(remoteJid);

  // CASE 1: GRUP TERDAFTAR SEWA
  if (dataSewa) {
    const now = Date.now();
    const notificationMs = notificationDays * 24 * 60 * 60 * 1000;
    const timeRemaining = dataSewa.expired - now;
    const selisihHariSewa = selisihHari(dataSewa.expired);
    
    const groupMetadata = await getGroupMetadata(sock, remoteJid);
    const participants = groupMetadata.participants;

    // Sub-case 1: Masa berlaku hampir habis (belum menerima notifikasi)
    if (timeRemaining <= notificationMs && timeRemaining > 0 && !notifiedGroups.has(remoteJid)) {
      await sendNotification(sock, remoteJid, message, participants, 'warning', selisihHariSewa);
      notifiedGroups.add(remoteJid);
      return false;
    }
    
    // Sub-case 2: Masa berlaku sudah habis
    if (timeRemaining <= 0) {
      await handleExpiredSewa(sock, remoteJid, message, participants);
      return false;
    }
  }
  
  // CASE 2: GRUP TIDAK TERDAFTAR SEWA
  else {
    // Log grup non-sewa satu kali saja
    if (!nonSewaGroups.has(remoteJid)) {
      logCustom("info", "GRUB INI BUKAN TERMASUK SEWABOT", `bukan-sewa-${remoteJid}.txt`);
      nonSewaGroups.add(remoteJid);
    }
    
    // Grup non-sewa tetap diizinkan (tidak ada penolakan akses)
  }
  
  return true;
}

// ================================
// EXPORT
// ================================
export default {
  name: "Sewa Handle",
  priority: 10,
  process,
};