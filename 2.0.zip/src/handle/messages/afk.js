import { findUser, updateUser } from "../../lib/users.js";
import { formatDuration, logTracking } from "../../lib/utils.js";
import { logCustom } from "../../lib/logger.js";

/**
 * Format pesan AFK dengan card simple
 */
function formatAfkMessage(username, durasi, alasan, isSelf = false) {
  const alasanText = alasan ? `📌 ${alasan}` : '📌 -';
  
  if (isSelf) {
    return `✨ *Welcome Back!*
╭─────────────────
│ 👤 ${username}
│ ⏱️ AFK: ${durasi}
│ ${alasanText}
╰─────────────────
💬 Kamu sudah aktif kembali.`;
  }
  
  return `⚠️ *Sedang AFK*
╭─────────────────
│ 👤 ${username}
│ ⏱️ ${durasi}
│ ${alasanText}
╰─────────────────
💡 Tunggu sebentar ya~`;
}

/**
 * Format pesan singkat untuk mention
 */
function formatMentionAfk(username, durasi, alasan) {
  const alasanPart = alasan ? ` (${alasan})` : '';
  return `⚠️ *${username}* sedang AFK ${durasi}${alasanPart}`;
}

/**
 * Hapus mode AFK user
 */
async function clearAfk(sender, pushName, sock, remoteJid, message) {
  const user = await findUser(sender);
  if (!user) return false;
  
  const [docId, userData] = user;
  
  if (userData?.status === 'afk' && userData?.afk) {
    const durasi = formatDuration(userData.afk.lastChat);
    const alasan = userData.afk.alasan;
    
    const welcomeMsg = formatAfkMessage(pushName, durasi, alasan, true);
    await sock.sendMessage(remoteJid, { text: welcomeMsg }, { quoted: message });
    
    await updateUser(sender, { status: 'aktif', afk: null });
    logTracking(`Afk cleared - ${sender}`);
    return true;
  }
  return false;
}

/**
 * Notifikasi ke user yang mention orang AFK
 */
async function notifyMentioned(sock, remoteJid, message, mentionedJid, sender) {
  for (const jid of mentionedJid) {
    if (jid === sender) continue;
    
    const user = await findUser(jid);
    if (!user) continue;
    
    const [docId, userData] = user;
    
    if (userData?.status === 'afk' && userData?.afk) {
      const durasi = formatDuration(userData.afk.lastChat);
      const alasan = userData.afk.alasan;
      const username = userData.username || jid.split('@')[0];
      
      const msg = formatMentionAfk(username, durasi, alasan);
      
      await sock.sendMessage(remoteJid, { text: msg }, { quoted: message });
      logTracking(`Afk mention - ${sender} mentioned ${jid}`);
      return;
    }
  }
}

async function process(sock, messageInfo) {
  const { remoteJid, message, sender, pushName, mentionedJid } = messageInfo;

  try {
    // 1. Cek mention ke user AFK
    if (mentionedJid?.length > 0) {
      await notifyMentioned(sock, remoteJid, message, mentionedJid, sender);
    }

    // 2. Cek pengirim sedang AFK
    await clearAfk(sender, pushName, sock, remoteJid, message);
    
  } catch (error) {
    console.error("Error in AFK process:", error);
    logCustom("info", error, `ERROR-AFK-HANDLE.txt`);
  }

  return true;
}

export default {
  name: "Afk",
  priority: 3,
  process,
};