import { incrementUserChatCount } from "../../lib/totalchat.js";
import { addChat } from "../../lib/chatManager.js";
import { downloadMedia } from "../../lib/utils.js";

// ============ KONFIGURASI ============
const CONFIG = {
  MIN_CHARACTER: 4,           // Minimal karakter pesan
  NO_URL: true,               // Tidak boleh mengandung URL
  NO_REPEATED_WORDS: true,    // Tidak boleh kata unik berulang (spam kata yang sama)
  EXCLUDED_TYPES: ["sticker", "image", "video", "audio", "document"] // Tipe pesan yang dikecualikan
};
// ====================================

// Fungsi untuk cek apakah pesan mengandung URL
function containsUrl(text) {
  const urlPattern = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/gi;
  return urlPattern.test(text);
}

// Fungsi untuk cek apakah pesan terdiri dari kata unik yang berulang
function hasRepeatedUniqueWords(text) {
  // Hanya proses jika ada teks
  if (!text) return false;
  
  // Ambil kata-kata unik (case insensitive)
  const words = text.toLowerCase().match(/[a-z0-9]+/gi) || [];
  const uniqueWords = [...new Set(words)];
  
  // Jika hanya 1 kata unik dan diulang terus (contoh: "haha haha haha" atau "a a a a")
  if (uniqueWords.length === 1 && words.length >= 3) {
    return true;
  }
  
  // Cek jika kata yang sama diulang lebih dari 3 kali berturut-turut
  let repeatCount = 1;
  for (let i = 1; i < words.length; i++) {
    if (words[i] === words[i-1]) {
      repeatCount++;
      if (repeatCount >= 4) return true; // Kata sama muncul 4x berturut-turut
    } else {
      repeatCount = 1;
    }
  }
  
  return false;
}

// Fungsi utama validasi pesan
function isValidMessage(text, type) {
  // 1. Cek tipe pesan (sticker, image, dll tidak dihitung)
  if (CONFIG.EXCLUDED_TYPES.includes(type)) {
    return false;
  }
  
  // Jika tidak ada teks, tidak dihitung
  if (!text || text.trim() === "") {
    return false;
  }
  
  const trimmedText = text.trim();
  
  // 2. Cek minimal karakter
  if (trimmedText.length < CONFIG.MIN_CHARACTER) {
    return false;
  }
  
  // 3. Cek mengandung URL
  if (CONFIG.NO_URL && containsUrl(trimmedText)) {
    return false;
  }
  
  // 4. Cek kata unik berulang (spam)
  if (CONFIG.NO_REPEATED_WORDS && hasRepeatedUniqueWords(trimmedText)) {
    return false;
  }
  
  return true;
}

async function process(sock, messageInfo) {
  const { remoteJid, message, id, sender, isGroup, fullText, type } =
    messageInfo;

  try {
    if (isGroup) {
      // Validasi pesan sebelum menambah counter
      const isValid = isValidMessage(fullText, type);
      
      if (isValid) {
        // Hanya tambah counter jika pesan memenuhi syarat
        await incrementUserChatCount(remoteJid, sender);
      }

      let newMessage;
      if (type === "sticker") {
        const mediaPath = `./tmp/${await downloadMedia(message)}`;
        newMessage = {
          id,
          text: mediaPath,
          type,
        };
      } else if (fullText) {
        // Jika fullText tersedia, gunakan sebagai teks
        newMessage = {
          id,
          text: fullText,
        };
      }

      // Jika newMessage diatur, tambahkan ke obrolan
      if (newMessage) {
        addChat(sender, newMessage);
      }
    }
  } catch (error) {
    console.error("Error dalam proses Chat:", error);
  }

  return true; // Lanjutkan ke plugin berikutnya
}

export default {
  name: "Chat",
  priority: 3,
  process,
};