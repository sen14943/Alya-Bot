import fs from "fs";
import path from "path";
import { findGroup } from "../lib/group.js";
import { containsBadword } from "../lib/badword.js";
import mess from "../../case/strings.js";
import spamDetection from "../lib/spamDetection.js";
import badwordDetection from "../lib/badwordDetection.js";
import config from "../../config.js";
import { updateUser, findUser } from "../lib/users.js";
import autoAi from "../lib/autoai.js";
import autoSimi from "../lib/autosimi.js";
import autoRusuh from "../lib/autorusuh.js";
import { getGroupMetadata, findParticipantLatest } from "../lib/cache.js";
import {
  logWithTime,
  isUrlInText,
  toText,
  sendMessageWithMention,
  sendMessageWithMentionNotQuoted,
  logTracking,
} from "../lib/utils.js";
import { findMessageById, editMessageById } from "../lib/chatManager.js";
import { sendImageAsSticker } from "../lib/exif.js";

const notifiedUsers = new Set();
const rateLimit_blacklist = {};
const notifiedBlacklistUsers = new Set();

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const botNumber = config.phone_number_bot;

// ==================== KONFIGURASI ANTILINKWA YANG DITINGKATKAN ====================
const ANTILINKWA_CONFIG = {
  whatsappDomains: [
    'chat.whatsapp.com',
    'whatsapp.com',
    'wa.me',
    'wa.whatsapp.com',
    'web.whatsapp.com',
    'api.whatsapp.com',
    'business.whatsapp.com',
    'pay.whatsapp.com',
    'status.whatsapp.com',
    'cdn.whatsapp.com',
    'mmg.whatsapp.com',
    'v.whatsapp.com',
    'pps.whatsapp.com',
    'g.whatsapp.com',
    'static.whatsapp.com'
  ],
  whatsappPatterns: [
    /chat\.whatsapp\.com\/[a-zA-Z0-9]+/i,
    /whatsapp\.com\/channel\/[a-zA-Z0-9]+/i,
    /wa\.me\/[0-9]+/i,
    /web\.whatsapp\.com\//i,
    /api\.whatsapp\.com\//i,
    /business\.whatsapp\.com\//i
  ]
};

// ==================== KONFIGURASI ANTI PROMOSI ====================
const ANTIPROMOSI_CONFIG = {
  // Pola harga (minimal 1 untuk deteksi dasar)
  pricePatterns: [
    /\b\d+[kK]\b/,           // 1k, 10k, 100k
    /\b\d+rb\b/,              // 1rb, 10rb
    /\b\d+\.?\d*[jtJt]\b/,    // 1jt, 1.5jt, 2jt
    /\b\d+miliar\b/,          // 1miliar, 2miliar
    /\b\d+terliliun\b/,       // 1terliliun
    /\b\d+\.?\d* juta\b/,     // 1.5 juta
    /\b\d+\.?\d* milyar\b/,   // 2.5 milyar
    /\b\d+\.?\d* triliun\b/,  // 1 triliun
    /\b\d+\.?\d* ribu\b/,     // 10.5 ribu
  ],
  
  // Kata promosi
  promoWords: [
    'daget', 'jual', 'beli', 'cod', 'promo', 'diskon', 'murah',
    'grosir', 'ecer', 'order', 'pesan', 'dm', 'open order', 'oo',
    'fast response', 'respon cepat', 'terlaris', 'best seller',
    'stok terbatas', 'pre order', 'po', 'jastip', 'titip', 'dropship'
  ],
  
  // Kata pengecualian (jika ada, abaikan deteksi)
  exceptionWords: [
    'info', 'berita', 'tutorial', 'gratis', 'download', 'share',
    'rekomendasi', 'tips', 'cara', 'belajar', 'pengumuman',
    'admin', 'moderator', 'bot', 'rules', 'peraturan'
  ],
  
  // Minimal panjang teks untuk diproses
  minTextLength: 15,
  
  // Minimal jumlah kata harga yang harus muncul
  minPriceMatches: 1,
  
  // Minimal jumlah kata promosi yang harus muncul
  minPromoMatches: 1,
};

function isWhatsAppLink(text) {
  if (!text || typeof text !== 'string') return false;
  const lowerText = text.toLowerCase();
  
  for (const domain of ANTILINKWA_CONFIG.whatsappDomains) {
    if (lowerText.includes(domain)) return true;
    if (lowerText.includes(`https://${domain}`)) return true;
    if (lowerText.includes(`http://${domain}`)) return true;
    if (lowerText.includes(`www.${domain}`)) return true;
  }
  
  for (const pattern of ANTILINKWA_CONFIG.whatsappPatterns) {
    if (pattern.test(lowerText)) return true;
  }
  
  const groupLinkPattern = /(https?:\/\/)?(www\.)?(chat\.whatsapp\.com|whatsapp\.com)\/(invite\/)?[a-zA-Z0-9]{16,}/i;
  if (groupLinkPattern.test(lowerText)) return true;
  
  return false;
}

function isWhatsAppChannel(text) {
  if (!text || typeof text !== 'string') return false;
  const lowerText = text.toLowerCase();
  const channelPattern = /whatsapp\.com\/channel\/[a-zA-Z0-9]+/i;
  return channelPattern.test(lowerText);
}

// ==================== FUNGSI ANTI PROMOSI ====================
function isPromotionalText(text) {
  if (!text || typeof text !== 'string') return false;
  const lowerText = text.toLowerCase();
  
  // Skip jika teks terlalu pendek
  if (lowerText.length < ANTIPROMOSI_CONFIG.minTextLength) return false;
  
  // Cek kata pengecualian (jika ada, langsung dianggap aman)
  for (const exception of ANTIPROMOSI_CONFIG.exceptionWords) {
    if (lowerText.includes(exception)) {
      return false;
    }
  }
  
  // Hitung pola harga yang cocok
  let priceMatchCount = 0;
  let priceMatches = [];
  for (const pattern of ANTIPROMOSI_CONFIG.pricePatterns) {
    const matches = lowerText.match(pattern);
    if (matches) {
      priceMatchCount += matches.length;
      priceMatches.push(...matches);
    }
  }
  
  // Hitung kata promosi yang cocok
  let promoMatchCount = 0;
  let promoMatches = [];
  for (const word of ANTIPROMOSI_CONFIG.promoWords) {
    // Cek sebagai kata utuh (bukan substring)
    const regex = new RegExp(`\\b${word.replace(/\s+/, '\\s+')}\\b`, 'i');
    if (regex.test(lowerText)) {
      promoMatchCount++;
      promoMatches.push(word);
    }
  }
  
  // Logika deteksi:
  // Kondisi 1: Ada harga minimal 1 DAN ada kata promosi minimal 1
  const hasPriceAndPromo = (priceMatchCount >= ANTIPROMOSI_CONFIG.minPriceMatches && 
                             promoMatchCount >= ANTIPROMOSI_CONFIG.minPromoMatches);
  
  // Kondisi 2: Ada minimal 2 indikasi harga (contoh: "10k dan 20k")
  const hasMultiplePrices = (priceMatchCount >= 2);
  
  // Kondisi 3: Ada minimal 2 kata promosi
  const hasMultiplePromos = (promoMatchCount >= 2);
  
  // Hasil deteksi
  const isPromo = hasPriceAndPromo || hasMultiplePrices || hasMultiplePromos;
  
  if (isPromo) {
    logWithTime("ANTIPROMOSI", `Price: ${priceMatchCount} (${priceMatches.join(', ')}) | Promo: ${promoMatchCount} (${promoMatches.join(', ')})`);
  }
  
  return isPromo;
}

async function process(sock, messageInfo) {
  const {
    m,
    id,
    sender,
    isBot,
    pushName,
    message,
    isGroup,
    prefix,
    command,
    fullText,
    type,
    isQuoted,
    isTagSw,
    isTagMeta,
    isForwarded,
    isTagComunity,
    mentionedJid,
    senderType,
  } = messageInfo;
  let { remoteJid } = messageInfo;

  const result = findParticipantLatest(sender);
  if (result && isTagSw) {
    remoteJid = result.groupId;
  }

  const messagesDefault = toText(message);
  if (isTagSw || isGroup) {
    // lanjut
  } else {
    return true;
  }

  const now = Date.now();

  try {
    const dataGroupSettings = await findGroup(remoteJid);
    if (!dataGroupSettings) {
      logWithTime("System", `Data grup tidak ditemukan atau fitur belum diaktifkan.`);
      return true;
    }

    const { fitur } = dataGroupSettings;

    const groupMetadata = await getGroupMetadata(sock, remoteJid);
    const participants = groupMetadata.participants;
    const isAdmin = participants.some(
      (p) => (p.phoneNumber === sender || p.id === sender) && p.admin
    );

    const deleteMessage = async () => {
      logTracking(`Menghapus pesan di grub (${command})`);
      await sock.sendMessage(remoteJid, {
        delete: { remoteJid, id, participant: sender },
      });
    };

    const kickParticipant = async () => {
      logTracking(`Kick peserta dari grub (${command})`);
      await sock.groupParticipantsUpdate(remoteJid, [sender], "remove");
    };

    const sendText = async (text, isquoted = false) => {
      logTracking(`Handler - mengirim pesan teks (${command})`);
      if (isquoted) {
        await sendMessageWithMentionNotQuoted(sock, remoteJid, text, senderType);
      } else {
        await sock.sendMessage(remoteJid, { text }, { quoted: message });
      }
    };

    async function handleAction(action, sender) {
      if (action === "block") {
        await updateUser(sender, { status: "block" });
      } else if (action === "kick") {
        await kickParticipant();
      } else if (action === "both") {
        await updateUser(sender, { status: "block" });
        await kickParticipant();
      } else {
        console.warn("Tindakan badword tidak valid:", action);
      }
    }

    const user = await findUser(sender);

    const isWhatsappLink = isWhatsAppLink(fullText);
    const isWhatsappSaluran = isWhatsAppChannel(fullText);

    // ==================== ANTI LINK WA YANG DITINGKATKAN ====================
    
    // AntiLinkWA V2 - Langsung hapus + kick (tanpa notifikasi)
    if (!isAdmin && fitur.antilinkwav2 && isWhatsappLink) {
      logWithTime("SYSTEM", `Deteksi fitur Anti-link WA V2: ${fullText}`);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    // AntiLinkChannel V2 - Langsung hapus + kick (tanpa notifikasi)
    if (!isAdmin && fitur.antilinkchv2 && isWhatsappSaluran) {
      logWithTime("SYSTEM", `Deteksi fitur Anti-link Channel V2`);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    // AntiLinkWA - Langsung hapus (tanpa notifikasi)
    if (!isAdmin && fitur.antilinkwa && isWhatsappLink) {
      logWithTime("SYSTEM", `Deteksi fitur AntiLinkWA: ${fullText}`);
      await deleteMessage();
      return false;
    }

    // AntiLinkChannel - Langsung hapus (tanpa notifikasi)
    if (!isAdmin && fitur.antilinkch && isWhatsappSaluran) {
      logWithTime("SYSTEM", `Deteksi fitur AntiLinkChannel`);
      await deleteMessage();
      return false;
    }

    // ==================== ANTI PROMOSI ====================
    if (!isAdmin && fitur.antipromosi) {
      const isPromo = isPromotionalText(fullText);
      
      if (isPromo) {
        logWithTime("ANTIPROMOSI", `Deteksi promosi dari @${sender.split("@")[0]}: ${fullText.substring(0, 100)}`);
        
        // Hapus pesan
        await deleteMessage();
        
        // Kirim peringatan
        const warningMessage = `⚠️ @${sender.split("@")[0]} _Dilarang melakukan promosi/jualan di grup ini!_`;
        await sendText(warningMessage, true);
        
        return false;
      }
    }

    // ==================== KODE ASLI LAINNYA (TIDAK BERUBAH) ====================
    
    const ALLOWED_DOMAINS = [
      'youtube.com', 'youtu.be',
      'instagram.com', 'ig.me',
      'tiktok.com', 'tiktok.io',
      'whatsapp.com', 'wa.me', 'chat.whatsapp.com',
      'facebook.com', 'fb.com',
      'twitter.com', 'x.com',
      'google.com', 'gmail.com',
      'drive.google.com'
    ];
    
    const DANGEROUS_KEYWORDS = ['gacor', 'slot', 'judi', 'bet', 'casino', 'scam'];
    
    function hasNumbersInDomain(domain) {
      return /\d/.test(domain.split('.')[0]);
    }
    
    function isSafeDomain(domain) {
      domain = domain.toLowerCase();
      if (ALLOWED_DOMAINS.some(allowed => domain.includes(allowed))) {
        return true;
      }
      if (hasNumbersInDomain(domain)) {
        return false;
      }
      if (DANGEROUS_KEYWORDS.some(keyword => domain.includes(keyword))) {
        return false;
      }
      return false;
    }
    
    // Anti-link V2
    if (!isAdmin && fitur.antilinkv2 && /https?:\/\/[^\s]+/.test(fullText || '')) {
      const urls = fullText.match(/(https?:\/\/[^\s]+)/gi) || [];
      let shouldBlock = false;
      let dangerousDomain = '';
      
      for (const url of urls) {
        try {
          const domain = new URL(url).hostname.replace('www.', '');
          if (!isSafeDomain(domain)) {
            shouldBlock = true;
            dangerousDomain = domain;
            break;
          }
        } catch (e) {
          shouldBlock = true;
          break;
        }
      }
      
      if (shouldBlock) {
        logWithTime("SYSTEM", `Deteksi fitur Anti-link V2: ${dangerousDomain}`);
        await deleteMessage();
        try {
          await sock.groupParticipantsUpdate(remoteJid, [sender], "remove");
          logWithTime("SYSTEM", `User dikick: ${sender.split('@')[0]}`);
        } catch (error) {
          console.log('Gagal kick:', error.message);
        }
        return false;
      }
    }

    if (!isAdmin && fitur.antilink && isUrlInText(fullText)) {
      logWithTime("SYSTEM", `Deteksi fitur antilink`);
      await deleteMessage();
      return false;
    }

    if (!isAdmin && fitur.antihidetag2 && mentionedJid.length > 0) {
      logWithTime("SYSTEM", `Deteksi fitur antihidetagv2`);
      const hidden = !mentionedJid.some((jid) => {
        const number = jid.split("@")[0];
        return fullText.includes(number);
      });
      if (hidden) {
        await deleteMessage();
        await kickParticipant();
        return false;
      }
    }

    if (!isAdmin && fitur.antihidetag && mentionedJid.length > 0) {
      logWithTime("SYSTEM", `Deteksi fitur antihidetag`);
      const hidden = !mentionedJid.some((jid) => {
        const number = jid.split("@")[0];
        return fullText.includes(number);
      });
      if (hidden) {
        await deleteMessage();
        return false;
      }
    }

    if (fitur.detectblacklist2 && user) {
      logWithTime("SYSTEM", `Deteksi fitur Detect Blacklist`);
      if (user) {
        const [docId, userData] = user;
        const status = userData.status;
        if (status === "blacklist") {
          await kickParticipant();
        }
      }
    }

    if (fitur.detectblacklist && user) {
      logWithTime("SYSTEM", `Deteksi fitur Detect Blacklist`);
      if (user) {
        const [docId, userData] = user;
        const status = userData.status;
        const userId = sender.split("@")[0];
        if (status === "blacklist") {
          if (!notifiedBlacklistUsers.has(userId)) {
            const warningMessage = `⚠️ _Peringatan Blacklist_ \n\n@${userId} Telah di blacklist`;
            await sendText(warningMessage, true);
            logWithTime(pushName, `User sedang di blacklist`);
            notifiedBlacklistUsers.add(userId);
          } else {
            logWithTime(pushName, `User blacklist sudah diberi notifikasi sebelumnya`);
          }
          return false;
        }
      }
    }

    if (fitur.detectblacklist && fitur.detectblacklist2) {
      if (user) {
        const [docId, userData] = user;
        const status = userData.status;
        if (status === "blacklist") {
          return false;
        }
      }
    }

    // DEFAULT BADWORDS DAN FUNGSI BADWORD
    const DEFAULT_BADWORDS = [
      "anjing", "bangsat", "bajingan", "kontol", "memek", "jembut", 
      "ngentot", "pentil", "perek", "bego", "goblok", "idiot",
      "asu", "kampret", "jancok", "cukimai", "pantek", "babi", "monyet", 
      "tolol", "dungu", "bedebah", "brengsek", "keparat", "lonte", 
      "pelacur", "bajing", "anjir", "anjg", "bgsd", "bgst", "kntl", 
      "mmk", "jmbt", "ngentd", "asw", "kmprt", "jncok", "jing"
    ];
    
    function calculateSimilarity(str1, str2) {
      const track = Array(str2.length + 1).fill(null).map(() => Array(str1.length + 1).fill(null));
      for (let i = 0; i <= str1.length; i += 1) track[0][i] = i;
      for (let j = 0; j <= str2.length; j += 1) track[j][0] = j;
      for (let j = 1; j <= str2.length; j += 1) {
        for (let i = 1; i <= str1.length; i += 1) {
          const indicator = str1[i - 1] === str2[j - 1] ? 0 : 1;
          track[j][i] = Math.min(track[j][i - 1] + 1, track[j - 1][i] + 1, track[j - 1][i - 1] + indicator);
        }
      }
      const distance = track[str2.length][str1.length];
      const maxLength = Math.max(str1.length, str2.length);
      return ((maxLength - distance) / maxLength) * 100;
    }
    
    async function containsBadwordSimilar(text, customWords = []) {
      try {
        const allBadwords = [...DEFAULT_BADWORDS, ...customWords];
        const words = text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(word => word.length > 2);
        const detectedWords = [];
        for (const word of words) {
          for (const badword of allBadwords) {
            if (word === badword) {
              detectedWords.push(word);
              break;
            }
            if (word.length >= 3 && badword.length >= 3) {
              const similarity = calculateSimilarity(word, badword);
              if (similarity >= 90) {
                detectedWords.push(`${word} (mirip: ${badword})`);
                break;
              }
              if (badword.length >= 4 && word.includes(badword)) {
                detectedWords.push(`${word} (mengandung: ${badword})`);
                break;
              }
            }
          }
        }
        return { status: detectedWords.length > 0, words: detectedWords.join(', '), count: detectedWords.length };
      } catch (error) {
        console.error("Error in badword detection:", error);
        return { status: false, words: '', count: 0 };
      }
    }
    
    async function containsBadword(context, text, useSimilarity = true) {
      try {
        let customBadwords = [];
        if (useSimilarity) {
          return await containsBadwordSimilar(text, customBadwords);
        }
        const allBadwords = [...DEFAULT_BADWORDS, ...customBadwords];
        const textLower = text.toLowerCase();
        const detectedWords = [];
        for (const badword of allBadwords) {
          if (textLower.includes(badword.toLowerCase())) {
            detectedWords.push(badword);
          }
        }
        return { status: detectedWords.length > 0, words: detectedWords.join(', '), count: detectedWords.length };
      } catch (error) {
        console.error("Error in containsBadword:", error);
        return { status: false, words: '', count: 0 };
      }
    }
    
    if (!isAdmin && fitur.badword && command !== "delbadword") {
      const hasBadwordGroup = await containsBadword(remoteJid, fullText, true);
      const hasBadwordGlobal = await containsBadword("global-badword", fullText, true);
      if (hasBadwordGroup.status || hasBadwordGlobal.status) {
        const detectWords = hasBadwordGroup.words || hasBadwordGlobal.words;
        const detectCount = hasBadwordGroup.count || hasBadwordGlobal.count;
        logWithTime("SYSTEM", `Deteksi fitur badword - ${detectCount} kata terdeteksi`);
        await deleteMessage();
        const result = badwordDetection(sender);
        if (result.status === "warning") {
          if (mess.handler.badword_warning) {
            let warningMessage = mess.handler.badword_warning
              .replace("@sender", `@${sender.split("@")[0]}`)
              .replace("@warning", result.totalWarnings)
              .replace("@detectword", detectWords)
              .replace("@detectcount", detectCount)
              .replace("@totalwarning", config.BADWORD.warning);
            await sendText(warningMessage, true);
          }
          return false;
        }
        if (result.status === "blocked") {
          if (mess.handler.badword_block) {
            let warningMessage = mess.handler.badword_block
              .replace("@sender", `@${sender.split("@")[0]}`)
              .replace("@warning", result.totalWarnings)
              .replace("@detectword", detectWords)
              .replace("@detectcount", detectCount)
              .replace("@totalwarning", config.BADWORD.warning);
            await sendText(warningMessage, true);
          }
          const badwordAction = config.BADWORD.action.toLowerCase().trim();
          try {
            if (user) {
              await handleAction(badwordAction, sender);
            }
          } catch (error) {
            console.error("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");
            await sendText("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");
          }
        }
        return false;
      }
    }

    if (!isAdmin && fitur.badwordv2 && command !== "delbadword") {
      const hasBadwordGroup = await containsBadword(remoteJid, fullText);
      const hasBadwordGlobal = await containsBadword("global-badword", fullText);
      if (hasBadwordGroup.status || hasBadwordGlobal.status) {
        logWithTime("SYSTEM", `Deteksi fitur badwordv2`);
        await deleteMessage();
        const detectWords = hasBadwordGroup.words || hasBadwordGlobal.words;
        const result = badwordDetection(sender);
        if (mess.handler.badword_block) {
          let warningMessage = mess.handler.badword_block
            .replace("@sender", `@${sender.split("@")[0]}`)
            .replace("@warning", result.totalWarnings)
            .replace("@detectword", detectWords)
            .replace("@totalwarning", config.BADWORD.warning);
          await sendText(warningMessage, true);
        }
        const badwordAction = config.BADWORD.action.toLowerCase().trim();
        try {
          if (user) {
            await handleAction(badwordAction, sender);
          }
        } catch (error) {
          console.error("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");
          await sendText("❗ _Terjadi kesalahan, tindakan badword gagal. Pastikan Bot Adalah admin_");
        }
        return false;
      }
    }

    if (!isAdmin && fitur.badwordv3 && command !== "delbadword") {
      const hasBadwordGroup = await containsBadword(remoteJid, fullText);
      const hasBadwordGlobal = await containsBadword("global-badword", fullText);
      if (hasBadwordGroup.status || hasBadwordGlobal.status) {
        logWithTime("SYSTEM", `Deteksi fitur badwordv3`);
        await deleteMessage();
        const detectWords = hasBadwordGroup.words || hasBadwordGlobal.words;
        const result = badwordDetection(sender);
        if (result.status === "warning") {
          if (mess.handler.badword_warning) {
            let warningMessage = mess.handler.badword_warning
              .replace("@sender", `@${sender.split("@")[0]}`)
              .replace("@warning", result.totalWarnings)
              .replace("@detectword", detectWords)
              .replace("@totalwarning", config.BADWORD.warning);
            await sendText(warningMessage, true);
          }
          return false;
        }
        if (result.status === "blocked") {
          if (mess.handler.badword_block) {
            let warningMessage = mess.handler.badword_block
              .replace("@sender", `@${sender.split("@")[0]}`)
              .replace("@warning", result.totalWarnings)
              .replace("@detectword", detectWords)
              .replace("@totalwarning", config.BADWORD.warning);
            await sendText(warningMessage, true);
            await kickParticipant();
          }
        }
      }
    }

    if (fitur.antigame && command) {
      const Games = ["bj", "blackjack", "caklontong", "kodam", "cekkodam", "snakes", "dare", "family100", "kuismath", "math", "suit", "tebakangka", "tebakbendera", "tebakbom", "tebakgambar", "tebakhewan", "tebakkalimat", "tebakkata", "tebaklagu", "tebak", "tebaklirik", "tictactoe", "truth", "ttc", "ttt"];
      if (Games.some((game) => command.includes(game))) {
        const notifKey = `antigame-${remoteJid}-${sender}`;
        if (!notifiedUsers.has(notifKey)) {
          notifiedUsers.add(notifKey);
          await sendText(mess.game.isStop);
        }
        return false;
      }
    }

    const antiFeatures = {
      image: fitur.antifoto,
      video: fitur.antivideo,
      audio: fitur.antiaudio,
      document: fitur.antidocument,
      contact: fitur.anticontact,
      sticker: fitur.antisticker,
      poll: fitur.antipolling,
    };

    if (!isAdmin && antiFeatures[type]) {
      logWithTime("SYSTEM", `Deteksi fitur - ${type}`);
      await deleteMessage();
      return false;
    }

    if (fitur.antiedit && m.isEdited.status) {
      const fullText = m.isEdited.text;
      const idChatEdited = m.isEdited.id;
      if (idChatEdited) {
        const oldMessage = findMessageById(sender, idChatEdited);
        if (oldMessage) {
          if (mess.handler.antiedit) {
            let warningMessage = mess.handler.antiedit.replace("@oldMessage", `${oldMessage.text || ""}`);
            await sendText(warningMessage, true);
          }
          if (fullText) {
            editMessageById(sender, idChatEdited, fullText);
            return false;
          }
        }
      }
    }

    if (fitur.antidelete && m.isDeleted) {
      const idChatDeleted = m.message.message?.protocolMessage?.key?.id;
      if (idChatDeleted) {
        const oldMessage = findMessageById(sender, idChatDeleted);
        if (oldMessage) {
          if (oldMessage.type && oldMessage.type == "sticker") {
            try {
              const outputPath = path.resolve("./", oldMessage.text);
              const stickerBuffer = fs.readFileSync(outputPath);
              const options = { packname: config.sticker_packname, author: config.sticker_author };
              await sendImageAsSticker(sock, remoteJid, stickerBuffer, options, message);
              if (mess.handler.antidelete) {
                let warningMessage = mess.handler.antidelete.replace("@sender", `@${sender.split("@")[0]}`).replace("@text", "sticker");
                await sendText(warningMessage, true);
              }
            } catch (error) {
              console.error("Error:", error);
            }
            return;
          }
          if (mess.handler.antidelete) {
            let warningMessage = mess.handler.antidelete.replace("@sender", `@${sender.split("@")[0]}`).replace("@text", `${oldMessage.text || ""}`);
            await sendText(warningMessage, true);
          }
        }
      }
    }

    if (!isAdmin && typeof fitur.antispamchat === "boolean" && fitur.antispamchat) {
      const result = spamDetection(sender);
      if (result.status === "warning") {
        if (mess.handler.antispamchat) {
          let warningMessage = mess.handler.antispamchat.replace("@sender", `@${sender.split("@")[0]}`).replace("@warning", result.totalWarnings).replace("@totalwarning", config.SPAM.warning);
          try {
            await sendText(warningMessage, true);
          } catch (err) {
            console.error("Gagal kirim pesan warning:", err);
          }
        }
        return false;
      }
      if (result.status === "blocked") {
        if (mess.handler.antispamchat2) {
          let warningMessage = mess.handler.antispamchat2.replace("@sender", `@${sender.split("@")[0]}`);
          await sendText(warningMessage, true);
        }
        const spamAction = config.SPAM.action.toLowerCase().trim();
        try {
          if (user) {
            await handleAction(spamAction, sender);
          }
        } catch (error) {
          console.error("Terjadi kesalahan saat memproses tindakan spam:", error);
          await sendText("❗ _Terjadi kesalahan, tindakan spam gagal._");
        }
        return false;
      }
    }

    if (!isAdmin && fitur?.antivirtex === true) {
      const isTextMessage = type !== "video" && type !== "image";
      const isTextTooLong = messagesDefault.length > 30000;
      if (isTextMessage && isTextTooLong) {
        if (mess.handler.antivirtex) {
          let warningMessage = mess.handler.antivirtex.replace("@sender", `@${sender.split("@")[0]}`);
          await sendText(warningMessage, true);
        }
        await deleteMessage();
        return false;
      }
    }

    if (fitur?.autoai && command !== "on" && command !== "off" && !prefix) {
      const containsAI = fullText.toLowerCase().trim().includes("ai");
      const isQuotedMessageFromBot = (() => {
        if (!isQuoted?.sender) return false;
        const senderNumber = isQuoted.sender.split("@")[0];
        return senderNumber === botNumber;
      })();
      const content_old = isQuotedMessageFromBot ? isQuoted.text || isQuoted.content || "" : undefined;
      if (type === "text" || type === "image" || containsAI) {
        await autoAi(sock, messageInfo, content_old);
        return false;
      }
    }

    if (fitur?.autosimi && command !== "on" && command !== "off") {
      const containsSimi = fullText.toLowerCase().trim().includes("simi");
      const isQuotedMessageFromBot = (() => {
        if (!isQuoted?.sender) return false;
        const senderNumber = isQuoted.sender.split("@")[0];
        return senderNumber === botNumber;
      })();
      const content_old = isQuotedMessageFromBot ? isQuoted.text || isQuoted.content || "" : undefined;
      if (type === "text" || containsSimi) {
        await autoSimi(sock, messageInfo, content_old);
        return false;
      }
    }

    if (fitur?.autorusuh && command !== "on" && command !== "off") {
      const isQuotedMessageFromBot = (() => {
        if (!isQuoted?.sender) return false;
        const senderNumber = isQuoted.sender.split("@")[0];
        return senderNumber === botNumber;
      })();
      await autoRusuh(sock, messageInfo, isQuotedMessageFromBot);
      return false;
    }

    if (!isAdmin && fitur?.antibot && isBot && isGroup) {
      if (mess.handler.antibot) {
        let warningMessage = mess.handler.antibot.replace("@sender", `@${sender.split("@")[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (fitur?.onlyadmin) {
      if (command === "debug") {
        console.log(`Status Only Admin: ${fitur.onlyadmin ? "Aktif" : "Nonaktif"}`);
        return false;
      }
      if (!isAdmin) return false;
    }

    // ANTI GROUP STATUS UPDATE
    if (!isAdmin && fitur?.antigrupstatusupdate) {
      const isGroupStatusUpdate = (() => {
        if (m.message?.groupStatusMessageV2) return true;
        if (m.message?.protocolMessage?.type === 25) return true;
        if (m.message?.protocolMessage?.editedMessage?.groupStatusMessageV2) return true;
        if (m.message?.messageContextInfo?.messageSecret && 
            m.message?.extendedTextMessage?.text === undefined &&
            !m.message?.imageMessage && 
            !m.message?.videoMessage &&
            !m.message?.conversation) return true;
        return false;
      })();
      
      if (isGroupStatusUpdate) {
        logWithTime("SYSTEM", `Deteksi fitur antigrupstatusupdate - Mengirim status grup dari @${sender.split("@")[0]}`);
        await sendText(`⚠️ @${sender.split("@")[0]} _Dilarang mengirim Status Grup/Story ke grup ini!_`, true);
        await deleteMessage();
        return false;
      }
    }

    if (!isAdmin && fitur?.antigrupstatusupdate2) {
      const isGroupStatusUpdate = (() => {
        if (m.message?.groupStatusMessageV2) return true;
        if (m.message?.protocolMessage?.type === 25) return true;
        if (m.message?.protocolMessage?.editedMessage?.groupStatusMessageV2) return true;
        return false;
      })();
      
      if (isGroupStatusUpdate) {
        logWithTime("SYSTEM", `Deteksi fitur antigrupstatusupdate2 - Menendang @${sender.split("@")[0]} karena mengirim status grup`);
        await sendText(`⚠️ @${sender.split("@")[0]} _Dilarang mengirim Status Grup! Anda akan dikeluarkan._`, true);
        await deleteMessage();
        await kickParticipant();
        return false;
      }
    }

    if (!isAdmin && fitur?.antigroupstatus) {
      const isGroupStatus = m.message?.protocolMessage?.type === 25 ||
                           (m.message?.protocolMessage?.editedMessage?.extendedTextMessage?.contextInfo?.groupMentions?.length > 0) ||
                           (m.message?.extendedTextMessage?.contextInfo?.groupMentions?.length > 0);
      if (isGroupStatus) {
        if (mess.handler.antigroupstatus) {
          let warningMessage = mess.handler.antigroupstatus.replace("@sender", `@${sender.split("@")[0]}`);
          await sendText(warningMessage, true);
        }
        await deleteMessage();
        return false;
      }
    }
    
    if (!isAdmin && fitur?.antitagsw && isTagSw) {
      if (mess.handler.antitagsw) {
        let warningMessage = mess.handler.antitagsw.replace("@sender", `@${sender.split("@")[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      return false;
    }
    
    if (!isAdmin && fitur?.antitagsw2 && isTagSw) {
      if (mess.handler.antitagsw) {
        let warningMessage = mess.handler.antitagsw.replace("@sender", `@${sender.split("@")[0]}`);
        await sendText(warningMessage, true);
      }
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (fitur?.antitagmeta && isGroup && isTagMeta) {
      let warningMessage = "⚠️ @sender _Terdeteksi Tag Meta Ai di grub ini_";
      warningMessage = warningMessage.replace("@sender", `@${sender.split("@")[0]}`);
      await sendText(warningMessage, true);
      await deleteMessage();
      return false;
    }

    if (fitur?.antitagmeta2 && isGroup && isTagMeta) {
      let warningMessage = "⚠️ @sender _Terdeteksi Tag Meta Ai di grub ini_";
      warningMessage = warningMessage.replace("@sender", `@${sender.split("@")[0]}`);
      await sendText(warningMessage, true);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (!isAdmin && fitur?.antiforward && isGroup && isForwarded) {
      let warningMessage = "⚠️ @sender _Terdeteksi Mengirim Pesan Terusan_";
      warningMessage = warningMessage.replace("@sender", `@${sender.split("@")[0]}`);
      await sendText(warningMessage, true);
      await deleteMessage();
      return false;
    }

    if (!isAdmin && fitur?.antiforward2 && isGroup && isForwarded) {
      let warningMessage = "⚠️ @sender _Terdeteksi Mengirim Pesan Terusan_";
      warningMessage = warningMessage.replace("@sender", `@${sender.split("@")[0]}`);
      await sendText(warningMessage, true);
      await deleteMessage();
      await kickParticipant();
      return false;
    }

    if (rateLimit_blacklist[sender] && now - rateLimit_blacklist[sender] < 5000) {
      return true;
    } else {
      rateLimit_blacklist[sender] = now;
    }
  } catch (error) {
    console.error("Terjadi kesalahan pada proses Handler.js:", error.message);
  }
  return true;
}

export default {
  name: "Mode On Handler :",
  priority: 2,
  process,
};