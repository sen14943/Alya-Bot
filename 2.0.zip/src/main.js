// ================================
// IMPORT MODULES
// ================================
import chokidar from "chokidar";
import config from "../config.js";
const mode = config.mode;

import { findGroup } from "./lib/group.js";
import chalk from "chalk";
import handler from "./lib/handler.js";
import mess from "../case/strings.js";
import { updateParticipant } from "./lib/cache.js";

import path from "path";
import { handleActiveFeatures } from "./lib/participant_update.js";

import {
  logWithTime,
  log,
  danger,
  findClosestCommand,
  logTracking,
} from "./lib/utils.js";

import {
  isOwner,
  isPremiumUser,
  updateUser,
  findUser,
} from "./lib/users.js";

import { reloadPlugins } from "./lib/plugins.js";
import { logCustom } from "./lib/logger.js";
import fs from "fs/promises";
import { existsSync } from "fs";

import { 
  extractURLs, 
  detectURLType, 
  isOnlyURLMessage,
} from "./lib/smartdl.js";

import { findSewa, getAllSewa } from "./lib/sewa.js";

// ✅ IMPORT SALDO (untuk konversi limit ke rupiah jika perlu)
import saldo from "./lib/saldo.js";

// ================================
// IMPORT FILE YANG SUDAH DIPISAH
// ================================
import { 
  commandWithoutRegister, 
  noQueueCommands, 
  antiSpamConfig,
  RATE_LIMIT,
  QUEUE,
  DISCOUNT_CONFIG,
  CLAIM,
  DB_PATHS,
  CLEANUP_INTERVALS,
  SEWA_RELOAD_INTERVAL,
  ONLY_RENTED_GROUPS 
} from "./main/main_config.js";

import { 
  findSimilarCommand, 
  getTypoNotification,
  checkHighSimilarity,
  checkLowSimilarity 
} from "./main/similar.js";

import { commandQueue, CommandQueue } from "./main/queue.js";

handler.initHandlers();

// ================================
// UTILITY FUNCTIONS
// ================================

const ensureDbDirectory = async () => {
  try {
    const dbDir = path.join(process.cwd(), "db");
    if (!existsSync(dbDir)) {
      await fs.mkdir(dbDir, { recursive: true });
    }
  } catch (e) {
    console.error("❌ Failed to create database directory:", e);
  }
};

const safeReadJSON = async (filePath) => {
  try {
    if (!existsSync(filePath)) return null;
    const data = await fs.readFile(filePath, "utf8");
    return JSON.parse(data);
  } catch (e) {
    console.error(`⚠️ Error reading ${filePath}:`, e.message);
    return null;
  }
};

const safeWriteJSON = async (filePath, data) => {
  try {
    await ensureDbDirectory();
    await fs.writeFile(filePath, JSON.stringify(data, null, 2));
    return true;
  } catch (e) {
    console.error(`⚠️ Error writing ${filePath}:`, e.message);
    return false;
  }
};

const sendReaction = (sock, remoteJid, messageKey, emoji) => 
  sock.sendMessage(remoteJid, { react: { text: emoji, key: messageKey } }).catch(() => {});

// ✅ FUNGSI POTONG DESIMAL MAKSIMAL 3 ANGKA (0.001)
const truncateTo3Decimals = (value) => {
  if (isNaN(value)) return 0;
  return Math.floor(value * 1000) / 1000;
};

// ✅ FUNGSI HITUNG DISKON DENGAN DESIMAL (POTONG 3 DESIMAL)
const calculateDiscountedLimit = (originalLimit, isPremium) => {
  if (!originalLimit || originalLimit === 0) return 0;
  const discount = isPremium ? DISCOUNT_CONFIG.premium : DISCOUNT_CONFIG.regular;
  const raw = originalLimit * (1 - discount / 100);
  
  // Potong maksimal 3 desimal (0.001)
  let result = truncateTo3Decimals(raw);
  
  // Minimal 0.001 agar tidak 0 (opsional)
  if (result <= 0 && raw > 0) return 0.001;
  
  return result;
};

// ================================
// LAPISAN 1: ANTI SPAM
// ================================
class AntiSpam {
  constructor() {
    this.userCommands = new Map();
    this.spamConfig = antiSpamConfig;
    this.startCleanupInterval();
  }

  getSpamLevel(command) {
    if (this.spamConfig.medium.commands.includes(command)) {
      return { level: 'medium', cooldown: this.spamConfig.medium.cooldown };
    }
    return null;
  }

  isSpam(userId, command) {
    const spamConfig = this.getSpamLevel(command);
    if (!spamConfig) return false;

    const key = `${userId}_${command}`;
    const lastUsed = this.userCommands.get(key);
    const now = Date.now();

    if (lastUsed && (now - lastUsed) < spamConfig.cooldown) {
      return true;
    }

    this.userCommands.set(key, now);
    return false;
  }

  cleanup() {
    const now = Date.now();
    let cleaned = 0;
    
    for (const [key, timestamp] of this.userCommands.entries()) {
      if (now - timestamp > CLEANUP_INTERVALS.antiSpam) {
        this.userCommands.delete(key);
        cleaned++;
      }
    }
  }

  startCleanupInterval() {
    this.cleanupInterval = setInterval(() => this.cleanup(), CLEANUP_INTERVALS.antiSpam);
  }

  stopCleanupInterval() {
    if (this.cleanupInterval) clearInterval(this.cleanupInterval);
  }
}

const antiSpam = new AntiSpam();

// ================================
// LAPISAN 2: RATE LIMIT PERSONAL
// ================================
class PersonalRateLimit {
  constructor() {
    this.lastMsg = new Map();
    this.startCleanupInterval();
  }

  check(sender, isOwnerU) {
    if (!RATE_LIMIT.enabled) return true;
    if (RATE_LIMIT.skipOwners && isOwnerU) return true;
    
    const now = Date.now();
    const lastTime = this.lastMsg.get(sender);
    
    if (lastTime && (now - lastTime) < RATE_LIMIT.cooldown) return false;
    
    this.lastMsg.set(sender, now);
    return true;
  }

  cleanup() {
    const now = Date.now();
    for (const [sender, timestamp] of this.lastMsg.entries()) {
      if (now - timestamp > CLEANUP_INTERVALS.rateLimitCache) {
        this.lastMsg.delete(sender);
      }
    }
  }

  startCleanupInterval() {
    this.cleanupInterval = setInterval(() => this.cleanup(), CLEANUP_INTERVALS.rateLimitCache);
  }

  stopCleanupInterval() {
    if (this.cleanupInterval) clearInterval(this.cleanupInterval);
  }
}

const rateLimiter = new PersonalRateLimit();

// ================================
// FUNGSI SEWA
// ================================
let sewaCache = new Map();
let lastSewaReload = 0;

const reloadSewaCache = async () => {
  try {
    const now = Date.now();
    if (now - lastSewaReload < SEWA_RELOAD_INTERVAL * 1000) return;
    
    const allSewa = await getAllSewa();
    sewaCache.clear();
    if (allSewa && Array.isArray(allSewa)) {
      allSewa.forEach(sewa => {
        if (sewa && sewa.id) sewaCache.set(sewa.id, sewa);
      });
    }
    lastSewaReload = now;
  } catch (e) {
    logCustom("warn", `Sewa cache reload error: ${e.message}`, `CACHE_ERROR.txt`);
  }
};

setTimeout(() => reloadSewaCache(), 1000);
setInterval(() => reloadSewaCache(), SEWA_RELOAD_INTERVAL * 1000);

// ✅ FUNGSI PENGECEKAN GRUP SEWA - return TRUE/FALSE
const isGroupRented = async (groupId) => {
  try {
    await reloadSewaCache();
    const data = sewaCache.get(groupId);
    
    if (data && data.expired) {
      return Date.now() <= data.expired;
    }
    return false;
  } catch (err) {
    return false;
  }
};

const warnGroup = async (sock, jid, msg, meta) => {
  const p = path.join(process.cwd(), DB_PATHS.groupWarnings);
  let warns = {};
  
  try {
    const existing = await safeReadJSON(p);
    if (existing) warns = existing;
  } catch (e) {}
  
  if (!warns[jid]?.warned) {
    await sock.sendMessage(jid, {
      text: `> Akses Ditolak\n\nFitur Ini Khusus Grup Premium!`
    }, { quoted: msg }).catch(() => {});
    
    warns[jid] = { 
      warned: true, 
      first_warn: new Date().toISOString(), 
      last_attempt: new Date().toISOString(), 
      group_name: meta?.subject || 'Unknown', 
      group_id: jid 
    };
    
    await safeWriteJSON(p, warns);
  }
};

// ================================
// LOAD PLUGINS
// ================================
const pluginsPath = path.join(process.cwd(), "plugins");
const lastUpdate = {};
let plugins = [];

reloadPlugins().then(p => { 
  plugins = p; 
  console.log(`[✔] Loaded ${p.length} plugins`);
}).catch(e => {
  console.error("❌ Plugin error:", e);
  logCustom("error", `Plugin loading error: ${e.message}`, `PLUGIN_LOAD_ERROR.txt`);
});

if (mode === "development") {
  chokidar.watch(pluginsPath, { ignoreInitial: true })
    .on("change", f => f.endsWith(".js") && 
      reloadPlugins().then(p => { 
        plugins = p; 
        console.log('[⚡] Plugins reloaded'); 
      }).catch(e => {
        console.error("❌ Plugin reload error:", e);
        logCustom("error", `Plugin reload error: ${e.message}`, `PLUGIN_RELOAD_ERROR.txt`);
      }));
}

// ================================
// FUNGSI LAINNYA
// ================================
const recordLimit = async (sender, cmd, used) => {
  try {
    const p = path.join(process.cwd(), DB_PATHS.limitUsage);
    let data = { users: {}, statistics: { totalLimitUsed: 0, lastReset: new Date().toISOString() } };
    
    const existing = await safeReadJSON(p);
    if (existing) data = existing;
    
    const num = sender.split("@")[0];
    if (!data.users[num]) {
      data.users[num] = { totalUsed: 0, commands: {}, lastActive: new Date().toISOString() };
    }
    
    // used bisa desimal, tetep disimpan apa adanya
    data.users[num].totalUsed += used;
    data.users[num].lastActive = new Date().toISOString();
    data.users[num].commands[cmd] = (data.users[num].commands[cmd] || 0) + used;
    data.statistics.totalLimitUsed += used;
    
    await safeWriteJSON(p, data);
  } catch (e) {
    logCustom("error", `Limit recording error: ${e.message}`, `LIMIT_RECORD_ERROR.txt`);
  }
};

// ✅ AUTO CLAIM - TANPA KIRIM PESAN (Diam-diam)
const autoClaim = async sender => {
  try {
    const data = await findUser(sender);
    if (!data) return { success: false, reason: "user_not_found" };
    
    const [_, user] = data;
    const now = Date.now();
    
    if (user.lastClaim && now - user.lastClaim < CLAIM.COOLDOWN) {
      const sisa = CLAIM.COOLDOWN - (now - user.lastClaim);
      return { 
        success: false, 
        reason: "cooldown", 
        text: `${Math.floor(sisa / 3600000)}j ${Math.floor((sisa % 3600000) / 60000)}m` 
      };
    }

    await updateUser(sender, {
      limit: (user.limit || 0) + CLAIM.AMOUNT,
      money: (user.money || 0) + 50,
      lastClaim: now
    });
    
    return { success: true, silent: true };
  } catch (err) {
    return { success: false, reason: "error" };
  }
};

const handleURL = async (sock, info) => {
  const { remoteJid, fullText, message, sender, isGroup } = info;
  
  if (fullText?.startsWith(config.prefix) || typeof fullText !== 'string' || fullText.length < 10) return null;
  if (!isOnlyURLMessage(fullText)) return null;
  
  const urls = extractURLs(fullText);
  if (!urls.length) return null;
  
  const urlInfo = detectURLType(urls[0]);
  if (!urlInfo) return null;
  
  if (isGroup) {
    const rented = await isGroupRented(remoteJid);
    if (!rented && !isOwner(sender)) {
      await sendReaction(sock, remoteJid, message.key, "⛔");
      return null;
    }
  }
  
  await sendReaction(sock, remoteJid, message.key, "🔗");
  return { 
    ...info, 
    command: urlInfo.command, 
    content: urls[0], 
    fullText: `.${urlInfo.command} ${urls[0]}`, 
    isAutoURL: true, 
    prefix: "." 
  };
};

const validatePlugin = (plugin) => {
  if (!plugin.Commands || !plugin.handle) return false;
  if (!Array.isArray(plugin.Commands)) return false;
  if (typeof plugin.handle !== 'function') return false;
  return true;
};

// ✅ EXECUTE COMMAND
const executeCommand = async (sock, final, plugin, isPremium, isOwnerU, sender, message, remoteJid) => {
  try {
    if (!validatePlugin(plugin)) {
      await sock.sendMessage(remoteJid, { text: "⚠️ Plugin error" }, { quoted: message }).catch(() => {});
      return true;
    }

    if (antiSpam.isSpam(sender, final.command)) {
      await sendReaction(sock, remoteJid, message.key, "❌");
      return true;
    }
    
    if (plugin.OnlyPremium && !isPremium && !isOwnerU) {
      await sock.sendMessage(remoteJid, { text: mess.general.isPremium }, { quoted: message }).catch(() => {});
      return true;
    }
    
    if (plugin.OnlyOwner && !isOwnerU) {
      await sock.sendMessage(remoteJid, { text: mess.general.isOwner }, { quoted: message }).catch(() => {});
      return true;
    }

    // CEK SALDO (dengan desimal)
    if (!isPremium && !isOwnerU && plugin.limitDeduction) {
      const discountedLimit = calculateDiscountedLimit(plugin.limitDeduction, isPremium);
      const user = await findUser(sender);
      if (!user) {
        await sock.sendMessage(remoteJid, { text: "❌ User not found" }, { quoted: message }).catch(() => {});
        return true;
      }

      const [_, data] = user;
      
      if ((data.limit || 0) < discountedLimit) {
        const claim = await autoClaim(sender);
        
        if (claim.success) {
          const newUser = await findUser(sender);
          if (newUser && newUser[1].limit >= discountedLimit) {
            await updateUser(sender, { limit: truncateTo3Decimals(newUser[1].limit - discountedLimit) });
            await recordLimit(sender, final.command, discountedLimit);
            await commandQueue.add(sock, final, (s, i) => plugin.handle(s, i), discountedLimit);
            return true;
          }
        }
        
        // ✅ HITUNG WAKTU CLAIM BERIKUTNYA
        const now = Date.now();
        const lastClaim = data.lastClaim || 0;
        const nextClaimTime = lastClaim + CLAIM.COOLDOWN;
        let waktuTersisa = "";
        
        if (nextClaimTime > now) {
          const sisaMs = nextClaimTime - now;
          const jam = Math.floor(sisaMs / (1000 * 60 * 60));
          const menit = Math.floor((sisaMs % (1000 * 60 * 60)) / (1000 * 60));
          const detik = Math.floor((sisaMs % (1000 * 60)) / 1000);
          
          if (jam > 0) {
            waktuTersisa = `${jam} jam ${menit} menit`;
          } else if (menit > 0) {
            waktuTersisa = `${menit} menit ${detik} detik`;
          } else {
            waktuTersisa = `${detik} detik`;
          }
        } else {
          waktuTersisa = "sekarang (klik .claim)";
        }
        
        const sisaRupiah = saldo.limitToRupiah(truncateTo3Decimals(data.limit || 0));
        const butuhRupiah = saldo.limitToRupiah(discountedLimit);
        
        const text = `╭─❒ SALDO HABIS ❒\n│\n│ Saldo tidak mencukupi\n│ 📦 Butuh: ${butuhRupiah.toLocaleString('id-ID')} Rupiah\n│ 💰 Sisa: ${sisaRupiah.toLocaleString('id-ID')} Rupiah\n│\n│ 🎁 *Saldo Gratis:*\n│ ⏰ ${waktuTersisa}\n│\n╰───────────────────`;
        
        await sock.sendMessage(remoteJid, { text }, { quoted: message }).catch(() => {});
        await recordLimit(sender, final.command, 0);
        return true;
      }

      await updateUser(sender, { limit: truncateTo3Decimals(data.limit - discountedLimit) });
      await recordLimit(sender, final.command, discountedLimit);
    }

    await commandQueue.add(sock, final, (s, i) => plugin.handle(s, i), plugin.limitDeduction || 0);
    return true;
  } catch (error) {
    logCustom("error", `Execute command error: ${error.message}`, `EXECUTE_CMD_ERROR.txt`);
    await sendReaction(sock, remoteJid, message.key, "❌").catch(() => {});
    return true;
  }
};

// ================================
// PROSES PESAN UTAMA (SUDAH DIMODIFIKASI)
// ================================

// DAFTAR COMMAND YANG TETAP BISA DIGUNAKAN DI SEMUA DESTINATION (GROUP ATAU PRIVATE)
const allowedAllDestinationCommands = ["jadibot", "sewabot", "owner"];

async function processMessage(sock, info) {
  const { remoteJid, isGroup, message, sender, pushName, fullText } = info;
  const isPremium = isPremiumUser(sender);
  const isOwnerU = isOwner(sender);

  try {
    let final = info;
    const url = await handleURL(sock, info);
    if (url) final = url;

    // ✅ preProcess jalan untuk SEMUA pesan (handler game, anti-link, dll)
    const shouldContinue = await handler.preProcess(sock, final);
    if (!shouldContinue) return;

    // ✅ Setelah preProcess, baru cek prefix untuk plugin
    if (!final.prefix && !final.isAutoURL) return;

    if (!rateLimiter.check(sender, isOwnerU)) {
      await sendReaction(sock, remoteJid, message.key, "⏳");
      return;
    }

    // ============================================================
    // ✅ CEK DESTINATION (GROUP/PRIVATE) DENGAN PENGECUALIAN
    // ============================================================
    const isWrongDestination = (config.bot_destination === "private" && isGroup) || 
                               (config.bot_destination === "group" && !isGroup);
    
    if (isWrongDestination) {
      // Cek apakah command termasuk dalam daftar yang diizinkan
      const isAllowedCommand = allowedAllDestinationCommands.includes(final.command);
      
      // Jika command TIDAK diizinkan dan user bukan owner/premium, tolak akses
      if (!isOwnerU && !isPremium && !isAllowedCommand) {
        return; // Diam-diam ditolak, tidak ada respon
      }
      // Jika command diizinkan (jadibot/sewabot/owner), LANJUTKAN proses
    }

    // ============================================================
    // ✅ CEK GRUP SEWA (dengan tambahan jadibot di allowedCommands)
    // ============================================================
    if (isGroup && config.bot_destination === "group") {
      // Tambahkan jadibot ke daftar command yang boleh diakses tanpa sewa
      const allowedCommands = ["sewabot", "owner", "menu", "allmenu", "saldo", "ceksaldo", "jadibot", "brat", "tt", "ig"];
      const needCheckRented = ONLY_RENTED_GROUPS === true;
      
      // ✅ PERBAIKAN: Hanya cek jika mode rental AKTIF
      if (needCheckRented) {
        // Command yang boleh diakses tanpa sewa
        if (!allowedCommands.includes(final.command) && !isOwnerU && !final.isAutoURL) {
          const isRentedGroup = await isGroupRented(remoteJid);
          if (!isRentedGroup) {
            await warnGroup(sock, remoteJid, message, info.groupMetadata);
            return;
          }
        }
      }
      // ✅ Jika needCheckRented = false, TIDAK ADA pengecekan
      // Semua command (termasuk smartdl) bisa jalan normal di grup manapun
    }

    // ============================================================
    // ✅ CEK PLUGIN & TYPO
    // ============================================================
    let plugin = plugins.find(p => p.Commands && p.Commands.includes(final.command));
    
    // CEK COMMAND SIMILAR (TYPO)
    if (!plugin && config.commandSimilarity && final.command) {
      const similarResult = findSimilarCommand(final.command, plugins, 0.9);
      
      if (similarResult) {
        if (similarResult.autoCorrect) {
          // ✅ KEMIRIPAN ≥ 90% → LANGSUNG OTOMATIS BENERIN
          final.command = similarResult.command;
          final.isTypo = true;
          final.similarity = similarResult.similarity;
          plugin = similarResult.plugin;
          
          // Kasih reaksi koreksi otomatis
          await sendReaction(sock, remoteJid, message.key, "✨");
          
        } else {
          // ⚠️ KEMIRIPAN < 90% → MUNCUL NOTIF, TIDAK OTOMATIS
          const notification = getTypoNotification(
            final.command,
            similarResult.command,
            final.prefix || ".",
            similarResult.similarity
          );
          
          await sock.sendMessage(remoteJid, { text: notification }, { quoted: message });
          await sendReaction(sock, remoteJid, message.key, "❓");
          return; // STOP, tidak eksekusi command
        }
      }
    }
    
    if (plugin) {
      return await executeCommand(sock, final, plugin, isPremium, isOwnerU, sender, message, remoteJid);
    }

  } catch (error) {
    logCustom("error", `processMessage error: ${error.message}`, `PROCESS_MESSAGE_ERROR.txt`);
    danger(final?.command, `Error: ${error.message}`);
  }
}

async function participantUpdate(sock, info) {
  const { id, action, participants } = info;
  try {
    const group = await findGroup(id);
    if (["promote", "demote", "add", "remove"].includes(action)) {
      updateParticipant(sock, id, participants, action).catch(() => {});
    }
    if (group) {
      if (lastUpdate[id] && Date.now() - lastUpdate[id] < config.rate_limit) return;
      lastUpdate[id] = Date.now();
      await handleActiveFeatures(sock, info, group.fitur);
    }
  } catch (error) {
    logCustom("error", `participantUpdate error: ${error.message}`, `ERROR-participant.txt`);
  }
}

function initializeBot(sock) {
  console.log('✅ Bot terinisialisasi');
}

async function gracefulShutdown() {
  console.log('\n⏹️ Shutdown...');
  antiSpam.stopCleanupInterval();
  rateLimiter.stopCleanupInterval();
  await commandQueue.shutdown(30000);
  console.log('✅ Shutdown complete');
  process.exit(0);
}

process.on('SIGINT', gracefulShutdown);
process.on('SIGTERM', gracefulShutdown);

// ================================
// EXPORT FUNCTIONS
// ================================
export { 
  processMessage, 
  participantUpdate,
  initializeBot,
  gracefulShutdown,
  commandQueue,
  antiSpam,
  rateLimiter,
  isGroupRented,
};