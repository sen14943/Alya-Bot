// ================================
// COMMAND QUEUE LOGIC (FIXED)
// ================================

import { QUEUE } from "./main_config.js";
import { noQueueCommands } from "./main_config.js";
import { logCustom } from "../lib/logger.js";

/**
 * Class untuk mengelola antrian command
 */
class CommandQueue {
  constructor() {
    this.queue = [];
    this.processing = new Map();
    this.maxConcurrent = QUEUE.maxConcurrent;
    this.DELAY = QUEUE.delay;
    this.TIMEOUT = QUEUE.timeout;
    this.queueNumber = 0;
    this.stats = { 
      processed: 0, 
      queued: 0, 
      timedout: 0, 
      noQueue: 0, 
      failed: 0 
    };
    this.processingTimeouts = new Map();
  }

  /**
   * Mengecek apakah command termasuk no queue
   * @param {string} command 
   * @returns {boolean}
   */
  isNoQueueCommand(command) {
    return noQueueCommands.includes(command);
  }

  /**
   * Menambahkan command ke antrian
   * @param {Object} sock - Socket connection
   * @param {Object} msg - Message object
   * @param {Function} fn - Function to execute
   * @param {number} limit - Limit deduction amount
   * @returns {Promise<Object>}
   */
  async add(sock, msg, fn, limit = 0) {
    if (!msg.prefix && !msg.isAutoURL) return fn(sock, msg);
    
    if (this.isNoQueueCommand(msg.command)) {
      this.stats.noQueue++;
      return fn(sock, msg);
    }
    
    const id = ++this.queueNumber;
    this.stats.queued++;
    
    await this.sendReaction(sock, msg.remoteJid, msg.message.key, "🔄");
    
    const item = { 
      id, msg, sock, fn, limit, retry: 0,
      addedAt: Date.now(),
      timeout: null,
      status: 'waiting'
    };
    
    this.queue.push(item);
    setImmediate(() => this.process());
    return { queued: true, queueNumber: id, queueLength: this.queue.length };
  }

  /**
   * Memproses antrian (FIXED: race condition)
   */
  process() {
    if (this.processing.size >= this.maxConcurrent || !this.queue.length) return;
    
    const slots = this.maxConcurrent - this.processing.size;
    const toProcess = [];
    
    // Ambil satu per satu dari depan queue (fix race condition)
    for (let i = 0; i < slots && this.queue.length > 0; i++) {
      const item = this.queue.shift();
      if (item && item.status === 'waiting') {
        toProcess.push(item);
      }
    }
    
    for (const item of toProcess) {
      item.status = 'processing';
      this.processing.set(item.id, item);
      
      const delayTime = this.DELAY * this.processing.size;
      const timeoutId = setTimeout(() => this.execute(item), delayTime);
      this.processingTimeouts.set(item.id, timeoutId);
    }
  }

  /**
   * Mengeksekusi item dari antrian (FIXED: clear timeout di finally)
   * @param {Object} item - Queue item
   */
  async execute(item) {
    // Clear processing timeout
    if (this.processingTimeouts.has(item.id)) {
      clearTimeout(this.processingTimeouts.get(item.id));
      this.processingTimeouts.delete(item.id);
    }
    
    await this.sendReaction(item.sock, item.msg.remoteJid, item.msg.message.key, "🔄");
    
    // Set timeout untuk eksekusi
    item.timeout = setTimeout(() => {
      if (!this.processing.has(item.id)) return;
      
      this.stats.timedout++;
      item.status = 'timeout';
      
      this.sendReaction(item.sock, item.msg.remoteJid, item.msg.message.key, "⏳");
      item.sock.sendMessage(item.msg.remoteJid, { 
        text: `> Server Overload, Tunggu Sebentar!` 
      }, { quoted: item.msg.message }).catch(() => {});
    }, this.TIMEOUT);
    
    try {
      await item.fn(item.sock, item.msg);
      
      if (item.status !== 'timeout') {
        this.stats.processed++;
        await this.sendReaction(item.sock, item.msg.remoteJid, item.msg.message.key, "✅");
      } else {
        await this.sendReaction(item.sock, item.msg.remoteJid, item.msg.message.key, "✅");
      }
    } catch (error) {
      logCustom("error", `Queue Error #${item.id}: ${error.message}`, `QUEUE_ERROR.txt`);
      await this.sendReaction(item.sock, item.msg.remoteJid, item.msg.message.key, "❌");
      this.stats.failed++;
      
      // FIXED: retry dengan batasan dan cek error permanent
      if (item.retry < 2 && !this.isPermanentError(error)) {
        item.status = 'waiting';
        item.retry++;
        this.queue.unshift(item);
      }
    } finally {
      // FIXED: timeout pasti ke-clear
      if (item.timeout) {
        clearTimeout(item.timeout);
        item.timeout = null;
      }
      
      this.processing.delete(item.id);
      if (this.processingTimeouts.has(item.id)) {
        clearTimeout(this.processingTimeouts.get(item.id));
        this.processingTimeouts.delete(item.id);
      }
      setImmediate(() => this.process());
    }
  }

  /**
   * Cek apakah error permanent (gak perlu retry)
   * @param {Error} error 
   * @returns {boolean}
   */
  isPermanentError(error) {
    const permanentErrors = [
      'Invalid session',
      'Authentication failed',
      'Not authorized',
      'Permission denied',
      'Blocked'
    ];
    return permanentErrors.some(msg => error.message?.includes(msg));
  }

  /**
   * Mengirim reaksi ke pesan (FIXED: log error)
   * @param {Object} sock 
   * @param {string} remoteJid 
   * @param {Object} messageKey 
   * @param {string} emoji 
   */
  async sendReaction(sock, remoteJid, messageKey, emoji) {
    try {
      await sock.sendMessage(remoteJid, { react: { text: emoji, key: messageKey } });
    } catch (error) {
      logCustom("warn", `Reaction failed: ${error.message}`, "REACTION_ERROR.txt");
    }
  }

  /**
   * Shutdown queue dengan timeout
   * @param {number} timeoutMs 
   * @returns {Promise<boolean>}
   */
  async shutdown(timeoutMs = 30000) {
    const startTime = Date.now();
    return new Promise((resolve) => {
      const checkInterval = setInterval(() => {
        if (this.processing.size === 0) {
          clearInterval(checkInterval);
          resolve(true);
        } else if (Date.now() - startTime > timeoutMs) {
          clearInterval(checkInterval);
          resolve(false);
        }
      }, 100);
    });
  }

  /**
   * Mendapatkan statistik queue
   * @returns {Object}
   */
  getStats() {
    return {
      ...this.stats,
      queueLength: this.queue.length,
      processing: this.processing.size
    };
  }

  /**
   * Reset semua statistik
   */
  resetStats() {
    this.stats = { 
      processed: 0, 
      queued: 0, 
      timedout: 0, 
      noQueue: 0, 
      failed: 0 
    };
    this.queueNumber = 0;
  }

  /**
   * Membersihkan semua antrian (FIXED: reset processing & timeout)
   */
  clearQueue() {
    // Clear semua timeout yang pending
    for (const [id, timeoutId] of this.processingTimeouts) {
      clearTimeout(timeoutId);
    }
    this.processingTimeouts.clear();
    
    // Hentikan semua item yang diproses
    for (const [id, item] of this.processing) {
      if (item.timeout) clearTimeout(item.timeout);
    }
    this.processing.clear();
    
    this.queue = [];
    this.queueNumber = 0;
  }
}

// Export singleton instance
export const commandQueue = new CommandQueue();

// Export class untuk keperluan testing
export { CommandQueue };