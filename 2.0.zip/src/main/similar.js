// ================================
// FUNGSI SIMILAR (CMD TYPO)
// ================================

import { commandWithoutRegister } from "./main_config.js";

/**
 * Mencari command yang paling mirip dengan input user
 * @param {string} command - Command yang diinput user
 * @param {Array} plugins - Daftar plugin yang tersedia
 * @param {number} autoCorrectThreshold - Threshold untuk auto correct (default 0.9)
 * @returns {Object|null} - Hasil similar atau null
 */
export const findSimilarCommand = (command, plugins, autoCorrectThreshold = 0.9) => {
  if (!command || !plugins || plugins.length === 0) return null;
  
  let bestMatch = null;
  let highestSimilarity = 0;
  
  // Cari semua command dari semua plugin
  const allCommands = [];
  plugins.forEach(plugin => {
    if (plugin.Commands && Array.isArray(plugin.Commands)) {
      plugin.Commands.forEach(cmd => {
        allCommands.push({
          command: cmd,
          plugin: plugin
        });
      });
    }
  });
  
  // Hitung similarity untuk setiap command
  for (const item of allCommands) {
    const similarity = calculateSimilarity(command, item.command);
    
    if (similarity > highestSimilarity) {
      highestSimilarity = similarity;
      bestMatch = item;
    }
  }
  
  // Jika tidak ada command yang mirip
  if (!bestMatch) return null;
  
  // Jika command dalam daftar withoutRegister, abaikan
  if (commandWithoutRegister.includes(command)) return null;
  
  // Jika command persis sama, bukan typo
  if (bestMatch.command === command) return null;
  
  // Hasil dengan similarity dan flag autoCorrect
  const shouldAutoCorrect = highestSimilarity >= autoCorrectThreshold;
  
  return {
    command: bestMatch.command,
    plugin: bestMatch.plugin,
    similarity: highestSimilarity,
    originalCommand: command,
    autoCorrect: shouldAutoCorrect  // true jika ≥90%, false jika <90%
  };
};

/**
 * Menghitung persentase kemiripan antara dua string
 * @param {string} str1 - String pertama
 * @param {string} str2 - String kedua
 * @returns {number} - Persentase kemiripan (0-1)
 */
const calculateSimilarity = (str1, str2) => {
  if (!str1 || !str2) return 0;
  if (str1 === str2) return 1;
  
  // Normalisasi string (lowercase)
  const s1 = str1.toLowerCase();
  const s2 = str2.toLowerCase();
  
  // Hitung jarak Levenshtein
  const distance = levenshteinDistance(s1, s2);
  const maxLength = Math.max(s1.length, s2.length);
  
  // Konversi ke persentase kemiripan
  return 1 - (distance / maxLength);
};

/**
 * Menghitung jarak Levenshtein antara dua string
 * @param {string} a - String pertama
 * @param {string} b - String kedua
 * @returns {number} - Jarak Levenshtein
 */
const levenshteinDistance = (a, b) => {
  const matrix = [];
  
  // Inisialisasi matrix
  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }
  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }
  
  // Hitung jarak
  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      const cost = a[j - 1] === b[i - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,      // deletion
        matrix[i][j - 1] + 1,      // insertion
        matrix[i - 1][j - 1] + cost // substitution
      );
    }
  }
  
  return matrix[b.length][a.length];
};

/**
 * Membuat pesan notifikasi untuk command typo (hanya untuk kemiripan < 90%)
 * @param {string} originalCommand - Command asli yang salah
 * @param {string} suggestedCommand - Command yang disarankan
 * @param {string} prefix - Prefix bot (misal: ".")
 * @param {number} similarity - Persentase kemiripan
 * @returns {string} - Pesan notifikasi
 */
export const getTypoNotification = (originalCommand, suggestedCommand, prefix = ".", similarity) => {
  const percentage = Math.floor(similarity * 100);
  return `Hy, Kak 👋😊
Cmd : *${prefix}${originalCommand}*
Tidak Ada Pada Bot Kami!

Mungkin Kakak Nya Typo 😅
*Kamu Bisa Coba:*
> Ketik: ${prefix}${suggestedCommand}`;
};

/**
 * Memeriksa apakah command memiliki kemiripan tinggi (≥90%)
 * @param {string} command - Command yang diinput
 * @param {Array} plugins - Daftar plugin
 * @returns {Object|null}
 */
export const checkHighSimilarity = (command, plugins) => {
  return findSimilarCommand(command, plugins, 0.9);
};

/**
 * Memeriksa apakah command memiliki kemiripan rendah (<90%)
 * @param {string} command - Command yang diinput
 * @param {Array} plugins - Daftar plugin
 * @returns {Object|null}
 */
export const checkLowSimilarity = (command, plugins) => {
  const result = findSimilarCommand(command, plugins, 0);
  if (result && !result.autoCorrect && result.similarity > 0.3) { // minimal 30% untuk kasih saran
    return result;
  }
  return null;
};