// ================================
// KONFIGURASI
// ================================

// Command tanpa register
export const commandWithoutRegister = ["list", "owner", "menu", "allmenu", "claim", "hd", "tt", "brat", "qc", "iqc", "play", "ig", "saldo", "ceksaldo"];

// Command langsung (no queue)
export const noQueueCommands = ["menu", "allmenu", "sewa", "laraon", "laraoff", "kick", "del", "addprem", "on", "off", "saldo", "ceksaldo"];

// Anti spam per command (1 menit)
export const antiSpamConfig = {
  medium: {
    commands: ["menu", "allmenu", "sewabot", "laraon", "laraoff"],
    cooldown: 30000 // 1 menit
  }
};

// Rate limit personal (cegah spam sebelum masuk queue)
export const RATE_LIMIT = {
  enabled: true,
  cooldown: 6700,     // 12 detik antar command per user
  skipOwners: true    // Owner bebas
};

// Queue settings
export const QUEUE = {
  maxConcurrent: 2,
  delay: 1400,
  timeout: 90000
};

// Diskon limit
export const DISCOUNT_CONFIG = {
  premium: 45,
  regular: 20
};

// Claim limit
export const CLAIM = { 
  AMOUNT: 135, 
  COOLDOWN: 3 * 24 * 60 * 60 * 1000
};

// Database paths
export const DB_PATHS = {
  limitUsage: "./db/users/limitusage.json",
  groupWarnings: "./db/group/warnings.json"
};

// Cleanup intervals
export const CLEANUP_INTERVALS = {
  antiSpam: 300000,
  rateLimitCache: 600000,
  sewaCache: 10000
};

export const SEWA_RELOAD_INTERVAL = 10;

// ================================
// ✅ KONFIGURASI GRUP SEWA
// ================================
// true  = HANYA grup yang sudah sewa yang bisa pakai bot
// false = SEMUA grup bisa pakai bot (gratis)
export const ONLY_RENTED_GROUPS = true;  // True Jika Hanya Untuk Penyewa