import moment from "moment-timezone";

// ================ KONFIGURASI UTAMA ================
const CONNECTION = "qr"; // qr atau pairing
const OWNER_NAME = "Angela";
const NOMOR_BOT = "62895337302084"; // 628xx nomor wa
const DESTINATION = "group"; // group , private, both
const APIKEY = "lara14"; // apikey dari autoresbot.com (paket apikey)
const RATE_LIMIT = 1000; // 3 detik/chat
const SIMILARITY = true; // Pencarian kemiripan command (true, false)
const MODE = "production"; // [production, development] (jangan di ubah kecuali anda developer)
const VERSION = global.version; // don't edit

// ================ INFORMASI PEMILIK ================
const EMAIL = "authenlaura5@gmail.com";
const REGION = "Indonesia";
const WEBSITE = "aracloud.iceiy.com";
const DATA_OWNER = ["6285126189342", "628988838767", "6282184353560", "6285641042562"];

// ================ KONFIGURASI CHAT ================
const ANTI_CALL = false; // jika true (setiap yang nelpon pribadi akan di block)
const AUTO_READ = false; // jika true (setiap chat akan di baca/centang 2 biru)
const AUTO_BACKUP = false; // jika true (setiap restart server, data backup di kirimkan ke wa owner)
const MIDNIGHT_RESTART = false; // Restart setiap jam 12 malam
const PRESENCE_UPDATE = ""; // unavailable, available, composing, recording, paused
const TYPE_WELCOME = "text"; // text dan random (1-6 untuk gambar)
const BG_WELCOME2 = "https://api.autoresbot.com/api/maker/bg-default";
const STATUS_SCHEDULED = true;

// ================ KONFIGURASI PANEL ================
const PANEL_URL = "";
const PANEL_PLTA = "";
const PANEL_DESCRIPTION = "";
const PANEL_ID_EGG = 15;
const PANEL_ID_LOCATION = 1;
const PANEL_DEFAULT_DISK = 1024; // 5GB atau 0 (unlimited)
const PANEL_DEFAULT_CPU = 40;

// ================ KONFIGURASI ANTIBADWORD ================
const BADWORD_WARNING = 2; // Jumlah maksimum peringatan sebelum tindakan diambil
const BADWORD_ACTION = "both"; // tindakan setelah warning terpenuhi (warn, kick, ban, both)
const BADWORD_SIMILARITY = true; // Deteksi kemiripan kata (90% similar)
const BADWORD_SIMILARITY_THRESHOLD = 90; // Persentase kemiripan minimum (1-100)
const BADWORD_MIN_WORD_LENGTH = 3; // Minimal panjang kata untuk dicek
const BADWORD_DEFAULT_ENABLED = true; // Gunakan daftar badword default
const BADWORD_DELETE_MESSAGE = true; // Hapus pesan yang mengandung badword
const BADWORD_SEND_WARNING = true; // Kirim peringatan ke pengguna
const BADWORD_LOG_DETECTION = true; // Log deteksi badword

// ================ KONFIGURASI ANTISPAM ================
const SPAM_LIMIT = 3; // Batas pesan dianggap spam
const SPAM_COOLDOWN = 3; // Waktu cooldown dalam detik (3 detik)
const SPAM_WARNING = 2; // Jumlah maksimum peringatan sebelum tindakan diambil
const SPAM_ACTION = "block"; // tindakan setelah warning terpenuhi (kick, block, both)
const SPAM_DETECT_FAST_MESSAGE = true; // Deteksi pesan terlalu cepat
const SPAM_DETECT_REPEAT_MESSAGE = true; // Deteksi pesan berulang
const SPAM_DELETE_MESSAGE = true; // Hapus pesan spam

// ================ KONFIGURASI KEAMANAN LAINNYA ================
const ANTI_LINK = false; // Blokir link otomatis
const ANTI_VIRUS = true; // Deteksi file berbahaya
const ANTI_SCAM = true; // Deteksi nomor scam
const GROUP_APPROVAL = false; // Persetujuan masuk group
const MAX_GROUP_MEMBERS = 1024; // Batas maksimal member group
const AUTO_KICK_INACTIVE = false; // Kick member tidak aktif setelah 30 hari

// ================ KONFIGURASI FITUR BOT ================
const AUTO_DOWNLOAD_MEDIA = false; // Auto download media yang dikirim
const AUTO_STICKER_CREATOR = true; // Auto buat sticker dari gambar
const AUTO_REPLY_PM = true; // Auto reply chat private
const MAX_UPLOAD_SIZE = 50; // Max size upload dalam MB
const COMMAND_COOLDOWN = 2; // Cooldown command dalam detik
const ENABLE_MENTION_REPLY = true; // Bot merespons saat di-mention

// ================ KONFIGURASI DATABASE ================
const DATABASE_BACKUP_INTERVAL = 24; // Backup database setiap jam
const DATABASE_CLEANUP_DAYS = 30; // Hapus data lebih dari 30 hari
const CACHE_ENABLED = true; // Enable caching untuk performa
const CACHE_TTL = 300; // Time To Live cache dalam detik

const config = {
  // ================ IDENTITAS ================
  APIKEY,
  phone_number_bot: NOMOR_BOT,
  type_connection: CONNECTION,
  bot_destination: DESTINATION,
  owner_name: OWNER_NAME,
  owner_number: DATA_OWNER,
  owner_website: WEBSITE,
  owner_email: EMAIL,
  region: REGION,
  version: VERSION,
  
  // ================ PENGATURAN UMUM ================
  rate_limit: RATE_LIMIT,
  status_prefix: true, // wajib prefix : atau false tanpa prefix
  prefix: ["."],
  sticker_packname: OWNER_NAME,
  sticker_author: `Date: ${moment
    .tz("Asia/Jakarta")
    .format("DD/MM/YY")}\nBY LaraBot - Angela`,
  mode: MODE,
  commandSimilarity: SIMILARITY,
  
  // ================ PENGATURAN CHAT ================
  anticall: ANTI_CALL,
  autoread: AUTO_READ,
  autobackup: AUTO_BACKUP,
  PresenceUpdate: PRESENCE_UPDATE,
  typewelcome: TYPE_WELCOME,
  bgwelcome2: BG_WELCOME2,
  midnight_restart: MIDNIGHT_RESTART,
  scheduled: STATUS_SCHEDULED,
  
  // ================ PENGATURAN KEAMANAN ================
  antilink: ANTI_LINK,
  antivirus: ANTI_VIRUS,
  antiscam: ANTI_SCAM,
  group_approval: GROUP_APPROVAL,
  max_group_members: MAX_GROUP_MEMBERS,
  auto_kick_inactive: AUTO_KICK_INACTIVE,
  
  // ================ PENGATURAN FITUR ================
  auto_download_media: AUTO_DOWNLOAD_MEDIA,
  auto_sticker_creator: AUTO_STICKER_CREATOR,
  auto_reply_pm: AUTO_REPLY_PM,
  max_upload_size: MAX_UPLOAD_SIZE,
  command_cooldown: COMMAND_COOLDOWN,
  enable_mention_reply: ENABLE_MENTION_REPLY,
  
  // ================ PENGATURAN DATABASE ================
  database_backup_interval: DATABASE_BACKUP_INTERVAL,
  database_cleanup_days: DATABASE_CLEANUP_DAYS,
  cache_enabled: CACHE_ENABLED,
  cache_ttl: CACHE_TTL,
  
  // ================ KONFIGURASI SPAM ================
  SPAM: {
    limit: SPAM_LIMIT,
    cooldown: SPAM_COOLDOWN, // Diperbaiki dari 'couldown' ke 'cooldown'
    warning: SPAM_WARNING,
    action: SPAM_ACTION,
    detect_fast_message: SPAM_DETECT_FAST_MESSAGE,
    detect_repeat_message: SPAM_DETECT_REPEAT_MESSAGE,
    delete_message: SPAM_DELETE_MESSAGE
  },
  
  // ================ KONFIGURASI BADWORD ================
  BADWORD: {
    warning: BADWORD_WARNING,
    action: BADWORD_ACTION,
    use_similarity: BADWORD_SIMILARITY,
    similarity_threshold: BADWORD_SIMILARITY_THRESHOLD,
    min_word_length: BADWORD_MIN_WORD_LENGTH,
    default_enabled: BADWORD_DEFAULT_ENABLED,
    delete_message: BADWORD_DELETE_MESSAGE,
    send_warning: BADWORD_SEND_WARNING,
    log_detection: BADWORD_LOG_DETECTION,
    // Daftar badword default akan diambil dari file terpisah
  },
  
  // ================ KONFIGURASI PANEL ================
  PANEL: {
    URL: PANEL_URL,
    KEY_APPLICATION: PANEL_PLTA,
    description: PANEL_DESCRIPTION,
    SERVER_EGG: PANEL_ID_EGG,
    id_location: PANEL_ID_LOCATION,
    default_disk: PANEL_DEFAULT_DISK,
    cpu_default: PANEL_DEFAULT_CPU,
  },
  
  // ================ TIMEZONE & LOCALE ================
  timezone: "Asia/Jakarta",
  locale: "id_ID",
  
  // ================ LOGGING ================
  log_level: "info", // debug, info, warn, error
  log_to_file: true,
  log_file_path: "./logs/bot.log",
  
  // ================ PERFORMANCE ================
  max_concurrent_operations: 5,
  queue_enabled: true,
  queue_max_size: 100,
  
  // ================ UPDATE & MAINTENANCE ================
  auto_update: false,
  maintenance_mode: false,
  maintenance_message: "Bot sedang dalam perawatan. Silakan coba lagi nanti.",
  
  // ================ CUSTOMIZATION ================
  bot_name: "Lara",
  bot_gender: "female",
  bot_personality: "friendly", // friendly, formal, funny, strict
  enable_ai_response: false,
  ai_response_chance: 30, // Persentase bot merespons dengan AI
};

export default config;