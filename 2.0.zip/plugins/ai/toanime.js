// plugins/hitamkan.js
import { editImage } from '../../api/ai-img.js';
import { uploadFile } from '../../api/uploader.js';
import { downloadQuotedMedia, downloadMedia, reply } from '../../src/lib/utils.js';
import { sendHelpCard } from '../../case/help.js';
import fs from 'fs';
import path from 'path';

const PROMPT = 'Buat Seseorang Pada Gambar Menjadi Anime 3D Realistis. Perbaiki Aksesoris, Dan Outfit Nya.';

async function handle(sock, messageInfo) {
    const { m, remoteJid, message, prefix, command, type, isQuoted } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    // Command tanpa parameter (hanya .toanime atau .jadianime)
    // Langsung kirim help card

    try {
        const mediaType = isQuoted ? isQuoted.type : type;
        
        // Cek apakah ada gambar
        if (mediaType !== 'image') {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: true,
                needText: false,
                example: "(kirim atau balas gambar)",
                description: "Ubah foto biasa menjadi anime 3D realistis dengan AI.\n\n✨ Cukup kirim atau balas gambar, otomatis diproses!\n✨ Hasil: gaya anime 3D dengan aksesoris dan outfit yang diperbaiki",
                notes: "Makin jelas foto wajahnya, makin bagus hasilnya!",
                limits: "2 poin"
            });
        }

        await sock.sendMessage(remoteJid, { 
            react: { text: '🎨', key: message.key } 
        });

        // ===============================
        // DOWNLOAD MEDIA
        // ===============================
        let media;
        try {
            media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
        } catch (error) {
            console.error('Download error:', error);
            return await reply(m, '❌ Gagal mengunduh gambar.\nSilakan kirim ulang gambar.');
        }

        const tmpFolder = path.resolve('./storage/tmp');
        const mediaPath = path.join(tmpFolder, media);
        
        if (!fs.existsSync(mediaPath)) {
            return await reply(m, '❌ File gambar tidak ditemukan.\nSilakan kirim ulang gambar.');
        }

        // ===============================
        // UPLOAD (Pakai uploader.js)
        // ===============================
        let imageUrl;
        try {
            imageUrl = await uploadFile(mediaPath);
            console.log(`📤 Upload berhasil: ${imageUrl}`);
        } catch (uploadError) {
            console.error('Upload error:', uploadError);
            return await reply(m, '❌ Gagal mengupload gambar.\nSilakan coba lagi.');
        }

        // ===============================
        // EDIT DENGAN AI (Pakai editorai.js)
        // ===============================
        await sock.sendMessage(remoteJid, { 
            react: { text: '🤖', key: message.key } 
        });

        let resultBuffer;
        try {
            resultBuffer = await editImage(imageUrl, PROMPT);
        } catch (editError) {
            console.error('Edit AI error:', editError);
            return await reply(m, `❌ Gagal memproses gambar.\n${editError.message}`);
        }

        // Hapus file temporary
        fs.unlink(mediaPath, () => {});

        // Kirim hasil
        await sock.sendMessage(remoteJid, {
            image: resultBuffer,
            caption: `> Berhasil Kak!\n\n*BY : Laura-AI*`,
        }, { quoted: message });
        
        // React sukses
        await sock.sendMessage(remoteJid, { 
            react: { text: '✅', key: message.key } 
        });
        
    } catch (error) {
        console.error('Error in toanime command:', error);
        await reply(m, '❌ Terjadi kesalahan saat memproses gambar.\nSilakan coba lagi nanti.');
        
        await sock.sendMessage(remoteJid, { 
            react: { text: '❌', key: message.key } 
        }).catch(() => {});
    }
}

export default {
    handle,
    Commands: ['toanime', 'jadianime'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 2,
};