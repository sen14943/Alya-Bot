// plugins/edit.js
import { editImage } from '../../api/ai-img.js';
import { uploadFile } from '../../api/uploader.js';
import { downloadQuotedMedia, downloadMedia, reply } from '../../src/lib/utils.js';
import { sendHelpCard } from '../../case/help.js';
import fs from 'fs';
import path from 'path';

async function handle(sock, messageInfo) {
    const { m, remoteJid, message, prefix, command, type, isQuoted, content } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim().length === 0) {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: true,
            needText: true,
            example: "jadikan anime",
            description: "Edit gambar dengan AI.\n\n✨ Contoh prompt:\n• jadikan style anime\n• ubah jadi lukisan minyak\n• jadi kartun disney\n• style cyberpunk\n• ubah jadi pemandangan pantai",
            notes: "Prompt yang detail dan spesifik akan menghasilkan edit yang lebih bagus!",
            limits: "2 poin"
        });
    }

    try {
        const mediaType = isQuoted ? isQuoted.type : type;
        
        // Cek apakah ada gambar
        if (mediaType !== 'image') {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: true,
                needText: true,
                example: "jadikan anime",
                description: "Kamu harus kirim atau balas gambar!\n\nKirim gambar dengan caption perintah edit.\n\n✨ Contoh: .edit jadikan anime",
                notes: "Prompt yang detail = hasil lebih bagus!",
                limits: "2 poin"
            });
        }

        // React loading
        await sock.sendMessage(remoteJid, {
            react: { text: '🎨', key: message.key },
        });

        // ===============================
        // DOWNLOAD MEDIA
        // ===============================
        let media;
        try {
            media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
        } catch (err) {
            console.error('Download error:', err);
            return await reply(
                m,
                '❌ Gagal mengunduh gambar dari WhatsApp.\n\nSilakan kirim ulang gambar dan coba lagi.'
            );
        }

        const tmpFolder = path.resolve('./storage/tmp');
        const mediaPath = path.join(tmpFolder, media);

        if (!fs.existsSync(mediaPath)) {
            return await reply(m, '❌ File gambar tidak ditemukan.\nSilakan kirim ulang gambar.');
        }

        // ===============================
        // UPLOAD (Pakai uploader.js)
        // ===============================
        let imageUrl;
        try {
            imageUrl = await uploadFile(mediaPath);
            console.log(`📤 Upload berhasil: ${imageUrl}`);
        } catch (uploadError) {
            console.error('Upload error:', uploadError);
            return await reply(m, '❌ Gagal mengupload gambar.\nSilakan coba beberapa saat lagi.');
        }

        // ===============================
        // EDIT DENGAN AI (Pakai editorai.js)
        // ===============================
        await sock.sendMessage(remoteJid, {
            react: { text: '🤖', key: message.key },
        });

        let resultBuffer;
        try {
            resultBuffer = await editImage(imageUrl, content.trim());
        } catch (editError) {
            console.error('Edit AI error:', editError);
            return await reply(m, `❌ Gagal mengedit gambar.\n${editError.message}`);
        }

        // Hapus file temporary
        fs.unlink(mediaPath, () => {});

        // Kirim hasil edit
        await sock.sendMessage(
            remoteJid,
            {
                image: resultBuffer,            
                caption: `> Berhasil Kak!\n\n*BY : Lara-AI*`,
            },
            { quoted: message },
        );
        
        // React sukses
        await sock.sendMessage(remoteJid, {
            react: { text: '✅', key: message.key },
        });
        
    } catch (error) {
        console.error('Error in edit command:', error);
        await reply(m, '❌ Terjadi kesalahan saat memproses gambar.\nSilakan coba lagi nanti.');
        
        await sock.sendMessage(remoteJid, {
            react: { text: '❌', key: message.key },
        }).catch(() => {});
    }
}

export default {
    handle,
    Commands: ['edit', 'art'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 2,
};