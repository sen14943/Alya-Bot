// plugins/yts.js
import yts from "yt-search";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";

// Fungsi untuk menangani pencarian YouTube
async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command } = messageInfo;

  try {
    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || !content.trim()) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "matahariku",
        description: "Cari video di YouTube dengan mudah!\n\n✨ Fitur:\n• Mencari video berdasarkan keyword\n• Menampilkan thumbnail\n• Info lengkap: durasi, views, upload date\n• Menampilkan 10 hasil teratas\n\n📝 Format: ${prefix + command} [keyword]\n📌 Contoh: ${prefix + command} matahariku\n📌 Contoh: ${prefix + command} anime romance",
        notes: "Makin spesifik keyword, makin relevan hasilnya!",
        limits: "1 poin"
      });
    }

    // Tampilkan reaksi "Loading"
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Melakukan pencarian menggunakan yts
    const search = await yts(content);

    // Cek apakah ada hasil
    if (!search.all || search.all.length === 0) {
      throw new Error("Tidak ada hasil untuk keyword: " + content);
    }

    // Batasi hasil maksimal 10 video
    const maxResults = Math.min(search.all.length, 10);
    
    // Menyusun teks hasil pencarian
    let teks = `🔍 *YouTube Search*\n\n📌 *Keyword:* ${content}\n📊 *Total:* ${search.all.length} hasil\n\n`;
    
    for (let i = 0; i < maxResults; i++) {
      const video = search.all[i];
      teks +=
        `┌─❖\n` +
        `│ 🎬 *${video.title}*\n` +
        `├─❖\n` +
        `│ ⏱️ Duration: ${video.timestamp}\n` +
        `│ 👁️ Views: ${video.views}\n` +
        `│ 📅 Upload: ${video.ago}\n` +
        `│ 🔗 URL: ${video.url}\n` +
        `└────────────┻\n\n`;
    }

    // React proses
    await sock.sendMessage(remoteJid, {
      react: { text: "📹", key: message.key },
    });

    // Mengirim hasil pencarian dengan thumbnail dari video pertama
    await sock.sendMessage(
      remoteJid,
      {
        image: { url: search.all[0].thumbnail },
        caption: teks,
      },
      { quoted: message }
    );

    // React sukses
    await sock.sendMessage(remoteJid, {
      react: { text: "✅", key: message.key },
    });

  } catch (error) {
    console.error("Error while searching YouTube:", error);
    logCustom("info", content, `ERROR-COMMAND-${command}.txt`);
    
    // React error
    await sock.sendMessage(remoteJid, {
      react: { text: "❌", key: message.key },
    }).catch(() => {});

    // Menangani kesalahan dan mengirim pesan ke pengguna
    const errorMessage = `❌ Gagal mencari video: ${error.message || error}\n\n💡 Coba keyword yang berbeda atau pastikan koneksi internet stabil.`;
    
    await sock.sendMessage(remoteJid, { 
      text: errorMessage 
    }, { quoted: message });
  }
}

export default {
  handle,
  Commands: ["yts", "ytsearch"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};