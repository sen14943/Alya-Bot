import { tiktokSearch } from "../../api/tiktok.js";
import { logCustom } from "../../src/lib/logger.js";
import { downloadToBuffer } from "../../src/lib/utils.js";
import { sendHelpCard } from "../../case/help.js";

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command } = messageInfo;

  try {
    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || !content.trim()) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "kucing lucu",
        description: "Cari dan download video TikTok tanpa watermark!\n\n✨ Fitur:\n• Cari video berdasarkan keyword\n• Download tanpa watermark\n• Kirim video langsung ke chat\n• Judul video sebagai caption\n\n📝 Format: ${prefix + command} [keyword]\n📌 Contoh: ${prefix + command} kucing lucu\n📌 Contoh: ${prefix + command} dance trend",
        notes: "Makin spesifik keyword, makin relevan hasilnya!",
        limits: "1 poin"
      });
    }

    // Tampilkan reaksi "Loading"
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Memanggil API untuk mendapatkan data video TikTok
    const response = await tiktokSearch(content);

    // Download file ke buffer
    const audioBuffer = await downloadToBuffer(response.no_watermark, "mp4");

    // Kirim reaksi proses
    await sock.sendMessage(remoteJid, {
      react: { text: "📹", key: message.key },
    });

    // Mengirim video tanpa watermark dan caption
    await sock.sendMessage(
      remoteJid,
      {
        video: audioBuffer,
        caption: `🎵 *${response.title}*\n\n📥 *Downloaded by:* Lara AI\n🔗 *Query:* ${content}`,
      },
      { quoted: message }
    );

    // React sukses
    await sock.sendMessage(remoteJid, {
      react: { text: "✅", key: message.key },
    });

  } catch (error) {
    console.error("Kesalahan saat memproses perintah TikTok:", error);
    logCustom("info", content, `ERROR-COMMAND-${command}.txt`);
    
    // React error
    await sock.sendMessage(remoteJid, {
      react: { text: "❌", key: message.key },
    }).catch(() => {});
    
    // Kirim pesan kesalahan yang lebih informatif
    const errorMessage = `❌ Gagal mencari video TikTok: ${error.message || error}\n\n💡 Coba keyword yang berbeda atau pastikan koneksi internet stabil.`;
    
    await sock.sendMessage(remoteJid, { 
      text: errorMessage 
    }, { quoted: message });
  }
}

export default {
  handle,
  Commands: ["tiktoksearch", "ttsearch", "tts"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};