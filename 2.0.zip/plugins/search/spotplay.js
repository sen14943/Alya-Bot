// plugins/play.js
import { ytmp3ByQuery } from '../../api/ytdl/ytdl.js';
import { searchSpotify } from '../../api/spotify.js';
import { sendHelpCard } from '../../case/help.js';

async function handle(sock, messageInfo) {
    const { m, remoteJid, message, content, prefix, command } = messageInfo;

    try {
        let query = content?.trim();

        // ===============================
        // CEK APAKAH USER MINTA BANTUAN
        // ===============================
        if (!query) {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: false,
                needText: true,
                example: "faded alan walker",
                description: "Putar lagu dari Spotify atau YouTube!\n\n✨ Fitur:\n• Prioritas Spotify API\n• Fallback ke YouTube jika gagal\n• Kirim thumbnail lagu\n• Audio kualitas bagus\n• Support judul lagu atau link\n\n📝 Format: ${prefix + command} [judul lagu / link]\n📌 Contoh: ${prefix + command} faded alan walker",
                notes: "Pastikan koneksi internet stabil untuk hasil terbaik!",
                limits: "1 poin"
            });
        }

        // React loading
        await sock.sendMessage(remoteJid, { react: { text: '🔍', key: message.key } });

        let result;

        // Prioritas: Spotify dulu, fallback ke YouTube
        try {
            console.log('🎵 Mencoba Spotify API...');
            result = await searchSpotify(query);
            
            // React download
            await sock.sendMessage(remoteJid, { react: { text: '⬇️', key: message.key } });
            
            // Kirim thumbnail + caption (REPLY ke pesan user)
            if (result.thumbnail) {
                await sock.sendMessage(remoteJid, {
                    image: { url: result.thumbnail },
                    caption: `> ${result.title}\n${result.artist || ''}\n\n${result.album || ''}`
                }, { quoted: message });
            } else {
                await sock.sendMessage(remoteJid, {
                    text: `> ${result.title}`
                }, { quoted: message });
            }
            
            // Download audio dari rawLink
            const audioResponse = await fetch(result.audio);
            const audioBuffer = Buffer.from(await audioResponse.arrayBuffer());
            
            // Kirim audio
            await sock.sendMessage(remoteJid, {
                audio: audioBuffer,
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: message });
            
        } catch (spotifyError) {
            console.log('⚠️ Spotify error, fallback ke YouTube:', spotifyError.message);
            
            // Fallback ke ytdl
            result = await ytmp3ByQuery(query);
            
            // React download
            await sock.sendMessage(remoteJid, { react: { text: '⬇️', key: message.key } });
            
            // Kirim thumbnail + caption
            if (result.thumbnail) {
                await sock.sendMessage(remoteJid, {
                    image: { url: result.thumbnail },
                    caption: `> ${result.title}`
                }, { quoted: message });
            } else {
                await sock.sendMessage(remoteJid, {
                    text: `> ${result.title}`
                }, { quoted: message });
            }
            
            // Kirim audio
            await sock.sendMessage(remoteJid, {
                audio: result.buffer,
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: message });
        }

        // React sukses
        await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('Error play:', error);
        
        await sock.sendMessage(remoteJid, { 
            react: { text: '❌', key: message.key } 
        }).catch(() => {});
        
        await sock.sendMessage(remoteJid, {
            text: `❌ Gagal memutar lagu: ${error.message || 'Coba lagi nanti'}\n\n💡 Pastikan judul lagu benar dan koneksi internet stabil.`
        }, { quoted: message });
    }
}

export default {
    handle,
    Commands: ['spotplay', 'spotify', 'play'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1
};