// plugins/pin.js

import { searchPinterest } from "../../api/pin.js";
import { createZip } from "../../api/support/archiver.js";
import { sendHelpCard } from "../../case/help.js";
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.resolve(__dirname, '../../');
const tempDir = path.join(rootDir, 'storage', 'temp');

// Pastikan folder temp ada
if (!fs.existsSync(tempDir)) {
    fs.mkdirSync(tempDir, { recursive: true });
}

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo;

    try {
        // Parse query dan angka
        let query = content && content.trim() !== "" ? content : isQuoted?.text ?? null;
        let previewCount = 4; // Default 4 gambar
        
        if (query) {
            // Cek apakah ada angka di awal query (contoh: "3 kucing")
            const match = query.match(/^(\d+)\s+(.+)$/);
            if (match) {
                let requestedCount = parseInt(match[1]);
                previewCount = Math.min(requestedCount, 10); // Max 10 gambar total
                query = match[2]; // Sisanya adalah query sebenarnya
            }
        }

        // ===============================
        // CEK APAKAH USER MINTA BANTUAN
        // ===============================
        if (!query) {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: false,
                needText: true,
                example: "kucing",
                description: "Cari gambar dari Pinterest dengan mudah!\n\n✨ Fitur:\n• Default: 4 gambar langsung dikirim\n• Bisa request jumlah (max 10 gambar)\n• Gambar sisanya dalam bentuk ZIP\n• Kualitas HD\n\n📝 Format:\n• Default: ${prefix + command} kucing\n• Dengan jumlah: ${prefix + command} 7 kucing",
                notes: "Makin spesifik keyword, makin relevan hasilnya!",
                limits: "1 poin"
            });
        }

        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        // Ambil gambar dari API
        const images = await searchPinterest(query);
        
        if (!images || images.length === 0) {
            throw new Error("Tidak ada hasil gambar untuk keyword: " + query);
        }

        // Batasi total gambar maksimal 10
        const maxTotal = 10;
        const totalAvailable = Math.min(images.length, maxTotal);
        const previewActual = Math.min(previewCount, totalAvailable);
        const remainingCount = totalAvailable - previewActual;

        console.log(`📊 Query: ${query}, Preview: ${previewActual}, Remaining: ${remainingCount}, Total: ${totalAvailable}`);

        // Kirim preview gambar (tanpa caption)
        for (let i = 0; i < previewActual; i++) {
            await sock.sendMessage(remoteJid, {
                image: { url: images[i] }
            }, { quoted: message });
            await new Promise(resolve => setTimeout(resolve, 200)); // Delay untuk album effect
        }

        // Kirim ZIP untuk sisanya (jika ada)
        if (remainingCount > 0) {
            // Download gambar sisanya
            const sessionDir = path.join(tempDir, `pin_${Date.now()}`);
            fs.mkdirSync(sessionDir, { recursive: true });

            const imageFiles = [];
            for (let i = previewActual; i < totalAvailable; i++) {
                try {
                    const res = await fetch(images[i]);
                    const buffer = await res.arrayBuffer();
                    const filePath = path.join(sessionDir, `${i+1}.jpg`);
                    fs.writeFileSync(filePath, Buffer.from(buffer));
                    imageFiles.push(filePath);
                } catch (e) {
                    console.log(`❌ Gagal download gambar ${i+1}: ${e.message}`);
                }
            }

            if (imageFiles.length > 0) {
                // Buat zip
                const zipName = `${query.replace(/[^a-z0-9]/gi, '_')}_${Date.now()}.zip`;
                const zipPath = path.join(tempDir, zipName);
                const zip = await createZip(imageFiles, zipPath);

                // Kirim zip dengan caption
                await sock.sendMessage(remoteJid, {
                    document: fs.readFileSync(zip.path),
                    fileName: `${query}.zip`,
                    mimetype: 'application/zip',
                    caption: `🔍 *${query}*\n📸 Total: ${totalAvailable} gambar\n📦 Sisanya: ${imageFiles.length} gambar dalam ZIP\n\n*Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`
                }, { quoted: message });

                // Bersihkan file temporary
                fs.rmSync(sessionDir, { recursive: true, force: true });
                fs.unlinkSync(zip.path);
            }
        }

        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        console.error('Error Pinterest:', error);
        
        await sock.sendMessage(remoteJid, { 
            react: { text: "❌", key: message.key } 
        }).catch(() => {});
        
        await sock.sendMessage(remoteJid, { 
            text: `❌ Gagal mencari gambar: ${error.message}\n\n💡 Coba keyword yang lebih spesifik.` 
        }, { quoted: message });
    }
}

export default {
    handle,
    Commands: ["pin", "pinterest"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1
};