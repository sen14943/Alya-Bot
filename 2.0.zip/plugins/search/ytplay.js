// plugins/play.js
import fs from 'fs';
import os from 'os';
import crypto from 'crypto';
import path from 'path';
import ff from 'fluent-ffmpeg';
import { path as ffmpegPath } from '@ffmpeg-installer/ffmpeg';
import { ytmp3ByQuery, ytmp4ByQuery } from '../../api/ytdl/ytdl.js';
import { smartCompress, shouldCompress } from '../../src/lib/mp4lite.js';
import { sendHelpCard } from '../../case/help.js';

ff.setFfmpegPath(ffmpegPath);

/**
 * Ekstrak audio dari video buffer menggunakan ffmpeg
 * @param {Buffer} videoBuffer - Buffer video MP4
 * @returns {Promise<Buffer>} - Buffer audio MP3
 */
async function extractAudioFromVideo(videoBuffer) {
    const tmpFileIn = path.join(os.tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp4`);
    const tmpFileOut = path.join(os.tmpdir(), `${crypto.randomBytes(6).readUIntLE(0, 6).toString(36)}.mp3`);
    
    try {
        fs.writeFileSync(tmpFileIn, videoBuffer);
        
        await new Promise((resolve, reject) => {
            ff(tmpFileIn)
                .on("error", reject)
                .on("end", () => resolve(true))
                .output(tmpFileOut)
                .audioCodec('libmp3lame')
                .audioBitrate('128k')
                .toFormat('mp3')
                .run();
        });
        
        const audioBuffer = fs.readFileSync(tmpFileOut);
        fs.unlinkSync(tmpFileIn);
        fs.unlinkSync(tmpFileOut);
        
        return audioBuffer;
        
    } catch (error) {
        console.error('❌ Ekstrak audio gagal:', error.message);
        try {
            if (fs.existsSync(tmpFileIn)) fs.unlinkSync(tmpFileIn);
            if (fs.existsSync(tmpFileOut)) fs.unlinkSync(tmpFileOut);
        } catch (e) {}
        throw error;
    }
}

async function handle(sock, messageInfo) {
    const { m, remoteJid, message, content, prefix, command } = messageInfo;

    try {
        let query = content?.trim();
        
        // ===============================
        // CEK APAKAH USER MINTA BANTUAN
        // ===============================
        if (!query) {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: false,
                needText: true,
                example: "faded alan walker",
                description: command === 'ytplay' 
                    ? "Download dan putar video dari YouTube!\n\n✨ Fitur:\n• Download video MP4 kualitas bagus\n• Auto kompres jika >10MB\n• Sertakan audio MP3 juga\n• Kirim video langsung ke chat\n\n📝 Format: ${prefix + command} [judul lagu/video]\n📌 Contoh: ${prefix + command} faded alan walker"
                    : "Download dan putar audio dari YouTube!\n\n✨ Fitur:\n• Download audio MP3 kualitas bagus\n• Kirim thumbnail lagu\n• Judul lagu sebagai caption\n• Support berbagai format\n\n📝 Format: ${prefix + command} [judul lagu]\n📌 Contoh: ${prefix + command} faded alan walker",
                notes: "Pastikan koneksi internet stabil untuk download yang cepat!",
                limits: "3 poin"
            });
        }

        // React loading
        await sock.sendMessage(remoteJid, { react: { text: '🔍', key: message.key } });

        const isVideo = command === 'ytplay';

        if (isVideo) {
            // ============ VIDEO MODE (ytplay) ============
            const result = await ytmp4ByQuery(query);
            
            // React download
            await sock.sendMessage(remoteJid, { react: { text: '⬇️', key: message.key } });
            
            // Kompres video jika perlu
            let videoBuffer = result.buffer;
            const originalSize = videoBuffer.length / (1024 * 1024);
            
            if (shouldCompress(videoBuffer, 10)) {
                console.log(`🗜️ Kompres video: ${originalSize.toFixed(2)}MB → target <10MB`);
                await sock.sendMessage(remoteJid, { react: { text: '🗜️', key: message.key } });
                
                videoBuffer = await smartCompress(videoBuffer, 10);
                const compressedSize = videoBuffer.length / (1024 * 1024);
                console.log(`✅ Kompres selesai: ${originalSize.toFixed(2)}MB → ${compressedSize.toFixed(2)}MB`);
            } else {
                console.log(`✅ Video ukuran ${originalSize.toFixed(2)}MB, tidak perlu kompres`);
            }
            
            // Cari title untuk caption
            const { searchTopVideo } = await import('../../api/ytdl/search.js');
            const videoInfo = await searchTopVideo(query);
            const videoTitle = videoInfo.title || result.title || 'Video';
            
            // Kirim video dengan caption (REPLY ke pesan user)
            await sock.sendMessage(remoteJid, {
                video: videoBuffer,
                mimetype: 'video/mp4',
                caption: `🎬 *${videoTitle}*\n\n📥 *Downloaded by:* Lara AI`
            }, { quoted: message });
            
            // EXTRA: Kirim audio juga (convert dari video)
            try {
                console.log('🎵 Mengekstrak audio dari video...');
                await sock.sendMessage(remoteJid, { react: { text: '🎵', key: message.key } });
                
                const audioBuffer = await extractAudioFromVideo(videoBuffer);
                
                if (audioBuffer && audioBuffer.length >= 50 * 1024) {
                    await sock.sendMessage(remoteJid, {
                        audio: audioBuffer,
                        fileName: `${videoTitle.replace(/[^a-z0-9]/gi, '_')}.mp3`,
                        mimetype: 'audio/mpeg',
                        ptt: false
                    }, { quoted: message });
                    
                    console.log(`✅ Audio terkirim: ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB`);
                } else {
                    console.log('⚠️ Gagal ekstrak audio, ukuran terlalu kecil');
                }
                
            } catch (audioError) {
                console.log('⚠️ Gagal ekstrak audio:', audioError.message);
                // Lanjutkan tanpa audio
            }
            
        } else {
            // ============ AUDIO MODE (play) ============
            const result = await ytmp3ByQuery(query);
            
            // React download
            await sock.sendMessage(remoteJid, { react: { text: '⬇️', key: message.key } });
            
            // Kirim thumbnail + caption title
            if (result.thumbnail) {
                await sock.sendMessage(remoteJid, {
                    image: { url: result.thumbnail },
                    caption: `🎵 *Hasil Pencarian Lara*\n\n📌 *Title:* ${result.title}`
                }, { quoted: message });
            } else {
                await sock.sendMessage(remoteJid, {
                    text: `🎵 *Memutar Lagu...*\n📌 *Title:* ${result.title}`
                }, { quoted: message });
            }
            
            // Kirim audio
            await sock.sendMessage(remoteJid, {
                audio: result.buffer,
                mimetype: 'audio/mpeg',
                ptt: false
            }, { quoted: message });
        }

        // React sukses
        await sock.sendMessage(remoteJid, { react: { text: '✅', key: message.key } });

    } catch (error) {
        console.error('Error play:', error);
        
        await sock.sendMessage(remoteJid, { 
            react: { text: '❌', key: message.key } 
        }).catch(() => {});
        
        await sock.sendMessage(remoteJid, {
            text: `❌ *Error:* ${error.message || 'Gagal memutar lagu/video'}\n\n💡 Pastikan judul benar dan koneksi internet stabil.`
        }, { quoted: message });
    }
}

export default {
    handle,
    Commands: ['play', 'ytplay'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 3
};