import { getGroupMetadata } from "../../src/lib/cache.js";
import { downloadQuotedMedia, downloadMedia } from "../../src/lib/utils.js";
import fs from "fs";
import fsPromise from "fs/promises";
import { isOwner } from "../../src/lib/users.js";

// Store untuk menyimpan interval broadcast aktif
const activeBroadcasts = new Map();

async function delay(sec) {
  return new Promise(r => setTimeout(r, sec * 1000));
}

// Fungsi untuk mendapatkan semua grup
async function getAllGroups(sock) {
  const groups = await sock.groupFetchAllParticipating();
  return Object.keys(groups);
}

// Fungsi untuk mendapatkan grup random
function getRandomGroups(groups, count = 1) {
  const shuffled = [...groups].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, count);
}

// Fungsi untuk memproses media
async function processMedia(message, isQuoted, type) {
  const mediaType = isQuoted 
    ? `${isQuoted.type}Message` 
    : `${type}Message`;

  if (mediaType === "imageMessage") {
    const mediaPath = isQuoted
      ? await downloadQuotedMedia(message)
      : await downloadMedia(message);
    return {
      buffer: fs.readFileSync(mediaPath),
      type: "image"
    };
  }
  
  if (mediaType === "videoMessage") {
    const mediaPath = isQuoted
      ? await downloadQuotedMedia(message)
      : await downloadMedia(message);
    return {
      buffer: fs.readFileSync(mediaPath),
      type: "video"
    };
  }

  if (mediaType === "stickerMessage") {
    const mediaPath = isQuoted
      ? await downloadQuotedMedia(message)
      : await downloadMedia(message);
    return {
      buffer: fs.readFileSync(mediaPath),
      type: "sticker"
    };
  }

  return null;
}

// Fungsi untuk membuat pesan berdasarkan media
function createMessage(media, text) {
  if (!media) return { text };

  switch(media.type) {
    case "image":
      return { image: media.buffer, caption: text };
    case "video":
      return { video: media.buffer, caption: text };
    case "sticker":
      return { sticker: media.buffer };
    default:
      return { text };
  }
}

// Fungsi untuk broadcast satu kali
async function broadcastOnce(sock, remoteJid, message, text, media) {
  try {
    const groups = await getAllGroups(sock);
    
    if (groups.length === 0) {
      await sock.sendMessage(
        remoteJid,
        { text: "❌ Bot tidak ada di grup mana pun" },
        { quoted: message }
      );
      return;
    }

    const msg = createMessage(media, text);
    let success = 0;

    for (const gc of groups) {
      try {
        await sock.sendMessage(gc, msg);
        success++;
      } catch (err) {
        console.error(`Gagal kirim ke ${gc}:`, err);
      }
      await delay(6); // Jeda 6 detik
    }

    await sock.sendMessage(
      remoteJid,
      { text: `✅ Broadcast terkirim ke ${success} dari ${groups.length} grup` },
      { quoted: message }
    );

  } catch (err) {
    console.error("Error broadcastOnce:", err);
    throw err;
  }
}

// Fungsi untuk broadcast berulang
async function startRecurringBroadcast(sock, remoteJid, message, text, media, intervalHours = 1) {
  const broadcastId = `${remoteJid}_${Date.now()}`;
  const intervalMs = intervalHours * 60 * 60 * 1000; // Konversi jam ke ms

  // Fungsi untuk mengirim ke random grup
  const sendToRandomGroups = async () => {
    try {
      const allGroups = await getAllGroups(sock);
      if (allGroups.length === 0) return;

      // Pilih 1-3 grup random
      const randomGroups = getRandomGroups(allGroups, Math.floor(Math.random() * 3) + 1);
      const msg = createMessage(media, text);
      
      let success = 0;
      for (const gc of randomGroups) {
        try {
          await sock.sendMessage(gc, msg);
          success++;
        } catch (err) {
          console.error(`Gagal kirim ke ${gc}:`, err);
        }
        await delay(10); // Jeda lebih lama 10 detik
      }

      // Notifikasi ke pengirim (opsional, bisa di-comment jika terlalu spam)
      await sock.sendMessage(
        remoteJid,
        { text: `🔄 Broadcast berulang: Terkirim ke ${success} grup random` },
        { quoted: message }
      );

    } catch (err) {
      console.error("Error recurring broadcast:", err);
    }
  };

  // Kirim pertama kali
  await sendToRandomGroups();

  // Set interval untuk pengiriman berikutnya
  const interval = setInterval(sendToRandomGroups, intervalMs);
  
  // Simpan interval
  if (!activeBroadcasts.has(remoteJid)) {
    activeBroadcasts.set(remoteJid, new Map());
  }
  activeBroadcasts.get(remoteJid).set(broadcastId, interval);

  return broadcastId;
}

// Handler utama
async function handle(sock, messageInfo) {
  const {
    remoteJid,
    message,
    content,
    prefix,
    command,
    isQuoted,
    type,
    sender
  } = messageInfo;

  // Cek owner
  if (!isOwner(sender)) {
    await sock.sendMessage(
      remoteJid,
      { text: "❌ Perintah ini hanya untuk owner bot" },
      { quoted: message }
    );
    return;
  }

  try {
    // Handle stopbc
    if (command === "stopbc") {
      const userBroadcasts = activeBroadcasts.get(remoteJid);
      if (!userBroadcasts || userBroadcasts.size === 0) {
        await sock.sendMessage(
          remoteJid,
          { text: "❌ Tidak ada broadcast aktif" },
          { quoted: message }
        );
        return;
      }

      // Hentikan semua interval
      for (const [id, interval] of userBroadcasts) {
        clearInterval(interval);
      }
      activeBroadcasts.delete(remoteJid);

      await sock.sendMessage(
        remoteJid,
        { text: "✅ Semua broadcast berulang telah dihentikan" },
        { quoted: message }
      );
      return;
    }

    // Handle addbc (broadcast berulang)
    if (command === "addbc") {
      if (!content || !content.trim()) {
        return sock.sendMessage(
          remoteJid,
          {
            text: `⚠️ Contoh:\n${prefix + command} teks broadcast\nAtau reply media dengan caption`
          },
          { quoted: message }
        );
      }

      const args = content.trim().split(' ');
      let text = content.trim();
      let intervalHours = 1; // Default 1 jam

      // Cek apakah ada argumen jam di akhir
      const lastArg = args[args.length - 1];
      if (!isNaN(lastArg) && lastArg > 0) {
        intervalHours = parseInt(lastArg);
        text = args.slice(0, -1).join(' ');
      }

      // Proses media jika ada
      const media = await processMedia(message, isQuoted, type);
      
      // Kirim reaksi
      await sock.sendMessage(remoteJid, {
        react: { text: "🔄", key: message.key }
      });

      // Mulai broadcast berulang
      const broadcastId = await startRecurringBroadcast(
        sock, 
        remoteJid, 
        message, 
        text, 
        media, 
        intervalHours
      );

      await sock.sendMessage(
        remoteJid,
        { 
          text: `✅ Broadcast berulang dimulai\n• Interval: ${intervalHours} jam\n• ID: ${broadcastId}\nKetik *stopbc* untuk menghentikan` 
        },
        { quoted: message }
      );
      return;
    }

    // Handle bc (broadcast biasa)
    if (command === "bc" || command === "broadcast") {
      if (!content || !content.trim()) {
        return sock.sendMessage(
          remoteJid,
          {
            text: `⚠️ Contoh:\n${prefix + command} teks broadcast\nAtau reply media dengan caption`
          },
          { quoted: message }
        );
      }

      const text = content.trim();

      // Proses media jika ada
      const media = await processMedia(message, isQuoted, type);

      // Kirim reaksi
      await sock.sendMessage(remoteJid, {
        react: { text: "🚀", key: message.key }
      });

      // Lakukan broadcast sekali
      await broadcastOnce(sock, remoteJid, message, text, media);
    }

  } catch (err) {
    console.error("Error in broadcast handler:", err);
    await sock.sendMessage(
      remoteJid,
      { text: "❌ Error saat memproses broadcast" },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["bc", "broadcast", "addbc", "stopbc"],
  OnlyOwner: true
};