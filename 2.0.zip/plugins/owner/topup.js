import { findUser, updateUser } from "../../src/lib/users.js";
import { sendMessageWithMention, convertToJid } from "../../src/lib/utils.js";
import saldo from "../../src/lib/saldo.js";

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command, senderType } = messageInfo;

  // --- Validasi input ---
  if (!content?.trim()) {
    const tex =
      `_⚠️ Format: *${prefix + command} tag 50*_\n\n` +
      `_💬 Contoh: *${prefix + command} @tag 50_ (nambah Rp ${saldo.limitToRupiah(50).toLocaleString('id-ID')})_`;
    return sock.sendMessage(remoteJid, { text: tex }, { quoted: message });
  }

  // Pisahkan target dan jumlah (dalam RUPIAH)
  const [rawNumber, rawRupiah] = content.split(" ").map((s) => s.trim());

  if (!rawNumber || !rawRupiah) {
    return sock.sendMessage(
      remoteJid,
      {
        text: `_Masukkan format yang benar_\n\n_Contoh: *${prefix + command} @tag 50*_ (nambah Rp 50)`,
      },
      { quoted: message }
    );
  }

  // Validasi jumlah rupiah
  const rupiahToAdd = parseInt(rawRupiah, 10);
  if (isNaN(rupiahToAdd) || rupiahToAdd <= 0) {
    return sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ _Jumlah harus berupa angka positif (dalam Rupiah)_\n\n_Contoh: *${prefix + command} @tag 5000*_`,
      },
      { quoted: message }
    );
  }

  // Konversi Rupiah ke Limit (karena limit di database tetap pakai satuan limit)
  const rate = saldo.getRate();
  const limitPerRupiah = rate.dapat / rate.harga;  // 1/7 = 0.142857 limit per rupiah
  let limitToAdd = rupiahToAdd * limitPerRupiah;
  
  // Potong 3 desimal biar rapi
  limitToAdd = Math.floor(limitToAdd * 1000) / 1000;

  // --- Cek user ---
  let dataUsers = await findUser(rawNumber);
  let userJid = rawNumber;

  if (!dataUsers) {
    // Jika tidak ketemu, coba dengan JID
    const r = await convertToJid(sock, rawNumber);
    userJid = r;
    dataUsers = await findUser(r);

    if (!dataUsers) {
      return sock.sendMessage(
        remoteJid,
        {
          text: `⚠️ _Pengguna dengan username/id ${rawNumber} tidak ditemukan._`,
        },
        { quoted: message }
      );
    }
  }

  const [docId, userData] = dataUsers;

  // --- Update data user (tambah limit versi desimal) ---
  await updateUser(userJid, {
    limit: (userData.limit || 0) + limitToAdd,
  });

  // --- Kirim pesan konfirmasi dalam RUPIAH ---
  await sendMessageWithMention(
    sock,
    remoteJid,
    `✅ _Saldo berhasil ditambahkan Rp ${rupiahToAdd.toLocaleString('id-ID')}_`,
    message,
    senderType
  );
}

export default {
  handle,
  Commands: ["addsaldo", "topup"],
  OnlyPremium: false,
  OnlyOwner: true,
};