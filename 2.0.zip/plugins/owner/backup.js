import { createBackup } from "../../src/lib/utils.js";
import config from "../../config.js";

// Data owner (salin dari file utama)
const DATA_OWNER = ["6285126189342", "628988838767"];

// Fungsi untuk mengirim ke semua owner
async function sendToAllOwners(sock, message, quoted = null) {
  for (const owner of DATA_OWNER) {
    try {
      await sock.sendMessage(`${owner}@s.whatsapp.net`, message, { quoted });
      // Delay 1 detik antar pengiriman
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (e) {
      console.log(`Gagal kirim pesan ke owner ${owner}:`, e.message);
    }
  }
}

async function handle(sock, messageInfo) {
  const { remoteJid, message } = messageInfo;
  
  try {
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    const backupFilePath = await createBackup();

    // Kirim konfirmasi ke chat yang memerintahkan backup
    await sock.sendMessage(
      remoteJid,
      {
        text: `✅ _Berhasil, data backup telah disimpan dan terkirim ke semua owner_

Size : ${backupFilePath.size}
Time : ${backupFilePath.time}
`,
      },
      { quoted: message }
    );

    const documentPath = backupFilePath.path;

    // Kirim file backup ke SEMUA owner (bukan hanya bot)
    await sendToAllOwners(
      sock,
      {
        document: { url: documentPath },
        fileName: `Backup_${backupFilePath.time.replace(/[/: ]/g, '_')}.zip`,
        mimetype: "application/zip",
        caption: `📦 *File Backup LaraBot*\n\n` +
                 `📊 *Informasi Backup:*\n` +
                 `• Ukuran: ${backupFilePath.size}\n` +
                 `• Waktu: ${backupFilePath.time}\n` +
                 `• Dibuat oleh: @${remoteJid.split('@')[0]}\n\n` +
                 `_Simpan file ini dengan baik untuk berjaga-jaga._`,
        mentions: [remoteJid]
      }
    );
    
  } catch (err) {
    console.error("Backup failed:", err);

    await sock.sendMessage(
      remoteJid,
      {
        text: `❌ _Gagal melakukan backup:_ ${err.message}`,
      },
      { quoted: message }
    );
    
    // Opsional: kirim notifikasi error ke owner juga
    await sendToAllOwners(
      sock,
      {
        text: `⚠️ *Gagal Backup*\n\n` +
               `Error: ${err.message}\n` +
               `Diminta oleh: @${remoteJid.split('@')[0]}`,
        mentions: [remoteJid]
      }
    );
  }
}

export default {
  handle,
  Commands: ["backup"],
  OnlyPremium: false,
  OnlyOwner: true,
};