import config from "../../config.js";
import { sendImageAsSticker } from "../../src/lib/exif.js";
import { logCustom } from "../../src/lib/logger.js";
import { generateBratSticker } from "../../api/canvas/brat.js";
import { sendHelpCard } from "../../case/help.js";

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim() === "") {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: false,
            needText: true,
            example: "kamu sayang aku ngga?",
            description: "Buat sticker BRAT keren dengan teks custom!\n\n✨ Fitur:\n• Teks besar dengan gaya BRAT\n• Background aesthetic\n• Langsung jadi sticker\n• Cocok untuk ekspresi lucu atau sindiran",
            notes: "Makin pendek dan lucu teksnya, makin keren stickernya!",
            limits: "2 poin"
        });
    }

    try {
        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        const buffer = await generateBratSticker(content.trim());

        const options = {
            packname: config.sticker_packname,
            author: config.sticker_author,
        };

        await sendImageAsSticker(sock, remoteJid, buffer, options, message);

        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        console.error('Error in brat command:', error);
        logCustom("info", content, `ERROR-COMMAND-${command}.txt`);
        
        await sock.sendMessage(remoteJid, { 
            react: { text: "❌", key: message.key } 
        }).catch(() => {});
        
        await sock.sendMessage(remoteJid, { 
            text: `❌ Gagal membuat sticker BRAT: ${error.message}\n\n💡 Silakan coba lagi dengan teks yang berbeda.` 
        }, { quoted: message });
    }
}

export default {
    handle,
    Commands: ["brat"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 2,
};