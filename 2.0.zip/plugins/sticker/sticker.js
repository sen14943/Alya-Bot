import { downloadQuotedMedia, downloadMedia } from "../../src/lib/utils.js";
import { sendImageAsSticker } from "../../src/lib/exif.js";
import { sendHelpCard } from "../../case/help.js";
import config from "../../config.js";
import sharp from "sharp";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import ffmpeg from "fluent-ffmpeg";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ==================== KONFIGURASI FONT E PEP ====================
const fontPaths = [
    path.join(process.cwd(), 'assets/fonts/Epep.ttf'),
    path.join(process.cwd(), 'assets/fonts/epep.ttf'),
    path.join(process.cwd(), 'Assets/Fonts/Epep.ttf'),
    path.join(process.cwd(), 'Assets/Fonts/epep.ttf'),
    path.join(__dirname, '../../assets/fonts/Epep.ttf'),
    path.join(__dirname, '../../Assets/Fonts/Epep.ttf'),
];

let FONT_PATH = null;
for (const fontPath of fontPaths) {
    if (fs.existsSync(fontPath)) {
        FONT_PATH = fontPath;
        console.log('[SMEME] ✅ Font Epep ditemukan:', FONT_PATH);
        break;
    }
}

if (!FONT_PATH) {
    console.log('[SMEME] ⚠️ Font Epep tidak ditemukan, pake fallback Arial');
}

const TMP_FOLDER = path.resolve("./storage/tmp");
const MEDIA_FOLDER = path.resolve("./assets/media");

// Pastikan folder tmp ada
if (!fs.existsSync(TMP_FOLDER)) {
    fs.mkdirSync(TMP_FOLDER, { recursive: true });
}

function waitFile(file, timeout = 3000) {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        const interval = setInterval(() => {
            if (fs.existsSync(file)) {
                clearInterval(interval);
                resolve(true);
            }
            if (Date.now() - start > timeout) {
                clearInterval(interval);
                reject(new Error("Timeout menunggu file"));
            }
        }, 100);
    });
}

function getTextWidth(text, fontSize) {
    const charWidth = fontSize * 0.65;
    return text.length * charWidth;
}

function calculateFontSize(text, maxWidth, maxFontSize = 72, minFontSize = 28) {
    if (!text || text.length === 0) return maxFontSize;

    let fontSize = maxFontSize;

    while (fontSize >= minFontSize) {
        const textWidth = getTextWidth(text, fontSize);
        if (textWidth <= maxWidth) {
            return fontSize;
        }
        fontSize -= 2;
    }

    return minFontSize;
}

function wrapText(text, maxWidth, fontSize) {
    if (!text || text.length === 0) return [];

    const charWidth = fontSize * 0.55;
    const maxCharsPerLine = Math.floor(maxWidth / charWidth);

    if (text.length <= maxCharsPerLine) {
        return [text];
    }

    const words = text.split(' ');
    const lines = [];
    let currentLine = '';

    for (const word of words) {
        const testLine = currentLine ? `${currentLine} ${word}` : word;
        if (testLine.length <= maxCharsPerLine) {
            currentLine = testLine;
        } else {
            if (currentLine) lines.push(currentLine);
            currentLine = word;
        }
    }
    if (currentLine) lines.push(currentLine);

    return lines.slice(0, 3);
}

function createMultiLineText(lines, fontSize, lineHeight, startY) {
    if (!lines || lines.length === 0) return '';

    let svg = '';
    const totalHeight = lines.length * lineHeight;
    let currentY = startY - (totalHeight / 2) + (lineHeight / 2);
    const shadowOffset = Math.max(3, Math.floor(fontSize / 18));
    const shadowBlur = Math.max(3, Math.floor(fontSize / 25));

    const fontFamily = FONT_PATH ? 'Epep, Arial, Helvetica, sans-serif' : 'Arial, Helvetica, sans-serif';

    svg += `
    <defs>
        <filter id="shadow" x="-30%" y="-30%" width="196%" height="196%">
            <feDropShadow dx="${shadowOffset}" dy="${shadowOffset}" stdDeviation="${shadowBlur}" flood-color="#000000" flood-opacity="0.85"/>
        </filter>
    </defs>
    `;

    lines.forEach((line, index) => {
        const escapedLine = line.replace(/[&<>]/g, function (m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            return m;
        });

        svg += `
        <text x="50%" y="${currentY + (index * lineHeight)}" 
              text-anchor="middle" dominant-baseline="middle"
              font-size="${fontSize}px" 
              font-family="${fontFamily}"
              font-weight="900"
              fill="#FFFFFF"
              filter="url(#shadow)">
            ${escapedLine}
        </text>
        `;
    });

    return svg;
}

function countWords(text) {
    if (!text) return 0;
    return text.trim().split(/\s+/).filter(word => word.length > 0).length;
}

async function convertStickerToImage(mediaPath) {
    const outputPath = path.join(TMP_FOLDER, `toimg_${Date.now()}.png`);

    await new Promise((resolve, reject) => {
        ffmpeg(mediaPath)
            .outputOptions("-vframes", "1")
            .output(outputPath)
            .on("end", () => resolve())
            .on("error", (err) => reject(err))
            .run();
    });

    if (!fs.existsSync(outputPath)) {
        throw new Error("Gagal mengkonversi sticker ke gambar");
    }

    const imageBuffer = fs.readFileSync(outputPath);

    try {
        if (fs.existsSync(outputPath)) fs.unlinkSync(outputPath);
    } catch (e) { }

    return imageBuffer;
}

async function downloadMediaAsBuffer(messageInfo, isQuoted, message) {
    const mediaName = isQuoted
        ? await downloadQuotedMedia(message)
        : await downloadMedia(message);

    if (!mediaName) {
        throw new Error("Gagal mendownload media");
    }

    let mediaPath = path.join(TMP_FOLDER, mediaName);
    if (!fs.existsSync(mediaPath)) {
        mediaPath = path.join(MEDIA_FOLDER, mediaName);
    }

    if (!fs.existsSync(mediaPath)) {
        throw new Error("File media tidak ditemukan setelah diunduh.");
    }

    await waitFile(mediaPath);

    const isSticker = mediaPath.endsWith('.webp');
    let buffer;

    if (isSticker) {
        console.log("🔄 Mengkonversi sticker ke gambar...");
        buffer = await convertStickerToImage(mediaPath);
    } else {
        buffer = fs.readFileSync(mediaPath);
    }

    try {
        if (fs.existsSync(mediaPath)) fs.unlinkSync(mediaPath);
    } catch (e) { }

    return { buffer, isSticker };
}

async function handle(sock, messageInfo) {
    const { remoteJid, message, type, isQuoted, prefix, command, content } = messageInfo;

    try {
        const hasText = content && content.trim().length > 0;
        const mediaType = isQuoted ? isQuoted.type : type;

        // ===============================
        // CEK APAKAH USER MINTA BANTUAN
        // ===============================
        if (!hasText && !["image", "sticker"].includes(mediaType)) {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: true,
                needText: true,
                example: "saya suka | kamu hebat",
                description: "Buat stiker meme keren dari gambar atau sticker!\n\n✨ Fitur:\n• Tambah teks atas/bawah\n• Support gambar & sticker\n• Font keren Epep\n• Maksimal 3 kata per bagian\n\n📝 Format: teks atas | teks bawah\n📌 Contoh: .s saya suka | kamu hebat",
                notes: "Pisahkan teks atas dan bawah dengan tanda | (vertical bar)",
                limits: "1"
            });
        }

        let topText = "";
        let bottomText = "";

        if (hasText) {
            const parts = content.split("|");
            if (parts.length >= 1) {
                topText = parts[0]?.trim() || "";
            }
            if (parts.length >= 2) {
                bottomText = parts[1]?.trim() || "";
            }
            if (parts.length === 1 && !content.includes("|")) {
                topText = content.trim();
                bottomText = "";
            }

            const topWordCount = countWords(topText);
            const bottomWordCount = countWords(bottomText);

            if (topWordCount > 3 || bottomWordCount > 3) {
                await sock.sendMessage(remoteJid, {
                    react: { text: "❌", key: message.key },
                });
                return sock.sendMessage(
                    remoteJid,
                    {
                        text: `❌ *Maksimal 3 kata per bagian!*\n\n📝 *Aturan:*\n• Atas: maksimal 3 kata\n• Bawah: maksimal 3 kata\n\n📌 *Contoh:*\n${prefix + command} saya suka | kamu hebat\n\n🖼️ *Support:*\n• Gambar\n• Sticker (otomatis dikonversi)`
                    },
                    { quoted: message }
                );
            }
        }

        if (mediaType !== "image" && mediaType !== "sticker") {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: true,
                needText: true,
                example: "saya suka | kamu hebat",
                description: "Buat stiker meme keren dari gambar atau sticker!\n\n📝 Format: teks atas | teks bawah",
                notes: "Kirim atau reply gambar/sticker dengan caption",
                limits: "1"
            });
        }

        await sock.sendMessage(remoteJid, {
            react: { text: "⏰", key: message.key },
        });

        const { buffer: imageBuffer, isSticker } = await downloadMediaAsBuffer(
            messageInfo,
            isQuoted,
            message
        );

        if (isSticker) {
            await sock.sendMessage(remoteJid, {
                react: { text: "🔄", key: message.key },
            });
        }

        const targetSize = 512;
        let image = sharp(imageBuffer);

        image = image.resize(targetSize, targetSize, {
            fit: 'cover',
            position: 'centre'
        });

        let finalBuffer;

        if (!hasText) {
            finalBuffer = await image.webp().toBuffer();
        } else {
            const maxTextWidth = targetSize - 96;

            let topFontSize = topText ? calculateFontSize(topText, maxTextWidth, 64, 28) : 64;
            let bottomFontSize = bottomText ? calculateFontSize(bottomText, maxTextWidth, 64, 28) : 64;

            let fontSize = Math.min(topFontSize, bottomFontSize);
            fontSize = Math.max(28, fontSize);

            let lineHeight = fontSize * 1.3;

            let topLines = topText ? wrapText(topText, maxTextWidth, fontSize) : [];
            let bottomLines = bottomText ? wrapText(bottomText, maxTextWidth, fontSize) : [];

            while ((topLines.length > 2 || bottomLines.length > 2) && fontSize > 28) {
                fontSize -= 4;
                topLines = topText ? wrapText(topText, maxTextWidth, fontSize) : [];
                bottomLines = bottomText ? wrapText(bottomText, maxTextWidth, fontSize) : [];
            }

            const finalLineHeight = fontSize * 1.3;
            const finalTopHeight = topLines.length * finalLineHeight;
            const finalBottomHeight = bottomLines.length * finalLineHeight;

            let topYPosition = finalTopHeight / 2 + 40;
            let bottomYPosition = targetSize - (finalBottomHeight / 2) - 40;

            let svgOverlay = `<svg width="${targetSize}" height="${targetSize}" xmlns="http://www.w3.org/2000/svg">`;
            svgOverlay += createMultiLineText(topLines, fontSize, finalLineHeight, topYPosition);
            svgOverlay += createMultiLineText(bottomLines, fontSize, finalLineHeight, bottomYPosition);
            svgOverlay += `</svg>`;

            const textBuffer = Buffer.from(svgOverlay);
            finalBuffer = await image
                .composite([{ input: textBuffer, gravity: 'north' }])
                .webp()
                .toBuffer();
        }

        const options = {
            packname: config.sticker_packname,
            author: config.sticker_author,
        };

        await sendImageAsSticker(sock, remoteJid, finalBuffer, options, message);

        await sock.sendMessage(remoteJid, {
            react: { text: "✅", key: message.key },
        });

    } catch (err) {
        console.error("Smeme error:", err);
        await sock.sendMessage(remoteJid, {
            react: { text: "❌", key: message.key },
        });
        await sock.sendMessage(
            remoteJid,
            { text: "❌ Gagal membuat stiker meme.\n" + err.message },
            { quoted: message }
        );
    }
}

export default {
    handle,
    Commands: ["smeme", "s"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
};