import config from "../../config.js";
import { sendImageAsSticker } from "../../src/lib/exif.js";
import { logCustom } from "../../src/lib/logger.js";
import { generateBratVideoSticker } from "../../api/canvas/brat.js";
import { sendHelpCard } from "../../case/help.js";

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim() === "") {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: false,
            needText: true,
            example: "lu belajar",
            description: "Buat sticker video BRAT keren dengan teks custom!\n\n✨ Fitur:\n• Video aesthetic bergerak\n• Teks besar dengan gaya BRAT\n• Langsung jadi sticker bergerak\n• Cocok untuk sindiran lucu atau ekspresi kocak",
            notes: "Teks yang singkat dan lucu = hasil lebih keren!",
            limits: "3 poin"
        });
    }

    try {
        await sock.sendMessage(remoteJid, {
            react: { text: "🎬", key: message.key }
        });

        const buffer = await generateBratVideoSticker(content.trim());

        await sock.sendMessage(remoteJid, {
            react: { text: "🎨", key: message.key }
        });

        const options = {
            packname: config.sticker_packname || "Lumina AI",
            author: config.sticker_author || "@senmuz",
        };

        await sendImageAsSticker(sock, remoteJid, buffer, options, message);

        await sock.sendMessage(remoteJid, {
            react: { text: "✅", key: message.key }
        });

    } catch (error) {
        console.error('Error in bratvid command:', error);
        logCustom("info", content, `ERROR-COMMAND-${command}.txt`);
        
        await sock.sendMessage(remoteJid, {
            react: { text: "❌", key: message.key }
        }).catch(() => {});
        
        await sock.sendMessage(remoteJid, {
            text: `❌ Gagal membuat sticker video BRAT: ${error.message}\n\n💡 Silakan coba lagi dengan teks yang berbeda.`
        }, { quoted: message });
    }
}

export default {
    handle,
    Commands: ["bratvid"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 3,
};