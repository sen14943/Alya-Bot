import fs from 'fs';
import path from 'path';
import { downloadQuotedMedia, downloadMedia, reply } from '../../src/lib/utils.js';
import { sendHelpCard } from '../../case/help.js';
import { Sticker, StickerTypes } from 'wa-sticker-formatter';

async function handle(sock, messageInfo) {
  const { m, remoteJid, message, content, prefix, command, isQuoted, type } = messageInfo;
  const mediaType = isQuoted ? isQuoted.type : type;

  try {
    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || !content.trim()) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: true,
        needText: true,
        example: "Laura Bot | Angela",
        description: "Buat stiker dengan watermark custom dari gambar atau stiker!\n\n✨ Fitur:\n• Tambah nama pack (watermark)\n• Tambah nama author\n• Support gambar & stiker\n• Kualitas HD\n\n📝 Format teks:\n• Tanpa '|': ${prefix + command} NamaPack\n• Dengan '|': ${prefix + command} NamaPack | NamaAuthor",
        notes: "Makin unik nama pack & author, makin keren stickermu!",
        limits: "1 poin"
      });
    }

    // Parse packname dan author
    let packname = '';
    let author = '';
    
    if (content.includes('|')) {
      const parts = content.split('|').map((s) => s.trim());
      packname = parts[0] || '';
      author = parts[1] || '';
    } else {
      packname = content.trim();
      author = '';
    }

    // Validasi tipe media
    if (!['image', 'sticker'].includes(mediaType)) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: true,
        needText: true,
        example: "Laura Bot | Angela",
        description: "Kamu harus kirim atau balas GAMBAR atau STIKER!\n\n📝 Format: ${prefix + command} NamaPack | NamaAuthor",
        notes: "Kirim gambar/stiker + caption seperti contoh di atas",
        limits: "1 poin"
      });
    }

    // React loading
    await sock.sendMessage(remoteJid, { 
      react: { text: '🎨', key: message.key } 
    });

    // ===============================
    // DOWNLOAD MEDIA (Sesuai utils.js)
    // ===============================
    let media;
    try {
      // utils.js menggunakan folder default ./storage/tmp
      media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
    } catch (error) {
      console.error('Download error:', error);
      return await reply(m, '❌ Gagal mengunduh media.\nSilakan kirim ulang gambar/stiker.');
    }

    // Path folder temporary sesuai utils.js
    const tmpFolder = path.resolve('./storage/tmp');
    const mediaPath = path.join(tmpFolder, media);

    if (!fs.existsSync(mediaPath)) {
      return await reply(m, '❌ File media tidak ditemukan.\nSilakan kirim ulang gambar/stiker.');
    }

    // Update react
    await sock.sendMessage(remoteJid, { 
      react: { text: '🖼️', key: message.key } 
    });

    // ===============================
    // BUAT STIKER DENGAN WATERMARK
    // ===============================
    const sticker = new Sticker(mediaPath, {
      pack: packname || 'Laura Bot',
      author: author || 'Angela',
      type: StickerTypes.FULL,
      quality: 50,
    });

    const buffer = await sticker.toBuffer();

    // Hapus file temporary
    fs.unlink(mediaPath, () => {});

    // Kirim stiker
    await sock.sendMessage(remoteJid, { 
      sticker: buffer 
    }, { quoted: message });
    
    // React sukses
    await sock.sendMessage(remoteJid, { 
      react: { text: '✅', key: message.key } 
    });
    
  } catch (error) {
    console.error('Error in wm command:', error);
    
    // React error
    await sock.sendMessage(remoteJid, { 
      react: { text: '❌', key: message.key } 
    }).catch(() => {});
    
    await reply(
      m,
      `❌ *Terjadi kesalahan saat membuat stiker watermark*\n\n📌 *Error:* ${error.message}\n\nSilakan coba lagi nanti.`
    );
  }
}

export default {
  handle,
  Commands: ['wm', 'watermark', 'stickerwm', 'swm'],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};