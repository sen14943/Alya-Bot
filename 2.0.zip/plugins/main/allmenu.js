// handle/menu.js
import menuProxy, { loadMenuOnce } from '../../src/lib/menu.js';
import config from '../../config.js';
import { readFileAsBuffer } from '../../src/lib/fileHelper.js';
import { reply, style, getCurrentDate, readMore } from '../../src/lib/utils.js';
import { isOwner, isPremiumUser } from '../../src/lib/users.js';

/* =========================
   CONFIG
========================= */

const MENU_MEDIA_TYPE = 'image';
const MENU_MEDIA_FILE = '../../assets/media/allmenu.jpg';
const MENU_AUDIO_SIANG = '../../assets/audio/menuall.mp3';
const MENU_AUDIO_MALAM = '../../assets/audio/malam.mp3';

/* =========================
   HELPER
========================= */

function getUserRole(sender) {
  if (isOwner(sender)) return 'Owner';
  if (isPremiumUser(sender)) return 'Premium';
  return 'User';
}

function formatMenu(title, items) {
  const formattedItems = items.map((item) => {
    if (typeof item === 'string') return `│  ˖ ࣪ ݂ ✤ ${item}`;
    if (typeof item === 'object' && item.command && item.description) {
      return `│  ˖ ࣪ ݂ ✤ .${item.command} ${item.description}`;
    }
    return '│  ˖ ࣪ ݂ ✤ [Invalid item]';
  });

  return `
┌───〔 *${title.toUpperCase()}* 〕
│
${formattedItems.join('\n')}
╰────────────────────`;
}

function getDashboard(pushName, roleUser, date) {
  return `
╭──〔 *DASHBOARD* 〕
├❥ 
├⌬ NAMA : *${pushName || 'User'}*
├⌬ STATUS : *${roleUser}*
├⌬ DATE : *${date}*
├⌬ MODELS: *Prime*
├❥ 
╰───────────────────`;
}

function buildAllMenu(pushName, roleUser, date, menuData) {
  const dashboard = getDashboard(pushName, roleUser, date);
  
  const menuSections = Object.keys(menuData)
    .map((key) => formatMenu(key, menuData[key]))
    .join('\n\n');
  
  return dashboard + '\n\n' + menuSections;
}

function isDaytime() {
  const hour = new Date().getHours();
  // Siang: 06:00 - 17:59 (6 pagi - 5 sore)
  // Malam: 18:00 - 05:59 (6 sore - 5 pagi)
  return hour >= 6 && hour < 18;
}

function getAudioPath() {
  return isDaytime() ? MENU_AUDIO_SIANG : MENU_AUDIO_MALAM;
}

/* =========================
   MAIN HANDLER
========================= */

async function handle(sock, messageInfo) {
  const { m, remoteJid, pushName, sender, content, command, message } = messageInfo;

  const roleUser = getUserRole(sender);
  const date = getCurrentDate();
  const category = (content || '').toLowerCase();

  const menuData = await loadMenuOnce();

  /* ========= CATEGORY MENU ========= */

  if (category && menuData[category]) {
    const response = formatMenu(category, menuData[category]);
    await reply(m, style(response));
    return;
  }
  
  if (command === 'allmenu') {
    /* ========= ALL MENU ========= */
    const response = buildAllMenu(pushName, roleUser, date, menuData);
    const imageBuffer = await readFileAsBuffer(MENU_MEDIA_FILE);
    const audioPath = getAudioPath();
    
    let audioBuffer;
    try {
      audioBuffer = await readFileAsBuffer(audioPath);
    } catch (err) {
      console.error('Gagal load audio:', err.message);
      // Jika audio gagal, tetap lanjut tanpa audio
    }

    // Kirim gambar dengan caption
    let mediaMessage = {
      image: imageBuffer,
      caption: style(response),
      contextInfo: {
        mentionedJid: [sender],
      },
    };

    await sock.sendMessage(remoteJid, mediaMessage, { quoted: message });

    // Kirim audio jika berhasil di-load
    if (audioBuffer) {
      let audioMessage = {
        audio: audioBuffer,
        mimetype: 'audio/mpeg',
        ptt: false, // false = sebagai audio biasa, true = sebagai voice note
      };
      await sock.sendMessage(remoteJid, audioMessage, { quoted: message });
    }
  }
}

/* =========================
   EXPORT
========================= */

export default {
  Commands: ['allmenu'],
  OnlyPremium: false,
  OnlyOwner: false,
  handle,
};