// handle/menu.js
import { loadMenuOnce } from '../../src/lib/menu.js';
import { style, getCurrentDate, readMore } from '../../src/lib/utils.js';
import { isOwner, isPremiumUser } from '../../src/lib/users.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/* =========================
   CONFIG
========================= */

const MENU_MEDIA_FILE = '../../assets/media/allmenu.jpg';
const MENU_AUDIO_FILE = '../../assets/audio/menucat.mp3';
const menuImageBuffer = fs.readFileSync(path.join(__dirname, MENU_MEDIA_FILE));
let menuAudioBuffer = null;
try {
  menuAudioBuffer = fs.readFileSync(path.join(__dirname, MENU_AUDIO_FILE));
} catch (err) {
  console.error('Gagal load audio menucat.mp3:', err.message);
}

/* =========================
   HELPER
========================= */

function getUserRole(sender) {
  if (isOwner(sender)) return 'Owner';
  if (isPremiumUser(sender)) return 'Premium';
  return 'User';
}

function formatMenu(title, items) {
  const formattedItems = items.map((item) => {
    if (typeof item === 'string') return `│  ˖ ࣪ ݂ ✤ ${item}`;
    if (typeof item === 'object' && item.command && item.description) {
      return `│  ˖ ࣪ ݂ ✤ .${item.command} ${item.description}`;
    }
    return '│  ˖ ࣪ ݂ ✤ [Invalid item]';
  });

  return `
┌───〔 *${title.toUpperCase()}* 〕
│
${formattedItems.join('\n')}
╰────────────────────`;
}

function getDashboard(pushName, roleUser, date) {
  return `
╭──〔 *DASHBOARD* 〕
├❥ 
├⌬ NAMA : *${pushName || 'User'}*
├⌬ STATUS : *${roleUser}*
├⌬ DATE : *${date}*
├⌬ MODELS : *Prime*
├❥ 
╰───────────────────`;
}

function buildAllMenu(pushName, roleUser, date, menuData) {
  const dashboard = getDashboard(pushName, roleUser, date);
  
  const menuSections = Object.keys(menuData)
    .map((key) => formatMenu(key, menuData[key]))
    .join('\n\n');
  
  return dashboard + '\n\n' + menuSections;
}

function addFooter(text) {
  return `${text}

Alya-XD : BY Senkai
Base : Lara-MD ( BY Angela )`;
}

async function sendWithAudio(sock, remoteJid, caption, quotedMessage) {
  // Kirim gambar dengan caption
  await sock.sendMessage(remoteJid, {
    image: menuImageBuffer,
    caption: style(caption)
  }, { quoted: quotedMessage });

  // Kirim audio jika ada
  if (menuAudioBuffer) {
    const audioMessage = {
      audio: menuAudioBuffer,
      mimetype: 'audio/mpeg',
      ptt: false,
    };
    await sock.sendMessage(remoteJid, audioMessage, { quoted: quotedMessage });
  }
}

/* =========================
   MAIN HANDLER
========================= */

async function handle(sock, messageInfo) {
  const { remoteJid, pushName, sender, content, command, message } = messageInfo;

  const roleUser = getUserRole(sender);
  const date = getCurrentDate();
  const category = (content || '').toLowerCase();
  const menuData = await loadMenuOnce();

  /* ========= MENU ========= */
  if (command === 'menu') {
    const text = addFooter(`*INFO*\n_Bot Ini Tidak Memiliki Fitur Menu_\n\nUntuk Menampilkan Daftar Fitur\n- Ketik: *.allmenu* ( _Daftar Menu_ )\n- Ketik: *.menucat* ( _Daftar Menu Spesifik_ )\n\n> Contoh : .menucat download`);
    
    await sendWithAudio(sock, remoteJid, text, message);
    return;
  }

  /* ========= MENUCAT DENGAN KATEGORI ========= */
  if (command === 'menucat' && category && menuData[category]) {
    const response = addFooter(formatMenu(category, menuData[category]));
    await sendWithAudio(sock, remoteJid, response, message);
    return;
  }

  /* ========= MENUCAT KATEGORI TIDAK VALID ========= */
  if (command === 'menucat' && category && !menuData[category]) {
    const text = addFooter(`❌ Kategori "${category}" tidak ditemukan`);
    await sendWithAudio(sock, remoteJid, text, message);
    return;
  }

  /* ========= MENUCAT TANPA KATEGORI ========= */
  if (command === 'menucat' && !category) {
    const response = addFooter(buildAllMenu(pushName, roleUser, date, menuData));
    await sendWithAudio(sock, remoteJid, response, message);
  }
}

/* =========================
   EXPORT
========================= */

export default {
  Commands: ['menu', 'menucat'],
  OnlyPremium: false,
  OnlyOwner: false,
  handle,
};