import { sendMessageWithMention } from "../../src/lib/utils.js";
import fs from "fs";
import path from "path";
import saldo from "../../src/lib/saldo.js";

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, sender, senderType } = messageInfo;
  if (!isGroup) return; // Hanya untuk grup

  try {
    // Path ke file limit usage
    const usagePath = path.join(process.cwd(), "db", "users", "limitusage.json");
    
    // Cek apakah file exists
    if (!fs.existsSync(usagePath)) {
      return await sock.sendMessage(
        remoteJid,
        { text: "> _Tidak Ada Data Saat Ini_" },
        { quoted: message }
      );
    }

    // Baca data limit usage
    const usageData = JSON.parse(fs.readFileSync(usagePath, "utf8"));
    const users = usageData.users || {};

    // Konversi ke array dan sortir berdasarkan totalUsed (descending)
    const sortedUsers = Object.entries(users)
      .map(([number, data]) => ({
        number,
        ...data
      }))
      .sort((a, b) => (b.totalUsed || 0) - (a.totalUsed || 0))
      .slice(0, 20); // Ambil top 20

    if (sortedUsers.length === 0) {
      return await sock.sendMessage(
        remoteJid,
        { text: "> _Data Tidak Tersedia_" },
        { quoted: message }
      );
    }

    // Format daftar user (tanpa tanggal)
    const userList = sortedUsers
      .map((user, index) => {
        const medal = index === 0 ? "🏆" : index === 1 ? "🥈" : index === 2 ? "🥉" : "📍";
        const totalLimit = user.totalUsed || 0;
        const totalSaldo = Math.floor(saldo.limitToRupiah(totalLimit)); // Hapus desimal
        
        // Cari nomor yang cocok untuk mention
        let mentionNumber = user.number;
        if (!mentionNumber.includes('@')) {
          mentionNumber = senderType === "user" 
            ? `${mentionNumber}@s.whatsapp.net`
            : `${mentionNumber}@lid`;
        }

        return `${medal} @${mentionNumber.split('@')[0]}  →  Rp ${totalSaldo.toLocaleString('id-ID')}`;
      })
      .join("\n");

    // Hitung statistik tambahan (dalam saldo)
    const totalLimitAll = Object.values(users).reduce((sum, u) => sum + (u.totalUsed || 0), 0);
    const totalSaldoAll = Math.floor(saldo.limitToRupiah(totalLimitAll)); // Hapus desimal
    const activeToday = Object.values(users).filter(u => {
      if (!u.lastActive) return false;
      const last = new Date(u.lastActive).toDateString();
      const today = new Date().toDateString();
      return last === today;
    }).length;

    const textNotif = `╭═══════════════════════╮
║   🌟 TOP 20 USER AKTIF HARIAN 🌟   
╰═══════════════════════╯

${userList}

╭───────────────────╮
│ 📊 *STATISTIK*            
├─────────────────
│ 💰 Total Tagihan : Rp ${totalSaldoAll.toLocaleString('id-ID')}
│ 👥 Pengguna Aktif : ${activeToday} user
│ ⏰ Update : ${new Date().toLocaleString('id-ID')}
╰───────────────────╯

📝 *Penjelasan:*
Owner Akan Membayar Tagihan 
Pada Awal Bulan! Agar Bot Tetap 
Dapat Digunakan

> Yuk, Pakai Lara Bot :)`;

    // Kirim pesan dengan mention
    await sendMessageWithMention(
      sock,
      remoteJid,
      textNotif,
      message,
      senderType
    );

  } catch (error) {
    console.error("Error in top command:", error);
    await sock.sendMessage(
      remoteJid,
      { text: "⚠️ Terjadi kesalahan saat menampilkan daftar pengguna aktif." },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["lb","leaderboard","top"],
  OnlyPremium: false,
  OnlyOwner: false
};