import { findUser } from "../../src/lib/users.js";
import { isOwner, isPremiumUser } from "../../src/lib/users.js";
import saldo from "../../src/lib/saldo.js";
import fs from "fs";
import path from "path";

async function handle(sock, messageInfo) {
    const { remoteJid, message, sender, pushName } = messageInfo;

    try {
        await sock.sendMessage(remoteJid, {
            react: { text: "🔄", key: message.key },
        });

        const dataUsers = await findUser(sender);
        if (!dataUsers) {
            return sock.sendMessage(
                remoteJid,
                { text: `📛 *AKUN TIDAK DITEMUKAN*\n\nSilakan daftar dulu ya dengan ketik .daftar` },
                { quoted: message }
            );
        }

        const [docId, userData] = dataUsers;
        const limitSisa = userData.limit || 0;
        const isOwnerUser = isOwner(sender);
        const isPremium = isPremiumUser(sender);
        const username = userData.username || pushName || "Tidak diketahui";
        const role = userData.role || "User";
        
        // Ambil TOTAL PENGGUNAAN dari limitusage.json
        let totalPemakaian = 0;
        try {
            const usagePath = path.join(process.cwd(), "db", "users", "limitusage.json");
            if (fs.existsSync(usagePath)) {
                const usageData = JSON.parse(fs.readFileSync(usagePath, "utf8"));
                const users = usageData.users || {};
                
                const senderNumber = sender.split('@')[0];
                if (users[senderNumber]) {
                    totalPemakaian = users[senderNumber].totalUsed || 0;
                }
            }
        } catch (err) {
            console.error("Error reading limit usage:", err);
        }
        
        // Konversi limit ke Rupiah dan hilangkan desimal
        const saldoSisa = Math.floor(saldo.limitToRupiah(limitSisa));
        const saldoTerpakai = Math.floor(saldo.limitToRupiah(totalPemakaian));
        const saldoAwal = saldoSisa + saldoTerpakai;
        
        // Format role
        let roleDisplay = role;
        if (isOwnerUser) {
            roleDisplay = "👑 OWNER";
        } else if (isPremium) {
            roleDisplay = "⭐ PREMIUM";
        } else {
            roleDisplay = "👤 USER";
        }
        
        const privateAccess = isPremium || isOwnerUser ? "YES" : "NO";
        
        // Tampilan dengan border seperti contoh
        let teks = `╭────────────────╮\n`;
        teks += `│  📊 PROFILE USER  \n`;
        teks += `├───────────────\n`;
        teks += `│ ${roleDisplay}\n`;
        teks += `│ 🔒 Private: ${privateAccess}\n`;
        teks += `├─────────────\n`;
        teks += `│ 💰 SALDO\n`;
        teks += `│ ├ Sisa: Rp ${saldoSisa.toLocaleString('id-ID')}\n`;
        teks += `│ ├ Terpakai: Rp ${saldoTerpakai.toLocaleString('id-ID')}\n`;
        teks += `│ └ Total: Rp ${saldoAwal.toLocaleString('id-ID')}\n`;
        teks += `╰────────────────╯`;
        
        await sock.sendMessage(remoteJid, { text: teks }, { quoted: message });
        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        console.error("Error:", error);
        await sock.sendMessage(
            remoteJid,
            { text: `❌ *ERROR*\n\n${error.message}` },
            { quoted: message }
        );
    }
}

export default {
    handle,
    Commands: ["me", "saldo", "ceksaldo", "profile"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 0.1,
};