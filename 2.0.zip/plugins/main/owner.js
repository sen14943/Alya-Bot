// handle/owner.js
import { sendMessageWithMention } from "../../src/lib/utils.js";
import { listOwner } from "../../src/lib/users.js";
import config from "../../config.js";
import { readFileAsBuffer } from '../../src/lib/fileHelper.js';

const THUMBNAIL_FILE = '../../assets/media/allmenu.jpg';
const AUDIO_FILE = '../../assets/audio/ownerku.mp3';

export async function handle(sock, messageInfo) {
  const { remoteJid, message, sender, senderType, pushName } = messageInfo;

  const data = listOwner();

  if (data.length === 0) {
    return await sendMessageWithMention(
      sock,
      remoteJid,
      "Owner belum terdaftar!",
      message,
      senderType
    );
  }

  // Format daftar owner
  let ownerList = "";
  let no = 1;
  for (const item of data) {
    const phoneNumber = item.split("@")[0];
    const formattedNumber = phoneNumber.startsWith('62') 
      ? `+${phoneNumber}` 
      : phoneNumber;
    ownerList += `\n${formattedNumber} (Owner ${no})`;
    no++;
  }

  // Membuat caption
  const caption = `Hai Kak *${pushName || sender.split("@")[0]}* 👋😊

Di Bawah Ini Adalah Nomor
Owner Kesayangan Ku ...

*Owner Ku*
${ownerList}

> Support Aku Terus Yaa ✨`;

  // Load thumbnail dan audio
  let thumbnailBuffer;
  let audioBuffer;
  
  try {
    thumbnailBuffer = await readFileAsBuffer(THUMBNAIL_FILE);
  } catch (err) {
    console.error('Gagal load thumbnail:', err.message);
  }
  
  try {
    audioBuffer = await readFileAsBuffer(AUDIO_FILE);
  } catch (err) {
    console.error('Gagal load audio:', err.message);
  }

  // Kirim pesan dengan thumbnail (jika ada)
  if (thumbnailBuffer) {
    const mediaMessage = {
      image: thumbnailBuffer,
      caption: caption,
      contextInfo: {
        mentionedJid: [sender],
      },
    };
    await sock.sendMessage(remoteJid, mediaMessage, { quoted: message });
  } else {
    // Jika thumbnail tidak ada, kirim text biasa
    await sendMessageWithMention(
      sock,
      remoteJid,
      caption,
      message,
      senderType
    );
  }

  // Kirim audio (jika ada)
  if (audioBuffer) {
    const audioMessage = {
      audio: audioBuffer,
      mimetype: 'audio/mpeg',
      ptt: false,
    };
    await sock.sendMessage(remoteJid, audioMessage, { quoted: message });
  }
}

export default {
  Commands: ["owner", "dev", "developer"],
  OnlyPremium: false,
  OnlyOwner: false,
  handle,
};