import { downloadQuotedMedia, downloadMedia } from "../../src/lib/utils.js";
import fs from "fs";
import path from "path";
import ffmpeg from "fluent-ffmpeg";
import mess from "../../case/strings.js";

// Konstanta path folder
const TMP_FOLDER = path.resolve("./storage/tmp");
const MEDIA_FOLDER = path.resolve("./assets/media");

async function handle(sock, messageInfo) {
  const { remoteJid, message, type, isQuoted, content, prefix, command } =
    messageInfo;

  try {
    const mediaType = isQuoted ? isQuoted.type : type;

    if (mediaType === "sticker") {
      await sock.sendMessage(remoteJid, {
        react: { text: "⏰", key: message.key },
      });

      // Download media - fungsi ini mengembalikan nama file saja
      const fileName = isQuoted
        ? await downloadQuotedMedia(message)
        : await downloadMedia(message);

      if (!fileName) {
        throw new Error("Gagal mengunduh media sticker.");
      }

      // Cari file di kedua folder yang mungkin
      let mediaPath = path.join(TMP_FOLDER, fileName);
      if (!fs.existsSync(mediaPath)) {
        mediaPath = path.join(MEDIA_FOLDER, fileName);
      }

      if (!fs.existsSync(mediaPath)) {
        throw new Error("File media tidak ditemukan setelah diunduh.");
      }

      // Generate nama file output
      const outputFileName = `toimg_${Date.now()}.png`;
      const outputPath = path.join(TMP_FOLDER, outputFileName);

      // Convert webp ke png menggunakan fluent-ffmpeg
      await new Promise((resolve, reject) => {
        ffmpeg(mediaPath)
          .outputOptions("-vframes", "1") // Ambil frame pertama (untuk stiker animasi)
          .output(outputPath)
          .on("end", () => resolve())
          .on("error", (err) => reject(err))
          .run();
      });

      // Cek apakah file output berhasil dibuat
      if (!fs.existsSync(outputPath)) {
        throw new Error("Gagal mengkonversi sticker ke gambar.");
      }

      // Baca file hasil konversi
      const imageBuffer = fs.readFileSync(outputPath);

      await sock.sendMessage(
        remoteJid,
        {
          image: imageBuffer,
          caption: mess.general.success,
        },
        { quoted: message }
      );

      // Cleanup: hapus file temporary
      try {
        if (fs.existsSync(mediaPath)) {
          fs.unlinkSync(mediaPath);
        }
        if (fs.existsSync(outputPath)) {
          fs.unlinkSync(outputPath);
        }
      } catch (cleanupErr) {
        console.log("Gagal menghapus file temporary:", cleanupErr.message);
      }
    } else {
      return await sock.sendMessage(
        remoteJid,
        {
          text: `⚠️ _Kirim/Balas sticker dengan caption *${prefix + command}*_`,
        },
        { quoted: message }
      );
    }
  } catch (error) {
    console.log(error);
    await sock.sendMessage(
      remoteJid,
      { text: "Maaf, terjadi kesalahan. Coba lagi nanti!" },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["toimg"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};