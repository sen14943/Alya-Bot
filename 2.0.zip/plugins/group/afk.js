import { findUser, updateUser } from "../../src/lib/users.js";

/**
 * Format pesan AFK dengan card simple
 */
function formatAfkCard(pushName, alasan, isSelf = true) {
  const alasanText = alasan !== "Tanpa Alasan" 
    ? `📌 ${alasan.length > 80 ? alasan.slice(0, 80) + '...' : alasan}` 
    : '📌 Tidak ada alasan';
  
  if (isSelf) {
    return `*AFK MODE ON*
╭─────────────────
│ 👤 ${pushName}
│ ${alasanText}
╰─────────────────
💬 Ketik pesan apapun untuk bangun.`;
  }
  
return `😴 *${pushName}* sedang AFK
╭─────────────────
│ ${alasanText}
╰─────────────────
💡 Sabar ya, tunggu bangun~`;
}

/**
 * Validasi input AFK
 */
function validateAfkInput(content) {
  if (!content || content.trim() === '') {
    return 'Tanpa Alasan';
  }
  
  // Filter kata kasar
  const kataKasar = ['goblok', 'tolol', 'bangsat', 'kontol'];
  let alasan = content.trim();
  
  for (const kata of kataKasar) {
    if (alasan.toLowerCase().includes(kata)) {
      alasan = alasan.replace(new RegExp(kata, 'gi'), '*');
    }
  }
  
  return alasan;
}

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, content, sender, pushName } = messageInfo;
  
  // Hanya berlaku di grup
  if (!isGroup) {
    await sock.sendMessage(
      remoteJid,
      { text: '❌ Fitur AFK hanya bisa digunakan di grup!' },
      { quoted: message }
    );
    return;
  }

  try {
    // Validasi input
    const alasan = validateAfkInput(content);
    
    // Cek apakah user sudah AFK sebelumnya
    const existingUser = await findUser(sender);
    
    if (existingUser) {
      const [docId, userData] = existingUser;
      
      // Jika sudah AFK, kasih tahu
      if (userData?.status === 'afk') {
        await sock.sendMessage(
          remoteJid,
          { text: `😴 Kamu sudah (AFK)!\n📌 ${userData.afk?.alasan || 'Tanpa alasan'}` },
          { quoted: message }
        );
        return;
      }
    }
    
    const waktuSekarang = new Date();
    
    // Update status jadi AFK
    await updateUser(sender, {
      status: "afk",
      afk: {
        lastChat: waktuSekarang.toISOString(),
        alasan: alasan,
      },
    });
    
    // Kirim pesan card
    const afkMessage = formatAfkCard(pushName, alasan, true);
    await sock.sendMessage(remoteJid, { text: afkMessage }, { quoted: message });
    
    // React dengan emoji tidur
    await sock.sendMessage(remoteJid, { react: { text: '🛌', key: message.key } }).catch(() => {});
    
  } catch (error) {
    console.error("Error in AFK command:", error);
    await sock.sendMessage(
      remoteJid,
      { text: "❌ Terjadi kesalahan. Silakan coba lagi nanti." },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["afk", "tidur"],
  OnlyPremium: false,
  OnlyOwner: false,
};