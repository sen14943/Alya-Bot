//Tiktok Downloader V2 By Angela
import { tiktok } from "../../api/tiktok.js";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";
import {
  forceConvertToM4a,
  extractLink,
  downloadToBuffer,
} from "../../src/lib/utils.js";

/**
 * Memvalidasi apakah URL yang diberikan adalah URL TikTok yang valid
 */
function isTikTokUrl(url) {
  return /tiktok\.com/i.test(url);
}

/**
 * Mendownload video dengan retry mechanism dan cek ukuran minimal
 */
async function downloadVideoWithRetry(videoUrl, maxRetries = 3) {
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`Percobaan download video ke-${attempt}`);
      
      // Download video ke buffer
      const videoBuffer = await downloadToBuffer(videoUrl, "mp4");
      
      // CEK UKURAN MINIMAL 10KB
      const MIN_SIZE = 10 * 1024; // 10KB dalam bytes
      
      if (videoBuffer.length < MIN_SIZE) {
        throw new Error(`Video terlalu kecil (${(videoBuffer.length / 1024).toFixed(2)}KB). Minimal 10KB`);
      }
      
      console.log(`✅ Video berhasil: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);
      return videoBuffer;
      
    } catch (error) {
      lastError = error;
      console.log(`❌ Percobaan ke-${attempt} gagal:`, error.message);
      
      // Jika masih ada percobaan tersisa, tunggu sebentar sebelum mencoba lagi
      if (attempt < maxRetries) {
        console.log(`⏳ Menunggu 2 detik sebelum percobaan ke-${attempt + 1}...`);
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
  }
  
  // Jika semua percobaan gagal
  throw new Error(`Gagal download video setelah ${maxRetries} percobaan: ${lastError?.message || "Unknown error"}`);
}

/**
 * Fungsi utama untuk menangani perintah TikTok
 */
async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command } = messageInfo;

  try {
    const trimmedContent = content?.trim() || "";

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!trimmedContent) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "https://www.tiktok.com/@username/video/1234567890",
        description: "Download video TikTok tanpa watermark!\n\n✨ Fitur:\n• Download video tanpa watermark\n• Auto ekstrak audio (jika tersedia)\n• Kirim video + audio\n• Kualitas HD\n• Support semua link TikTok\n\n📝 Format: ${prefix + command} [link_tiktok]\n📌 Contoh: ${prefix + command} https://www.tiktok.com/@username/video/1234567890",
        notes: "Pastikan link TikTok valid dan publik (bukan private account)!",
        limits: "1 poin"
      });
    }

    const validLink = extractLink(trimmedContent);

    // Validasi URL TikTok
    if (!isTikTokUrl(validLink)) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "https://www.tiktok.com/@username/video/1234567890",
        description: "❌ URL yang Anda masukkan tidak valid.\n\nPastikan URL berasal dari TikTok dan merupakan link video (bukan link profil).\n\nContoh link valid:\n• https://www.tiktok.com/@user/video/1234567890\n• https://vt.tiktok.com/xxxxxx",
        notes: "Link harus dari video, bukan dari profil atau live!",
        limits: "1 poin"
      });
    }

    // Tampilkan reaksi "Loading"
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Ambil data TikTok dengan timeout
    const response = await Promise.race([
      tiktok(validLink),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Timeout 120 detik - Tidak mendapat respons dari API")), 120000)
      )
    ]);
    
    if (!response?.no_watermark) {
      throw new Error("Gagal mengambil video TikTok");
    }

    // React proses
    await sock.sendMessage(remoteJid, {
      react: { text: "📹", key: message.key },
    });

    // Proses audio (jika tersedia)
    let audioUrl = response.music;
    let audioBuffer = null;
    
    if (audioUrl) {
      try {
        // Konversi ke M4A jika memungkinkan
        audioUrl = await forceConvertToM4a({ url: response.music });
        audioBuffer = await downloadToBuffer(audioUrl, "mp3");
        
        // Cek ukuran audio minimal (opsional, 100KB)
        if (audioBuffer && audioBuffer.length < 100 * 1024) {
          console.log(`⚠️ Audio terlalu kecil: ${(audioBuffer.length / 1024).toFixed(2)}KB`);
          audioBuffer = null; // Abaikan audio jika terlalu kecil
        }
      } catch (conversionError) {
        console.log("Gagal mengonversi audio:", conversionError);
      }
    }

    // Download video dengan validasi ukuran
    let videoBuffer;
    try {
      videoBuffer = await downloadVideoWithRetry(response.no_watermark);
    } catch (downloadError) {
      // Jika gagal download, coba panggil API lagi
      console.log("Gagal download video, mencoba panggil API ulang...");
      
      // Tampilkan pesan ke user
      await sock.sendMessage(remoteJid, {
        text: "⚠️ Video gagal diunduh (mungkin corrupt). Mencoba mengambil ulang dari API..."
      }, { quoted: message });
      
      // Panggil API lagi
      const retryResponse = await tiktok(validLink);
      
      if (!retryResponse?.no_watermark) {
        throw new Error("Gagal mengambil video TikTok pada percobaan kedua");
      }
      
      // Coba download lagi dengan video baru
      videoBuffer = await downloadVideoWithRetry(retryResponse.no_watermark);
    }

    // Caption hasil
    const customCaption = `✅ *Berhasil Download TikTok!*\n\n📥 *Video siap dikirim*\n🔗 *Source:* TikTok\n✨ *Powered by Lara AI*\n\n*Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`;

    // Kirim video dengan caption
    await sock.sendMessage(
      remoteJid,
      { 
        video: videoBuffer, 
        caption: customCaption
      },
      { quoted: message }
    );

    // Kirim audio jika tersedia
    if (audioUrl && audioBuffer) {
      await sock.sendMessage(
        remoteJid,
        { 
          audio: audioBuffer,
          fileName: `tiktok_audio.mp3`,
          mimetype: "audio/mp4",
          caption: `🎵 *Audio:* ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB`
        },
        { quoted: message }
      );
    } else if (audioUrl) {
      // Fallback: kirim dari URL jika buffer gagal
      await sock.sendMessage(
        remoteJid,
        { 
          audio: { url: audioUrl },
          fileName: `tiktok_audio.mp3`,
          mimetype: "audio/mp4"
        },
        { quoted: message }
      );
    }
    
    // Tampilkan reaksi "Berhasil"
    await sock.sendMessage(remoteJid, {
      react: { text: "✅", key: message.key },
    });
    
  } catch (error) {
    console.error("Kesalahan saat memproses perintah TikTok:", error);
    logCustom("info", content, `ERROR-COMMAND-${command}.txt`);

    // React error
    await sock.sendMessage(remoteJid, {
      react: { text: "❌", key: message.key },
    }).catch(() => {});

    // Handle timeout error khusus
    if (error.message.includes("Timeout 120 detik")) {
      await sock.sendMessage(remoteJid, {
        text: "⏰ *Timeout!*\nTidak mendapat respons dari API dalam 120 detik. Silakan coba lagi nanti."
      }, { quoted: message });
    } else {
      const errorMessage = `❌ Gagal download TikTok: ${error.message || error}\n\n💡 Pastikan link video valid (bukan private account) dan coba lagi.`;
      await sock.sendMessage(remoteJid, { 
        text: errorMessage 
      }, { quoted: message });
    }
  }
}

export default {
  handle,
  Commands: ["tt", "ttdl", "tiktok"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};