// IG Downloader V3 By Angela - Fixed for utils.js compatibility
import { igdl } from "btch-downloader";

import mess from "../../case/strings.js";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";
import { 
  downloadToBuffer, 
  reply,
  downloadQuotedMedia,
  downloadMedia
} from "../../src/lib/utils.js";

import fs from "fs-extra";
import path from "path";
import ffmpeg from "fluent-ffmpeg";
import { exec } from "child_process";
import { v4 as uuidv4 } from "uuid";

// WAJIB — PATH FFmpeg (Pterodactyl)
ffmpeg.setFfmpegPath("/usr/bin/ffmpeg");

const TMP_DIR = path.join(process.cwd(), "storage", "tmp"); // Sesuai utils.js

// UKURAN MINIMAL (hanya untuk validasi internal)
const MIN_VIDEO_SIZE = 50 * 1024; // 50KB
const MIN_IMAGE_SIZE = 5 * 1024;   // 5KB

/**
 * Memvalidasi apakah URL yang diberikan adalah URL Instagram yang valid
 */
function isIGUrl(url) {
  return /instagram\.com/i.test(url);
}

/**
 * AUDIO DETECTOR - Mengecek apakah file memiliki audio
 */
function hasAudio(filePath) {
  return new Promise((resolve) => {
    exec(
      `ffprobe -v error -select_streams a -show_entries stream=index -of csv=p=0 "${filePath}"`,
      (err, stdout) => {
        resolve(stdout.trim() !== "");
      }
    );
  });
}

/**
 * GET FILE SIZE - Mendapatkan ukuran file
 */
async function getFileSize(filePath) {
  try {
    const stats = await fs.stat(filePath);
    return stats.size;
  } catch {
    return 0;
  }
}

/**
 * VALIDATE VIDEO FILE - Validasi file video dengan cek ukuran
 */
async function validateVideoFile(filePath) {
  try {
    const exists = await fs.pathExists(filePath);
    if (!exists) throw new Error("File tidak ditemukan");

    const fileSize = await getFileSize(filePath);
    if (fileSize === 0) throw new Error("File kosong");
    if (fileSize < MIN_VIDEO_SIZE) throw new Error("File terlalu kecil");

    return true;
  } catch (error) {
    throw new Error(`Validasi video gagal: ${error.message}`);
  }
}

/**
 * CONVERT TO MP3 - Mengconvert video ke MP3
 */
async function convertToMP3(inputBuffer, m, remoteJid, sock) {
  let inputPath = null;
  let outputPath = null;
  
  try {
    await fs.ensureDir(TMP_DIR);
    await fs.chmod(TMP_DIR, 0o777);

    inputPath = path.join(TMP_DIR, uuidv4());
    outputPath = path.join(TMP_DIR, `${uuidv4()}.mp3`);

    await fs.writeFile(inputPath, inputBuffer);

    // Kirim reaksi sedang memproses
    await sock.sendMessage(remoteJid, {
      react: { text: "🔄", key: m.key },
    });

    // Validasi video sebelum convert
    await validateVideoFile(inputPath);

    // CEK ADA AUDIO ATAU TIDAK
    const audioExist = await hasAudio(inputPath);
    if (!audioExist) {
      throw new Error("File tidak memiliki audio");
    }

    // CONVERT ke MP3
    await new Promise((resolve, reject) => {
      ffmpeg()
        .input(inputPath)
        .inputOptions(["-analyzeduration 100M", "-probesize 100M"])
        .noVideo()
        .audioCodec("libmp3lame")
        .audioBitrate("64k")
        .audioChannels(2)
        .audioFrequency(44100)
        .format("mp3")
        .on("end", resolve)
        .on("error", reject)
        .save(outputPath);
    });

    // Validasi hasil convert
    const outputSize = await getFileSize(outputPath);
    if (outputSize < MIN_VIDEO_SIZE / 2) {
      throw new Error("Hasil convert terlalu kecil");
    }

    // Baca hasil convert
    const audioBuffer = await fs.readFile(outputPath);
    return audioBuffer;

  } catch (error) {
    console.error("Convert to MP3 error:", error);
    throw error;
  } finally {
    // Cleanup file temporary
    try {
      if (inputPath && await fs.pathExists(inputPath)) {
        await fs.unlink(inputPath).catch(() => {});
      }
      if (outputPath && await fs.pathExists(outputPath)) {
        await fs.unlink(outputPath).catch(() => {});
      }
    } catch (cleanupError) {
      console.log("Cleanup error:", cleanupError);
    }
  }
}

/**
 * Cek tipe media dari URL atau buffer
 */
function checkMediaType(mediaUrl, mediaBuffer) {
  const fileExtension = mediaUrl.split(".").pop()?.toLowerCase() || "";
  const isImageFromExt = ["jpg", "jpeg", "png", "webp", "gif"].includes(fileExtension);
  
  // Cek magic number
  if (mediaBuffer && mediaBuffer.length > 4) {
    // JPEG
    if (mediaBuffer[0] === 0xFF && mediaBuffer[1] === 0xD8) return "image";
    // PNG
    if (mediaBuffer[0] === 0x89 && mediaBuffer[1] === 0x50 && 
        mediaBuffer[2] === 0x4E && mediaBuffer[3] === 0x47) return "image";
    // GIF
    if (mediaBuffer[0] === 0x47 && mediaBuffer[1] === 0x49 && mediaBuffer[2] === 0x46) return "image";
    // WebP
    if (mediaBuffer[0] === 0x52 && mediaBuffer[1] === 0x49 && 
        mediaBuffer[2] === 0x46 && mediaBuffer[3] === 0x46) return "image";
  }
  
  return isImageFromExt ? "image" : "video";
}

/**
 * Mendownload media dengan retry mechanism
 */
async function downloadMediaWithRetry(mediaUrl, maxRetries = 3) {
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`Percobaan download media ke-${attempt}`);
      
      const mediaBuffer = await downloadToBuffer(mediaUrl, "mp4");
      const mediaType = checkMediaType(mediaUrl, mediaBuffer);
      
      // Validasi ukuran (internal only)
      if (mediaType === "video" && mediaBuffer.length < MIN_VIDEO_SIZE) {
        throw new Error("Video terlalu kecil");
      }
      if (mediaType === "image" && mediaBuffer.length < MIN_IMAGE_SIZE) {
        throw new Error("Gambar terlalu kecil");
      }
      
      console.log(`✅ Media valid: ${mediaType}`);
      return { mediaBuffer, mediaType };
      
    } catch (error) {
      lastError = error;
      console.log(`❌ Percobaan ke-${attempt} gagal:`, error.message);
      
      if (attempt < maxRetries) {
        console.log(`⏳ Menunggu 2 detik...`);
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
  }
  
  throw new Error(`Gagal download media setelah ${maxRetries} percobaan`);
}

/**
 * Fungsi utama untuk menangani perintah Instagram
 */
async function handle(sock, messageInfo) {
  const { m, remoteJid, message, content, prefix, command } = messageInfo;

  try {
    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content?.trim()) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "https://www.instagram.com/p/Cx1234567890/",
        description: "Download video/gambar dari Instagram!\n\n✨ Fitur:\n• Download Reels, Feed, Story, IGTV\n• Support video & gambar\n• Bisa convert video ke MP3\n• Kualitas HD\n\n📝 Format:\n• Download biasa: ${prefix + command} [link]\n• Convert ke MP3: ${prefix + command} mp3 [link]\n\n📌 Contoh:\n${prefix + command} https://www.instagram.com/p/Cx1234567890/\n${prefix + command} mp3 https://www.instagram.com/reel/Cx1234567890/",
        notes: "Pastikan link Instagram valid dan bisa diakses publik!",
        limits: "1 poin"
      });
    }

    // Cek apakah perintah untuk MP3
    const isMP3Command = content.toLowerCase().includes("mp3") || 
                        command.toLowerCase().includes("mp3") || 
                        command.toLowerCase().includes("audio");
    
    let urlContent = content;
    if (isMP3Command) {
      urlContent = content.replace(/mp3/gi, "").trim();
    }

    // Validasi URL Instagram
    if (!isIGUrl(urlContent)) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "https://www.instagram.com/p/Cx1234567890/",
        description: "❌ URL yang Anda masukkan tidak valid.\n\nPastikan URL berasal dari Instagram.\n\nContoh link valid:\n• https://www.instagram.com/p/Cx1234567890/\n• https://www.instagram.com/reel/Cx1234567890/\n• https://www.instagram.com/stories/username/1234567890",
        notes: "Link harus dari postingan yang publik (bukan private account)!",
        limits: "1 poin"
      });
    }

    // Tampilkan reaksi "Loading"
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: m.key },
    });

    // Panggil API
    const response = await Promise.race([
      igdl(urlContent),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error("Timeout 120 detik")), 120000)
      )
    ]);

    if (!response || response.length === 0) {
      throw new Error("Tidak ada media yang ditemukan");
    }

    // React proses
    await sock.sendMessage(remoteJid, {
      react: { text: "📥", key: m.key },
    });

    // Download media
    let mediaResult;
    try {
      mediaResult = await downloadMediaWithRetry(response[0].url);
    } catch (downloadError) {
      console.log("Gagal download, coba API ulang...");
      
      await reply(m, "⚠️ Media gagal diunduh. Mencoba ulang...");
      
      const retryResponse = await igdl(urlContent);
      if (!retryResponse || retryResponse.length === 0) {
        throw new Error("Gagal mengambil media");
      }
      
      mediaResult = await downloadMediaWithRetry(retryResponse[0].url);
    }

    const { mediaBuffer, mediaType } = mediaResult;

    // Caption hasil
    const customCaption = `✅ *Berhasil Download Instagram!*\n\n📥 *Media siap dikirim*\n🔗 *Source:* Instagram\n✨ *Powered by Lara AI*\n\n*Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`;

    // Jika perintah MP3
    if (isMP3Command) {
      if (mediaType === "video") {
        try {
          await sock.sendMessage(remoteJid, {
            react: { text: "🎵", key: m.key },
          });
          
          const audioBuffer = await convertToMP3(mediaBuffer, m, remoteJid, sock);
          
          await sock.sendMessage(
            remoteJid,
            {
              audio: audioBuffer,
              mimetype: "audio/mpeg",
              fileName: `instagram_audio_${Date.now()}.mp3`,
              ptt: false,
              caption: `✅ *Audio berhasil diekstrak!*\n\n🎵 *Size:* ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB`
            },
            { quoted: m }
          );
          
        } catch (convertError) {
          console.error("Gagal convert:", convertError);
          await reply(m, `❌ Gagal convert ke MP3: ${convertError.message}`);
        }
      } else {
        await reply(m, "⚠️ *Media adalah gambar, tidak bisa di-convert ke MP3.*");
        
        await sock.sendMessage(
          remoteJid,
          { 
            image: mediaBuffer, 
            caption: customCaption,
            mimetype: "image/jpeg"
          },
          { quoted: m }
        );
      }
    } else {
      // Kirim media asli
      if (mediaType === "image") {
        await sock.sendMessage(
          remoteJid,
          { 
            image: mediaBuffer, 
            caption: customCaption,
            mimetype: "image/jpeg"
          },
          { quoted: m }
        );
      } else {
        await sock.sendMessage(
          remoteJid,
          { 
            video: mediaBuffer, 
            caption: customCaption,
            mimetype: "video/mp4"
          },
          { quoted: m }
        );
      }
    }
    
    // Tampilkan reaksi "Berhasil"
    await sock.sendMessage(remoteJid, {
      react: { text: "✅", key: m.key },
    });
    
  } catch (error) {
    console.error("Kesalahan:", error);
    logCustom("info", content, `ERROR-COMMAND-${command}.txt`);

    // React error
    await sock.sendMessage(remoteJid, {
      react: { text: "❌", key: m.key },
    }).catch(() => {});

    if (error.message.includes("Timeout")) {
      await reply(m, "⏰ *Timeout!*\nSilakan coba lagi nanti.");
    } else {
      await reply(
        m,
        `❌ *Gagal download Instagram*\n\n📌 *Detail:* ${error.message || "Unknown error"}\n\n💡 Pastikan link valid dan postingan publik.`
      );
    }
    
  } finally {
    // Cleanup temp files (lebih dari 5 menit)
    try {
      const files = await fs.readdir(TMP_DIR);
      const now = Date.now();
      for (const f of files) {
        const fp = path.join(TMP_DIR, f);
        const stat = await fs.stat(fp);
        if (now - stat.mtimeMs > 5 * 60 * 1000) {
          await fs.unlink(fp).catch(() => {});
        }
      }
    } catch {}
  }
}

export default {
  handle,
  Commands: ["igdl", "ig", "instagram", "igmp3", "igaudio"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};