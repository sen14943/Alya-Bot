// plugins/ttmp3.js
import { tiktok } from "../../api/tiktok.js";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";
import {
  forceConvertToM4a,
  extractLink,
  downloadToBuffer,
} from "../../src/lib/utils.js";

/**
 * Validasi apakah URL berasal dari TikTok
 */
function isTikTokUrl(url) {
  return /tiktok\.com/i.test(url);
}

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, prefix, command } = messageInfo;

  try {
    const trimmedContent = content?.trim() || "";

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!trimmedContent) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "https://www.tiktok.com/@username/video/1234567890",
        description: "Download audio/musik dari video TikTok!\n\n✨ Fitur:\n• Ekstrak audio dari video TikTok\n• Hasil format MP3\n• Kualitas audio bagus\n• Cepat dan mudah\n\n📝 Format: ${prefix + command} [link_tiktok]\n📌 Contoh: ${prefix + command} https://www.tiktok.com/@username/video/1234567890",
        notes: "Pastikan link TikTok valid dan video memiliki audio (bukan video bisu)!",
        limits: "1 poin"
      });
    }

    const validLink = extractLink(trimmedContent);

    // Validasi URL TikTok
    if (!isTikTokUrl(validLink)) {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: true,
        example: "https://www.tiktok.com/@username/video/1234567890",
        description: "❌ URL yang Anda masukkan tidak valid.\n\nPastikan URL berasal dari TikTok dan merupakan link video.\n\nContoh link valid:\n• https://www.tiktok.com/@user/video/1234567890\n• https://vt.tiktok.com/xxxxxx",
        notes: "Link harus dari video yang memiliki audio!",
        limits: "1 poin"
      });
    }

    // Tampilkan reaksi "Loading"
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Ambil data TikTok
    const response = await tiktok(validLink);

    // Validasi response.music
    if (!response?.music) {
      console.error("Error: Tidak ada URL musik yang ditemukan dalam response.");
      logCustom("info", trimmedContent, `ERROR-COMMAND-${command}.txt`);
      
      await sock.sendMessage(remoteJid, {
        react: { text: "❌", key: message.key },
      }).catch(() => {});
      
      return await sock.sendMessage(remoteJid, {
        text: "❌ Gagal mengambil audio dari TikTok.\n\n💡 Pastikan video memiliki audio dan coba lagi nanti."
      }, { quoted: message });
    }

    // React proses
    await sock.sendMessage(remoteJid, {
      react: { text: "🎵", key: message.key },
    });

    let outputUrl = response.music;

    try {
      // Konversi ke M4A jika memungkinkan
      outputUrl = await forceConvertToM4a({ url: response.music });
      const audioBuffer = await downloadToBuffer(outputUrl, "mp3");

      // Kirim audio dengan caption
      await sock.sendMessage(
        remoteJid,
        {
          audio: audioBuffer,
          fileName: "tiktok_audio.mp3",
          mimetype: "audio/mp4",
          caption: `✅ *Berhasil Download Audio TikTok!*\n\n🎵 *Audio siap diputar*\n📥 *Size:* ${(audioBuffer.length / 1024 / 1024).toFixed(2)} MB\n✨ *Powered by Lara AI*\n\n*Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`
        },
        { quoted: message }
      );
    } catch (conversionError) {
      console.log("Gagal konversi audio, kirim dari URL:", conversionError);
      
      // Fallback: kirim dari URL
      await sock.sendMessage(
        remoteJid,
        {
          audio: { url: outputUrl },
          fileName: "tiktok_audio.mp3",
          mimetype: "audio/mp4",
        },
        { quoted: message }
      );
    }

    // React sukses
    await sock.sendMessage(remoteJid, {
      react: { text: "✅", key: message.key },
    });

  } catch (error) {
    console.error("Error in ttmp3:", error);
    logCustom("info", content, `ERROR-COMMAND-${command}.txt`);

    // React error
    await sock.sendMessage(remoteJid, {
      react: { text: "❌", key: message.key },
    }).catch(() => {});

    const errorMessage = `❌ Gagal download audio TikTok: ${error.message || error}\n\n💡 Pastikan link video valid dan memiliki audio, lalu coba lagi.`;
    
    await sock.sendMessage(remoteJid, { 
      text: errorMessage 
    }, { quoted: message });
  }
}

export default {
  handle,
  Commands: ["ttmp3", "tiktokmp3"],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 1,
};