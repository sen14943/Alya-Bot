// plugins/removebg.js
import { removeBackground } from '../../api/remove-bg.js';
import { uploadFile } from '../../api/uploader.js';
import { downloadQuotedMedia, downloadMedia, reply } from '../../src/lib/utils.js';
import { sendHelpCard } from '../../case/help.js';
import fs from 'fs';
import path from 'path';

async function handle(sock, messageInfo) {
    const { m, remoteJid, message, type, isQuoted, prefix, command } = messageInfo;

    try {
        const mediaType = isQuoted ? isQuoted.type : type;

        // CEK APAKAH ADA GAMBAR
        if (mediaType !== 'image') {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: true,
                needText: false,
                example: "(kirim atau balas gambar)",
                description: "Hapus background gambar secara otomatis dengan AI!\n\n✨ Fitur:\n• Menghapus latar belakang gambar\n• Hasil background transparan (PNG)\n• Cocok untuk foto produk, selfie, dll\n• Hasil bersih dan rapi",
                notes: "Pastikan objek utama terlihat jelas untuk hasil terbaik!",
                limits: "3 poin"
            });
        }

        // React loading
        await sock.sendMessage(remoteJid, {
            react: { text: '🎨', key: message.key },
        });

        // Download media
        let media;
        try {
            media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
        } catch (error) {
            console.error('Download error:', error);
            return await reply(m, '❌ Gagal mengunduh gambar.\nSilakan kirim ulang gambar.');
        }

        const tmpFolder = path.resolve('./storage/tmp');
        const mediaPath = path.join(tmpFolder, media);

        if (!fs.existsSync(mediaPath)) {
            return await reply(m, '❌ File gambar tidak ditemukan.\nSilakan kirim ulang gambar.');
        }

        // Upload ke tmp (pakai uploader.js)
        let imageUrl;
        try {
            imageUrl = await uploadFile(mediaPath);
            console.log(`📤 Upload berhasil: ${imageUrl}`);
        } catch (uploadError) {
            console.error('Upload error:', uploadError);
            return await reply(m, '❌ Gagal mengupload gambar.\nSilakan coba lagi.');
        }

        // Update react
        await sock.sendMessage(remoteJid, { 
            react: { text: '🤖', key: message.key } 
        });

        // Proses remove background
        let resultBuffer;
        try {
            resultBuffer = await removeBackground(imageUrl);
        } catch (bgError) {
            console.error('RemoveBG error:', bgError);
            return await reply(m, `❌ Gagal menghapus background.\n${bgError.message}`);
        }

        // Hapus file temporary
        fs.unlink(mediaPath, () => {});

        // Caption hasil
        const customCaption = `✅ *Berhasil menghapus background!*\n\n🖼️ *Hasil:* Background transparan (PNG)\n✨ *Powered by Lara AI - RemoveBG*\n\n> Gambar siap digunakan!`;

        await sock.sendMessage(
            remoteJid,
            {
                image: resultBuffer,
                caption: customCaption,
            },
            { quoted: message },
        );
        
        // React sukses
        await sock.sendMessage(remoteJid, { 
            react: { text: '✅', key: message.key } 
        });
        
    } catch (error) {
        console.error('Error in removebg command:', error);
        
        // React error
        await sock.sendMessage(remoteJid, { 
            react: { text: '❌', key: message.key } 
        }).catch(() => {});
        
        await reply(
            m,
            `❌ *Terjadi kesalahan*\n\nGagal menghapus background gambar.\nSilakan coba lagi nanti.\n\n📌 *Error:* ${error.message}`
        );
    }
}

export default {
    handle,
    Commands: ['removebg', 'nobg', 'hapusbg', 'transparan'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 3,
};