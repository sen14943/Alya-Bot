// commands/maker/hdvid.js
import { downloadQuotedMedia, downloadMedia, reply } from '../../src/lib/utils.js';
import { sendHelpCard } from '../../case/help.js';
import fs from 'fs';
import path from 'path';
import mess from '../../case/strings.js';
import axios from 'axios';
import config from '../../config.js';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const mainDir = path.resolve(__dirname, "../../");
const tmpDir = path.join(mainDir, "storage", "tmp");

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const http = axios.create({
  timeout: 60000,
  validateStatus: () => true,
});

// Fungsi request dengan retry
async function requestWithRetry(requestFn, maxRetries = 5, delayMs = 15000) {
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const result = await requestFn();
      return result;
    } catch (error) {
      lastError = error;
      console.log(`Percobaan ke-${attempt} gagal: ${error.message}`);
      
      if (attempt === maxRetries) break;
      
      console.log(`Menunggu ${delayMs/1000} detik sebelum mencoba lagi...`);
      await delay(delayMs);
    }
  }
  
  throw lastError;
}

async function handle(sock, messageInfo) {
  const { m, remoteJid, message, prefix, command, type, isQuoted } = messageInfo;

  try {
    // Cek apakah user reply/kirim video
    const mediaType = isQuoted ? isQuoted.type : type;
    
    // CEK APAKAH USER MINTA BANTUAN ATAU TIDAK ADA VIDEO
    if (mediaType !== 'video') {
      return await sendHelpCard(sock, remoteJid, message, {
        prefix: prefix,
        command: command,
        needImage: false,
        needText: false,
        needVideo: true,  // Custom untuk video
        example: "(kirim atau balas video)",
        description: "Tingkatkan kualitas video menjadi HD dengan AI!\n\n✨ Fitur:\n• Meningkatkan resolusi video\n• Memperjelas detail yang buram\n• Hasil lebih tajam dan jernih\n• Support berbagai format video",
        notes: "Proses memakan waktu 1-4 menit tergantung ukuran video. Makin jelas video asli, makin bagus hasil HD-nya!",
        limits: "5 poin"
      });
    }

    await sock.sendMessage(remoteJid, {
      react: { text: '⏰', key: message.key },
    });

    // ===============================
    // DOWNLOAD VIDEO DARI WA (otomatis ke storage/tmp)
    // ===============================
    let media;
    try {
      media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
    } catch (err) {
      if (err.code === 'ECONNRESET' || err.message?.includes('terminated')) {
        return await reply(m, '❌ Gagal mengunduh video dari WhatsApp.\n\nSilakan kirim ulang video dan coba lagi.');
      }
      throw err;
    }

    // Path sesuai utils.js: storage/tmp/
    const mediaPath = path.join(tmpDir, media);
    if (!fs.existsSync(mediaPath)) {
      return await reply(m, '❌ File video tidak ditemukan.\nSilakan kirim ulang video.');
    }

    // ===============================
    // UPLOAD VIDEO KE TMP (pake AutoResbot)
    // ===============================
    const uploadResult = await requestWithRetry(async () => {
      const { default: ApiAutoresbotModule } = await import('api-autoresbot');
      const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;
      const api = new ApiAutoresbot(config.APIKEY);
      const upload = await api.tmpUpload(mediaPath);
      
      if (!upload || upload.code !== 200) {
        throw new Error('Upload failed');
      }
      return upload;
    });

    const videoUrl = uploadResult.data.url;
    console.log(`Video uploaded: ${videoUrl}`);

    // ===============================
    // KIRIM KE API FAA HDVID
    // ===============================
    const createRes = await requestWithRetry(async () => {
      const faaUrl = `https://api-faa.my.id/faa/hdvid?url=${encodeURIComponent(videoUrl)}`;
      const response = await http.get(faaUrl);
      
      if (!response.data?.job_id) {
        throw new Error('No job_id received from FAA');
      }
      
      return response;
    });

    const jobId = createRes.data.job_id;
    const resultUrl = createRes.data.result;

    console.log(`Job ID: ${jobId}, Result URL: ${resultUrl}`);

    // ===============================
    // POLLING SETIAP 8 DETIK (MAKS 30x = 4 MENIT)
    // ===============================
    const maxPolling = 30;
    const pollingDelay = 8000;
    let finalVideoUrl = null;

    for (let attempt = 1; attempt <= maxPolling; attempt++) {
      await delay(pollingDelay);

      try {
        const pollRes = await http.get(resultUrl);
        const data = pollRes.data;

        console.log(`Polling #${attempt}: state = ${data.state}`);

        if (data.state === 'done') {
          finalVideoUrl = data.result?.download_url;
          if (finalVideoUrl) {
            console.log(`Video HD siap: ${finalVideoUrl}`);
            break;
          } else {
            return await reply(m, '❌ Video HD gagal diproses (URL tidak ditemukan).');
          }
        }

        if (data.state === 'failed') {
          return await reply(m, '❌ Proses HD video gagal.\nSilakan coba lagi.');
        }
      } catch (pollError) {
        console.log(`Polling error: ${pollError.message}`);
        if (attempt === maxPolling) {
          return await reply(m, '❌ Gagal mendapatkan status proses.\nSilakan coba lagi.');
        }
      }
    }

    if (!finalVideoUrl) {
      return await reply(m, '❌ Waktu proses terlalu lama (4 menit).\nSilakan coba lagi nanti.');
    }

    // ===============================
    // DOWNLOAD VIDEO HD DAN KIRIM KE WA
    // ===============================
    const videoRes = await requestWithRetry(async () => {
      const response = await http.get(finalVideoUrl, {
        responseType: 'arraybuffer',
      });
      
      if (response.status !== 200) {
        throw new Error(`Download failed with status ${response.status}`);
      }
      
      return response;
    });

    const videoBuffer = Buffer.from(videoRes.data);

    await sock.sendMessage(remoteJid, {
      video: videoBuffer,
      caption: mess.general.success,
    }, { quoted: message });

    // Hapus file tmp dari storage/tmp/
    try { 
      if (fs.existsSync(mediaPath)) {
        fs.unlinkSync(mediaPath); 
        console.log(`File ${media} dihapus dari ${tmpDir}`);
      }
    } catch (err) {
      console.error('Gagal hapus file:', err);
    }

  } catch (error) {
    console.error('Error in HD Video process:', error);
    await reply(m, '❌ Terjadi kesalahan saat memproses video.\nSilakan coba lagi nanti.');
  }
}

export default {
  handle,
  Commands: ['hdvid'],
  OnlyPremium: false,
  OnlyOwner: false,
  limitDeduction: 5,
};