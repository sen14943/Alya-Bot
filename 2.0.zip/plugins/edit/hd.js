// plugins/hd.js
import { enhanceImage } from '../../api/hd.js';
import { uploadFile } from '../../api/uploader.js';
import { downloadQuotedMedia, downloadMedia, reply } from '../../src/lib/utils.js';
import { sendHelpCard } from '../../case/help.js';
import fs from 'fs';
import path from 'path';

async function handle(sock, messageInfo) {
    const { m, remoteJid, message, type, isQuoted, prefix, command } = messageInfo;

    try {
        const mediaType = isQuoted ? isQuoted.type : type;

        // Cek apakah ada gambar
        if (mediaType !== 'image') {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: true,
                needText: false,
                example: "(kirim atau balas gambar)",
                description: "Tingkatkan kualitas gambar menjadi HD dengan AI!\n\n✨ Fitur:\n• Meningkatkan resolusi gambar\n• Memperjelas detail yang buram\n• Hasil lebih tajam dan jernih\n• Cocok untuk foto lama atau kurang jelas",
                notes: "Makin jelas gambar asli, makin bagus hasil HD-nya!",
                limits: "1 poin"
            });
        }

        // React loading
        await sock.sendMessage(remoteJid, {
            react: { text: '🖼️', key: message.key },
        });

        // Download media
        let media;
        try {
            media = isQuoted ? await downloadQuotedMedia(message) : await downloadMedia(message);
        } catch (error) {
            console.error('Download error:', error);
            return await reply(m, '❌ Gagal mengunduh gambar.\nSilakan kirim ulang gambar.');
        }

        const tmpFolder = path.resolve('./storage/tmp');
        const mediaPath = path.join(tmpFolder, media);

        if (!fs.existsSync(mediaPath)) {
            return await reply(m, '❌ File gambar tidak ditemukan.\nSilakan kirim ulang gambar.');
        }

        // Upload ke tmp
        let imageUrl;
        try {
            imageUrl = await uploadFile(mediaPath);
            console.log(`📤 Upload berhasil: ${imageUrl}`);
        } catch (uploadError) {
            console.error('Upload error:', uploadError);
            return await reply(m, '❌ Gagal mengupload gambar.\nSilakan coba lagi.');
        }

        // Update react
        await sock.sendMessage(remoteJid, { 
            react: { text: '✨', key: message.key } 
        });

        // Proses HD
        let resultBuffer;
        try {
            resultBuffer = await enhanceImage(imageUrl);
        } catch (hdError) {
            console.error('HD error:', hdError);
            return await reply(m, `❌ Gagal meningkatkan kualitas gambar.\n${hdError.message}`);
        }

        // Hapus file temporary
        fs.unlink(mediaPath, () => {});

        // Caption hasil
        const customCaption = `> *Berhasil meningkatkan kualitas!*\n\n✨ *Mode:* HD Enhanced\n🤖 *Powered by Lara AI*\n\n*Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`;

        await sock.sendMessage(
            remoteJid,
            {
                image: resultBuffer,
                caption: customCaption,
            },
            { quoted: message },
        );
        
        // React sukses
        await sock.sendMessage(remoteJid, { 
            react: { text: '✅', key: message.key } 
        });
        
    } catch (error) {
        console.error('Error in hd command:', error);
        
        await sock.sendMessage(remoteJid, { 
            react: { text: '❌', key: message.key } 
        }).catch(() => {});
        
        await reply(
            m,
            `❌ *Terjadi kesalahan*\n\nGagal memproses gambar.\nSilakan coba lagi nanti.\n\n📌 *Error:* ${error.message}`
        );
    }
}

export default {
    handle,
    Commands: ['hd', 'enhance', 'hq'],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
};