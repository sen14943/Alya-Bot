import { sendMessageWithMention } from '../../src/lib/utils.js';
import mess from '../../case/strings.js';
import { getGroupMetadata } from '../../src/lib/cache.js';
import { getTotalChatPerGroup } from '../../src/lib/totalchat.js';

// ============ KONFIGURASI ============
const MIN_CHAT = 10;  // Minimal chat agar tidak dianggap sider
// ====================================

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, sender, senderType } = messageInfo;
  if (!isGroup) return;

  try {
    const groupMetadata = await getGroupMetadata(sock, remoteJid);
    const participants = groupMetadata.participants;

    const isAdmin = participants.some(
      (p) => (p.phoneNumber === sender || p.id === sender) && p.admin,
    );

    if (!isAdmin) {
      await sock.sendMessage(remoteJid, { text: mess.general.isAdmin }, { quoted: message });
      return;
    }

    // Ambil data total chat per grup
    const totalChatData = await getTotalChatPerGroup(remoteJid);

    // Filter member dengan chat < MIN_CHAT (sider)
    const siderMembers = participants.filter((participant) => {
      const jid = participant.phoneNumber || participant.id;
      const totalChat = totalChatData[jid] || 0;
      return totalChat < MIN_CHAT;
    });

    if (siderMembers.length === 0) {
      return await sock.sendMessage(
        remoteJid,
        { text: `📋 _Tidak ada member sider (chat < ${MIN_CHAT}) di grup ini._` },
        { quoted: message },
      );
    }

    const memberList = siderMembers
      .map((p) => {
        const jid = p.phoneNumber || p.id;
        const number = jid.split('@')[0];
        const totalChat = totalChatData[jid] || 0;
        return `◧ @${number} (${totalChat} chat)`;
      })
      .join('\n');

    const countSider = siderMembers.length;
    const totalMember = participants.length;

    const teks_sider = `══✪〘 *👥 Member Sider* 〙✪══
        
_${countSider} dari ${totalMember} anggota grup ${groupMetadata.subject} adalah sider_

*📌 Alasan:* Chat kurang dari ${MIN_CHAT} pesan

*📋 List Member Sider:*
${memberList}

_Harap aktif di grup karena akan ada pembersihan member secara berkala._`;

    await sendMessageWithMention(sock, remoteJid, teks_sider, message, senderType);
  } catch (error) {
    console.error('Error handling gcsider:', error);
    await sock.sendMessage(
      remoteJid,
      { text: '⚠️ Terjadi kesalahan saat menampilkan member sider.' },
      { quoted: message },
    );
  }
}

export default {
  handle,
  Commands: ['gcsider', 'sider'],
  OnlyPremium: false,
  OnlyOwner: false,
};