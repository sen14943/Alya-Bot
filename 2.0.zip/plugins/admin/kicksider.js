import mess from "../../case/strings.js";
import config from "../../config.js";
import { sendMessageWithMention } from "../../src/lib/utils.js";
import { getGroupMetadata } from "../../src/lib/cache.js";
import { getTotalChatPerGroup } from "../../src/lib/totalchat.js";

// ============ KONFIGURASI ============
const DELAY_KICK = 3000;      // Delay per kick (ms)
const MIN_CHAT = 10;          // Minimal chat agar tidak di-kick
// ====================================

let inProccess = false;

async function handle(sock, messageInfo) {
  const { remoteJid, isGroup, message, sender, senderType } = messageInfo;
  if (!isGroup) return;

  try {
    const groupMetadata = await getGroupMetadata(sock, remoteJid);
    const participants = groupMetadata.participants;
    const isAdmin = participants.some(
      (p) => (p.phoneNumber === sender || p.id === sender) && p.admin
    );

    if (!isAdmin) {
      await sock.sendMessage(
        remoteJid,
        { text: mess.general.isAdmin },
        { quoted: message }
      );
      return;
    }

    if (inProccess) {
      await sock.sendMessage(
        remoteJid,
        { text: "⏳ _Proses pembersihan sedang berlangsung, tunggu sebentar..._" },
        { quoted: message }
      );
      return;
    }

    // Ambil data total chat
    const totalChatData = await getTotalChatPerGroup(remoteJid);

    // Filter member dengan chat < MIN_CHAT
    const memberToKick = participants
      .filter((participant) => {
        const jid = participant.phoneNumber || participant.id;
        const totalChat = totalChatData[jid] || 0;
        return totalChat < MIN_CHAT && jid.split("@")[0] !== config.phone_number_bot;
      })
      .map((p) => p.phoneNumber || p.id);

    if (memberToKick.length === 0) {
      return await sock.sendMessage(
        remoteJid,
        { text: `📋 _Tidak ada member dengan chat kurang dari ${MIN_CHAT}._` },
        { quoted: message }
      );
    }

    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });
    inProccess = true;

    let successCount = 0;
    for (const member of memberToKick) {
      await new Promise((resolve) => setTimeout(resolve, DELAY_KICK));
      try {
        await sock.groupParticipantsUpdate(remoteJid, [member], "remove");
        successCount++;
      } catch (error) {
        console.error(`Gagal kick ${member}:`, error);
      }
    }

    inProccess = false;

    await sendMessageWithMention(
      sock,
      remoteJid,
      `✅ _Berhasil mengeluarkan ${successCount} member dengan chat < ${MIN_CHAT}_`,
      message,
      senderType
    );
  } catch (error) {
    console.error("Error:", error);
    inProccess = false;
    return await sock.sendMessage(
      remoteJid,
      { text: "❌ Terjadi kesalahan saat memproses." },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["kickshider"],
  OnlyPremium: false,
  OnlyOwner: false,
};