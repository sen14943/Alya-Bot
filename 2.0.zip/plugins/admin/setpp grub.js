import { downloadQuotedMedia, downloadMedia } from "../../src/lib/utils.js";
import { getGroupMetadata } from "../../src/lib/cache.js";
import path from "path";
import mess from "../../case/strings.js";
import { fileURLToPath } from "url";
import fs from "fs";

// Gantikan require.main.filename dengan cara ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const mainDir = path.resolve(__dirname, "../../");
const tmpDir = path.join(mainDir, "storage", "tmp"); // Folder tmp sesuai utils.js

async function handle(sock, messageInfo) {
  const {
    remoteJid,
    isGroup,
    message,
    type,
    isQuoted,
    prefix,
    command,
    sender,
  } = messageInfo;

  if (!isGroup) return; // Hanya untuk grup

  try {
    // Ambil metadata grup
    const groupMetadata = await getGroupMetadata(sock, remoteJid);
    const participants = groupMetadata.participants;
    
    // Cek apakah pengirim adalah admin
    const isAdmin = participants.some(
      (p) => (p.phoneNumber === sender || p.id === sender) && p.admin
    );

    if (!isAdmin) {
      await sock.sendMessage(
        remoteJid,
        { text: mess.general.isAdmin },
        { quoted: message }
      );
      return;
    }

    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Unduh media (gambar) - simpan ke storage/tmp
    let mediaFileName;
    let mediaType;
    
    if (isQuoted) {
      // downloadQuotedMedia(message, useCustomFolder) 
      // - tanpa parameter kedua akan pakai tmpFolder (storage/tmp)
      mediaFileName = await downloadQuotedMedia(message);
      mediaType = `${isQuoted.type}Message`;
    } else {
      mediaFileName = await downloadMedia(message);
      mediaType = `${type}Message`;
    }

    if (mediaFileName && mediaType === "imageMessage") {
      const groupId = groupMetadata.id;
      const mediaPath = path.join(tmpDir, mediaFileName);
      
      // Cek apakah file benar-benar ada
      if (!fs.existsSync(mediaPath)) {
        throw new Error("File media tidak ditemukan");
      }
      
      // Update foto profil grup
      await sock.updateProfilePicture(groupId, { url: mediaPath });
      
      // Hapus file setelah digunakan
      setTimeout(() => {
        try {
          if (fs.existsSync(mediaPath)) {
            fs.unlinkSync(mediaPath);
            console.log(`File ${mediaFileName} berhasil dihapus dari tmp`);
          }
        } catch (err) {
          console.error("Gagal menghapus file media:", err);
        }
      }, 5000);

      return await sock.sendMessage(
        remoteJid,
        { text: `✅ Berhasil! Foto profil grup telah diganti.` },
        { quoted: message }
      );
    }

    // Jika media tidak valid
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Kirim atau balas gambar dengan caption *${prefix + command}*`,
      },
      { quoted: message }
    );
  } catch (error) {
    console.error("Error processing message:", error);

    let errorMessage = "❌ Terjadi kesalahan saat mengganti foto profil grup.";
    
    // Tambahkan pesan error spesifik jika perlu
    if (error.message === "File media tidak ditemukan") {
      errorMessage = "❌ Gagal mengunduh media. Pastikan gambar valid.";
    } else if (error.message?.includes("admin") || error.message?.includes("403")) {
      errorMessage = "❌ Bot harus menjadi admin grup untuk mengganti foto profil.";
    }

    await sock.sendMessage(remoteJid, {
      text: errorMessage,
    });
  }
}

export default {
  handle,
  Commands: ["setppgc", "setppgroub", "setppgrub", "setppgroup", "setppgrup"],
  OnlyPremium: false,
  OnlyOwner: false,
};