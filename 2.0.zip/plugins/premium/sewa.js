import { addSewa, findSewa } from "../../src/lib/sewa.js";
import config from "../../config.js";
import { selisihHari, hariini } from "../../src/lib/utils.js";
import { deleteCache } from "../../src/lib/globalCache.js";
import { readUsers } from "../../src/lib/users.js";
import { listOwner } from "../../src/lib/users.js";
import fs from 'fs';

const PREMIUM_STATS_FILE = './db/users/sewa_premium.json';

// Baca database statistik premium
function readPremiumStats() {
    if (!fs.existsSync(PREMIUM_STATS_FILE)) {
        fs.writeFileSync(PREMIUM_STATS_FILE, JSON.stringify({}, null, 2));
        return {};
    }
    return JSON.parse(fs.readFileSync(PREMIUM_STATS_FILE, 'utf-8'));
}

// Simpan database statistik premium
function writePremiumStats(data) {
    fs.writeFileSync(PREMIUM_STATS_FILE, JSON.stringify(data, null, 2));
}

// Update statistik user setelah sewa
function updateUserStats(sender, totalHari) {
    const stats = readPremiumStats();
    
    if (!stats[sender]) {
        stats[sender] = { total_grup: 0, total_masa_sewa: 0 };
    }
    
    stats[sender].total_grup += 1;
    stats[sender].total_masa_sewa += totalHari;
    
    writePremiumStats(stats);
}

// Cek batasan premium
function checkPremiumLimit(sender, totalHari) {
    const stats = readPremiumStats();
    const userStats = stats[sender] || { total_grup: 0, total_masa_sewa: 0 };
    
    const MAX_GRUP = 10;
    const MAX_HARI = 365;
    
    const newTotalGrup = userStats.total_grup + 1;
    const newTotalHari = userStats.total_masa_sewa + totalHari;
    
    if (newTotalGrup > MAX_GRUP) {
        return { allowed: false, reason: `Maksimal ${MAX_GRUP} grup (sudah ${userStats.total_grup} grup)` };
    }
    
    if (newTotalHari > MAX_HARI) {
        const sisa = MAX_HARI - userStats.total_masa_sewa;
        return { allowed: false, reason: `Maksimal ${MAX_HARI} hari total sewa (sisa ${sisa} hari, minta ${totalHari} hari)` };
    }
    
    return { allowed: true };
}

async function handle(sock, messageInfo) {
  let { remoteJid, message, content, sender, prefix, command } = messageInfo;

  // ========== CEK AKSES (OWNER / PREMIUM) ==========
  const ownerList = listOwner();
  const isOwner = ownerList.includes(sender);
  
  // Cek premium aktif
  const users = await readUsers();
  let isPremium = false;
  if (users[sender] && users[sender].premium) {
    const expiredDate = new Date(users[sender].premium);
    isPremium = expiredDate > new Date();
  }
  
  // Tolak user biasa
  if (!isOwner && !isPremium) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `❌ *Akses Ditolak!*\n\nCommand *${prefix + command}* hanya untuk *OWNER* dan *PREMIUM*.\n\nHubungi owner untuk menjadi premium.`
      },
      { quoted: message }
    );
  }
  
  // ========== VALIDASI INPUT ==========
  if (!content || content.trim() === "") {
    let batasanText = "";
    if (!isOwner && isPremium) {
      const stats = readPremiumStats()[sender] || { total_grup: 0, total_masa_sewa: 0 };
      batasanText = `\n\n📋 *Status Premium Anda:*\n• Grup terpakai: ${stats.total_grup}/10\n• Hari terpakai: ${stats.total_masa_sewa}/365`;
    }
    
    return await sock.sendMessage(
      remoteJid,
      {
        text: `_⚠️ Format Penggunaan:_ \n\n_💬 Contoh:_ _*${prefix + command} https://chat.whatsapp.com/xxx 30*_\n\n_*30* artinya 30 hari_\n\n_Owner: Bebas tanpa batasan_\n_Premium: Maksimal 10 grup & 365 hari_${batasanText}`,
      },
      { quoted: message }
    );
  }

  content = content.replace(/\?mode=[^ ]+/gi, "");

  const args = content.trim().split(" ");
  if (args.length < 2) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Format tidak valid. Contoh:\n*${prefix + command} https://chat.whatsapp.com/xxx 30*`
      },
      { quoted: message }
    );
  }

  const linkGrub = args[0];
  const totalHari = parseInt(args[1], 10);

  if (!linkGrub.includes("chat.whatsapp.com")) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Link harus dari chat.whatsapp.com`
      },
      { quoted: message }
    );
  }

  if (isNaN(totalHari) || totalHari <= 0) {
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ Jumlah hari tidak valid`
      },
      { quoted: message }
    );
  }

  // ========== CEK BATASAN PREMIUM (kecuali owner) ==========
  if (!isOwner && isPremium) {
    const limitCheck = checkPremiumLimit(sender, totalHari);
    if (!limitCheck.allowed) {
      return await sock.sendMessage(
        remoteJid,
        {
          text: `> *Batas Sewa Tercapai!*`
        },
        { quoted: message }
      );
    }
  }

  // ========== PROSES SEWA GRUP ==========
  const result_sewa = linkGrub.split("https://chat.whatsapp.com/")[1];
  let res_linkgc = "";

  const currentDate = new Date();
  const expirationDate = new Date(
    currentDate.getTime() + totalHari * 24 * 60 * 60 * 1000 + 1 * 60 * 60 * 1000
  );
  const timestampExpiration = expirationDate.getTime();

  try {
    const res = await sock.query({
      tag: "iq",
      attrs: { type: "get", xmlns: "w:g2", to: "@g.us" },
      content: [{ tag: "invite", attrs: { code: result_sewa } }],
    });

    res_linkgc = res.content[0].attrs.id;
    const res_namegc = res.content[0].attrs.subject;
    res_linkgc = res_linkgc + "@g.us";

    await sock.groupAcceptInvite(result_sewa).catch((err) => console.log(err));

    // Simpan ke database sewa (yang lama)
    await addSewa(res_linkgc, {
      linkGrub: linkGrub,
      start: hariini,
      expired: timestampExpiration,
    });

    // Update statistik premium (kecuali owner)
    if (!isOwner && isPremium) {
      updateUserStats(sender, totalHari);
    }

    deleteCache(`sewa-${remoteJid}`);

    // Hitung sisa kuota untuk response
    let kuotaText = "";
    if (!isOwner && isPremium) {
      const stats = readPremiumStats()[sender] || { total_grup: 0, total_masa_sewa: 0 };
      const sisaGrup = 10 - stats.total_grup;
      const sisaHari = 365 - stats.total_masa_sewa;
      kuotaText = `\n\n*Sisa Kuota Sewa:*\n- Grup: ${sisaGrup}/10\n- Hari: ${sisaHari}/365`;
    }

    return await sock.sendMessage(
      remoteJid,
      {
        text:
          `> _Bot Berhasil Bergabung_\n\n` +
          `- Grup : *${res_namegc}*\n` +
          `- Durasi : *${totalHari} Hari*\n` +
          `- Expired : *${selisihHari(timestampExpiration)}*${kuotaText}\n` +
          `_Ketik *.ceksewa* di grup untuk cek status sewa_`,
      },
      { quoted: message }
    );
    
  } catch (error) {
    console.error("Gagal bergabung:", error);
    
    let info = "_Pastikan link grup valid._";
    if (error instanceof Error && error.message.includes("not-authorized")) {
      info = `_Kemungkinan bot pernah dikeluarkan. Undang manual atau masukkan ulang._`;
    }
    
    return await sock.sendMessage(
      remoteJid,
      {
        text: `⚠️ *Gagal bergabung*\n\n${info}`
      },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["sewa"],
  OnlyPremium: false,
  OnlyOwner: false,  // Biarin false, kita handle sendiri di atas
};