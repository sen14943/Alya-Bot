import { listSewa } from '../../src/lib/sewa.js';

async function handle(sock, messageInfo) {
  const { remoteJid, message, content, sender, prefix, command } = messageInfo;

  try {
    // Validasi input kosong atau tidak sesuai format
    if (
      !content ||
      content.trim() === "" ||
      !content.includes("whatsapp.com")
    ) {
      return await sock.sendMessage(
        remoteJid,
        {
          text: `_⚠️ Format Penggunaan:_ \n\n_💬 Contoh:_ _*${
            prefix + command
          } https://chat.whatsapp.com/xxx*_`,
        },
        { quoted: message }
      );
    }

    // Kirim reaksi ⏰ untuk menunjukkan sedang memproses
    await sock.sendMessage(remoteJid, {
      react: { text: "⏰", key: message.key },
    });

    // Ekstrak ID grup dari tautan
    const groupId = content.split("chat.whatsapp.com/")[1]?.split(" ")[0]?.split("?")[0];
    if (!groupId) {
      return await sock.sendMessage(
        remoteJid,
        { text: `⚠️ Tautan grup tidak valid.` },
        { quoted: message }
      );
    }

    // Ambil daftar sewa
    const sewa = await listSewa();
    
    // Cek apakah grup ada dalam daftar sewa
    if (!sewa || !sewa[groupId]) {
      return await sock.sendMessage(
        remoteJid,
        { 
          text: `> Akses Di Tolak, Sewabot Terlebih Dahulu`
        },
        { quoted: message }
      );
    }

    // Cek status expired
    const dataSewa = sewa[groupId];
    const sekarang = Math.floor(Date.now() / 1000);
    
    if (dataSewa.expired < sekarang) {
      return await sock.sendMessage(
        remoteJid,
        { 
          text: `⚠️ *Masa Sewa Telah Berakhir*\n\n` +
                `_Maaf, masa sewa grup ini sudah habis._\n\n` +
                `_Silakan perpanjang sewa untuk dapat menggunakan bot kembali._` 
        },
        { quoted: message }
      );
    }

    // Bergabung ke grup menggunakan invite link
    try {
      await sock.groupAcceptInvite(groupId);
      
      // Hitung sisa hari
      const sisaHari = Math.ceil((dataSewa.expired - sekarang) / (24 * 60 * 60));
      
      // Kirim pesan sukses dengan informasi detail
      await sock.sendMessage(
        remoteJid,
        { 
          text: `*Berhasil Bergabung*\n` +
                `- Nama Grup : ${dataSewa.namaGrup || 'Tidak diketahui'}\n` +
                `- Masa Aktif : ${sisaHari} Hari\n\n` +
                `> Terima kasih Telah Menggunakan Larabot!`
        },
        { quoted: message }
      );
      
      // Kirim pesan ke grup yang baru saja dimasuki
      try {
        await sock.sendMessage(
          groupId,
          { 
            text: `> Larabot\n\n` +
                  `Hello, How Are You?`
          }
        );
      } catch (groupError) {
        console.error("Gagal kirim pesan ke grup:", groupError);
      }
      
    } catch (error) {
      let info = "_Pastikan link grup valid._";

      // Periksa pesan error
      if (error instanceof Error && error.message.includes("not-authorized")) {
        info = `_Kemungkinan Anda pernah dikeluarkan dari grup. Solusi: undang bot kembali atau masukkan secara manual._`;
      }

      if (error instanceof Error && error.message.includes("conflict")) {
        info = `> Lara Sudah Bergabung\n` +
               `- Masa Aktif : ${Math.ceil((dataSewa.expired - sekarang) / (24 * 60 * 60))} Hari`;
      }

      // Kirim pesan error ke pengguna
      return await sock.sendMessage(
        remoteJid,
        {
          text: `⚠️ _Gagal bergabung ke grup._\n\n${info}`,
        },
        { quoted: message }
      );
    }
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    await sock.sendMessage(
      remoteJid,
      { text: `⚠️ Terjadi kesalahan saat memproses perintah.` },
      { quoted: message }
    );
  }
}

export default {
  handle,
  Commands: ["join"],
  OnlyPremium: false,
  OnlyOwner: false, // Bisa digunakan oleh user biasa, tapi hanya untuk grup yang ada di daftar sewa
};