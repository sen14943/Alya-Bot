import { generateQuote } from "../../api/canvas/quotes.js";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim() === "") {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: false,
            needText: true,
            example: "Hallo|Angela",
            description: "Buat quotes keren dengan background aesthetic.\n\n✨ Mode 1 (dengan author): .q Hallo|Angela\n✨ Mode 2 (tanpa author): .q Hallo (author otomatis 'User')",
            notes: "Pisahkan teks dan author dengan tanda | (vertical bar)",
            limits: "1 poin"
        });
    }

    try {
        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        // Parse teks dan author
        let quoteText, author;
        if (content.includes("|")) {
            const parts = content.split("|");
            quoteText = parts[0].trim();
            author = parts[1].trim();
            
            // Validasi setelah parse
            if (!quoteText) {
                return await sendHelpCard(sock, remoteJid, message, {
                    prefix: prefix,
                    command: command,
                    needImage: false,
                    needText: true,
                    example: "Hallo|Angela",
                    description: "Teks tidak boleh kosong!\n\nContoh: .q Hallo|Angela",
                    notes: "Pisahkan teks dan author dengan tanda |",
                    limits: "1 poin"
                });
            }
            
            if (!author) {
                author = "User";
            }
        } else {
            quoteText = content.trim();
            author = "User";
        }

        const buffer = await generateQuote(quoteText, author);

        await sock.sendMessage(remoteJid, {
            image: buffer,
            caption: `> ✅ Berhasil membuat quotes!\n\n*Teks:* ${quoteText}\n*Author:* ${author}\n\n*Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`
        }, { quoted: message });

        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        logCustom("error", `QUOTES-ERROR: ${error.message}`, `ERROR-COMMAND-quotes.txt`);
        await sock.sendMessage(remoteJid, { 
            text: `❌ Gagal membuat quotes: ${error.message}\n\n💡 Pastikan teks tidak kosong dan coba lagi nanti.` 
        }, { quoted: message });
        
        await sock.sendMessage(remoteJid, { react: { text: "❌", key: message.key } });
    }
}

export default {
    handle,
    Commands: ["q", "quote"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
};