import { generateFakeFFAuto } from "../../api/canvas/fakeff.js";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim() === "") {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: false,
            needText: true,
            example: "Angela",
            description: "Buat foto profil palsu ala Free Fire.\n\n✨ Mode Single: cukup tulis nama\n✨ Mode Duo: pisahkan dengan | (contoh: Angela|Senkai)",
            notes: "Bisa pakai nama sendiri atau nama teman!",
            limits: "1 poin"
        });
    }

    try {
        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        let buffer;
        let name1, name2;

        // Deteksi mode duo atau single
        if (content.includes("|")) {
            const parts = content.split("|");
            name1 = parts[0].trim();
            name2 = parts[1].trim();
            
            if (!name1 || !name2) {
                return await sendHelpCard(sock, remoteJid, message, {
                    prefix: prefix,
                    command: command,
                    needImage: false,
                    needText: true,
                    example: "Angela|Senkai",
                    description: "Mode duo: pisahkan 2 nama dengan tanda |\n\nContoh: .ff Angela|Senkai",
                    notes: "Pastikan kedua nama tidak kosong!",
                    limits: "1 poin"
                });
            }
            
            console.log(`[FAKEFF] Mode DUO: "${name1}" & "${name2}"`);
        } else {
            name1 = content;
            name2 = null;
            console.log(`[FAKEFF] Mode SINGLE: "${name1}"`);
        }

        buffer = await generateFakeFFAuto(name1, name2);

        if (!buffer || buffer.length < 5000) {
            throw new Error("Gambar yang dihasilkan terlalu kecil atau rusak");
        }

        const sizeKB = (buffer.length / 1024).toFixed(2);
        console.log(`[FAKEFF] Berhasil generate foto (${sizeKB}KB)`);

        // Buat caption berdasarkan mode
        let caption = `
> Berhasil Kak!

*Nama:* ${name1}`;
        
        if (name2) {
            caption += `\n*Nama 2:* ${name2}`;
        }
        
        caption += `
*Ukuran:* ${sizeKB} KB
*Mode:* ${name2 ? "Duo 👥" : "Single 👤"}
*Models:* Lara-Ai

*Saluran Kami:*
https://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`;

        await sock.sendMessage(remoteJid, {
            image: buffer,
            caption: caption
        }, { quoted: message });

        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        logCustom("error", `FAKEFF-ERROR: ${error.message}`, `ERROR-COMMAND-fakeff.txt`);
        
        await sock.sendMessage(remoteJid, { 
            text: `❌ Gagal: ${error.message}\n\n💡 Format duo: nama|nama2 (contoh: .ff Angela|Senkai)` 
        }, { quoted: message });
        
        await sock.sendMessage(remoteJid, { react: { text: "❌", key: message.key } });
    }
}

export default {
    handle,
    Commands: ["fakeff", "ff"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
};