// plugins/iqc.js
import { logCustom } from "../../src/lib/logger.js";
import { createQuote } from "../../api/canvas/iqc.js";
import { sendHelpCard } from "../../case/help.js";

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim() === "") {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: false,
            needText: true,
            example: "halo dunia!",
            description: "Ubah teks jadi quote aesthetic dengan background keren.",
            notes: "Bisa pakai bahasa Indonesia atau Inggris, makin panjang teks makin keren!",
            limits: "1 poin"
        });
    }

    try {
        let text = content && content.trim() !== "" ? content : isQuoted?.text ?? null;

        if (!text) {
            return await sendHelpCard(sock, remoteJid, message, {
                prefix: prefix,
                command: command,
                needImage: false,
                needText: true,
                example: "halo dunia!",
                description: "Ubah teks jadi quote aesthetic dengan background keren.",
                notes: "Bisa pakai bahasa Indonesia atau Inggris, makin panjang teks makin keren!",
                limits: "1 poin"
            });
        }

        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        // ===============================
        // PAKAI LIBRARY IQC DARI SCRAPE
        // ===============================
        const buffer = await createQuote(text);

        await sock.sendMessage(remoteJid, {
            image: buffer,
            caption: `> Quote Berhasil Di Buat!\n\n*Create BY: Elaina-AI*\n*Teks:* ${text}\n\n*Link Saluran Kami:*\nhttps://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`
        }, { quoted: message });

        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        console.error('Error in iqc command:', error);
        logCustom("info", content, `ERROR-COMMAND-${command}.txt`);
        
        await sock.sendMessage(remoteJid, { 
            react: { text: "❌", key: message.key } 
        }).catch(() => {});
        
        await sock.sendMessage(remoteJid, { 
            text: `❌ *Gagal membuat quote*\n\n📌 *Error:* ${error.message}\n\n💡 Silakan coba lagi nanti.` 
        }, { quoted: message });
    }
}

export default {
    handle,
    Commands: ["iqc"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
};