// commands/fakeml.js
import { downloadQuotedMedia, downloadMedia } from "../../src/lib/utils.js";
import { createFakeML } from "../../api/canvas/fakeml.js";
import { getProfileBuffer } from "../../api/support/get_profile.js";
import { logCustom } from "../../src/lib/logger.js";
import { sendHelpCard } from "../../case/help.js";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const mainDir = path.resolve(__dirname, "../../");
const tmpDir = path.join(mainDir, "storage", "tmp");
const avatarDir = path.join(mainDir, "assets", "avatar");

// Fungsi untuk mendapatkan avatar random dari folder assets
function getRandomAvatarBuffer() {
    try {
        // Pastikan folder avatar ada
        if (!fs.existsSync(avatarDir)) {
            console.log(`[FAKEML] Folder avatar tidak ditemukan: ${avatarDir}`);
            return null;
        }
        
        // Baca semua file di folder avatar
        const files = fs.readdirSync(avatarDir);
        
        // Filter hanya file gambar jpg/jpeg/png
        const imageFiles = files.filter(file => 
            file.match(/\.(jpg|jpeg|png)$/i)
        );
        
        if (imageFiles.length === 0) {
            console.log(`[FAKEML] Tidak ada file gambar di folder avatar`);
            return null;
        }
        
        // Pilih random file
        const randomFile = imageFiles[Math.floor(Math.random() * imageFiles.length)];
        const avatarPath = path.join(avatarDir, randomFile);
        
        // Baca file menjadi buffer
        const avatarBuffer = fs.readFileSync(avatarPath);
        console.log(`[FAKEML] Menggunakan avatar random: ${randomFile}`);
        
        return avatarBuffer;
    } catch (error) {
        console.log(`[FAKEML] Gagal membaca avatar random: ${error.message}`);
        return null;
    }
}

async function handle(sock, messageInfo) {
    const { remoteJid, message, content, isQuoted, prefix, command, sender, type } = messageInfo;

    // ===============================
    // CEK APAKAH USER MINTA BANTUAN
    // ===============================
    if (!content || content.trim() === "") {
        return await sendHelpCard(sock, remoteJid, message, {
            prefix: prefix,
            command: command,
            needImage: false,
            needText: true,
            example: "Misaki",
            description: "Buat kartu profil palsu ala Mobile Legends.\n\n✨ Bisa reply gambar untuk pakai foto custom\n✨ Tanpa gambar akan pakai foto profil WA\n✨ Kalau gagal ambil foto WA, pakai avatar random",
            notes: "Bisa pakai nama sendiri atau nama hero ML!",
            limits: "1 poin"
        });
    }

    try {
        let name = content && content.trim() !== "" ? content : null;

        await sock.sendMessage(remoteJid, { react: { text: "⏰", key: message.key } });

        let buffer;
        let avatarBuffer = null;
        let usedDefaultAvatar = false;
        let avatarSource = "default";

        // ===============================
        // DOWNLOAD GAMBAR DARI REPLY ATAU KIRIMAN
        // ===============================
        
        // Cek apakah ada reply gambar
        if (isQuoted && isQuoted.type === "imageMessage") {
            try {
                const mediaFileName = await downloadQuotedMedia(message);
                if (mediaFileName) {
                    const mediaPath = path.join(tmpDir, mediaFileName);
                    if (fs.existsSync(mediaPath)) {
                        avatarBuffer = fs.readFileSync(mediaPath);
                        avatarSource = "custom (reply)";
                        console.log(`[FAKEML] Menggunakan avatar dari reply gambar`);
                        fs.unlinkSync(mediaPath);
                    }
                }
            } catch (e) {
                console.log(`[FAKEML] Gagal download reply gambar: ${e.message}`);
            }
        } 
        // Cek apakah kirim gambar langsung (tanpa reply)
        else if (type === "imageMessage") {
            try {
                const mediaFileName = await downloadMedia(message);
                if (mediaFileName) {
                    const mediaPath = path.join(tmpDir, mediaFileName);
                    if (fs.existsSync(mediaPath)) {
                        avatarBuffer = fs.readFileSync(mediaPath);
                        avatarSource = "custom (direct)";
                        console.log(`[FAKEML] Menggunakan avatar dari kiriman gambar`);
                        fs.unlinkSync(mediaPath);
                    }
                }
            } catch (e) {
                console.log(`[FAKEML] Gagal download kiriman gambar: ${e.message}`);
            }
        }

        // ===============================
        // GENERATE FAKE ML
        // ===============================
        
        if (avatarBuffer) {
            // Pakai avatar dari reply/kiriman
            buffer = await createFakeML(name, avatarBuffer);
        } else {
            // Coba ambil dari foto profil WhatsApp pake lib get_profile
            try {
                const profileBuffer = await getProfileBuffer(sock, sender);
                if (profileBuffer) {
                    buffer = await createFakeML(name, profileBuffer);
                    avatarSource = "whatsapp profile";
                    console.log(`[FAKEML] Menggunakan foto profil WhatsApp`);
                } else {
                    throw new Error("Profile buffer kosong");
                }
            } catch (error) {
                // Kalau gagal ambil dari WA, pakai avatar random dari assets
                console.log(`[FAKEML] Gagal ambil foto profil: ${error.message}`);
                
                const randomAvatarBuffer = getRandomAvatarBuffer();
                if (randomAvatarBuffer) {
                    buffer = await createFakeML(name, randomAvatarBuffer);
                    avatarSource = "random avatar (assets)";
                    usedDefaultAvatar = true;
                    console.log(`[FAKEML] Menggunakan avatar random dari folder assets`);
                } else {
                    // Fallback terakhir: pakai default avatar dari URL
                    console.log(`[FAKEML] Fallback ke default avatar URL`);
                    const defaultRes = await fetch('https://i.imgur.com/8Km9tLL.png');
                    const defaultBuffer = Buffer.from(await defaultRes.arrayBuffer());
                    buffer = await createFakeML(name, defaultBuffer);
                    avatarSource = "default URL (last fallback)";
                    usedDefaultAvatar = true;
                }
            }
        }

        if (!buffer || buffer.length < 5000) {
            throw new Error("Gambar yang dihasilkan terlalu kecil atau rusak");
        }

        const sizeKB = (buffer.length / 1024).toFixed(2);
        console.log(`[FAKEML] Berhasil generate foto (${sizeKB}KB) dari source: ${avatarSource}`);

        // Kirim hasil
        await sock.sendMessage(remoteJid, {
            image: buffer,
            caption: `
> ✨ *FAKE ML PROFILE CARD* ✨

┌─❖
│ 🎮 *Nama:* ${name}
│ 📦 *Ukuran:* ${sizeKB} KB
│ 👤 *Avatar:* ${avatarSource}
└────────────┻

*Saluran Kami:*
https://whatsapp.com/channel/0029VbCKkrsBPzjdL6T68C2y`
        }, { quoted: message });

        await sock.sendMessage(remoteJid, { react: { text: "✅", key: message.key } });

    } catch (error) {
        logCustom("error", `FAKEML-ERROR: ${error.message}`, `ERROR-COMMAND-fakeml.txt`);
        console.error("[FAKEML]", error);
        
        await sock.sendMessage(remoteJid, { 
            text: `❌ Gagal: ${error.message}\n\n💡 Tips: Coba lagi dengan nama yang berbeda atau kirim foto profil` 
        }, { quoted: message });
        
        await sock.sendMessage(remoteJid, { react: { text: "❌", key: message.key } });
    }
}

export default {
    handle,
    Commands: ["fakeml", "mlfake", "mlcard", "ml"],
    OnlyPremium: false,
    OnlyOwner: false,
    limitDeduction: 1,
};