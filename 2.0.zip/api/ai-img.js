// editorai.js
import axios from 'axios';

const BASE_URL = 'https://api-faa.my.id/faa/editfoto';

/**
 * Mengedit foto dengan AI berdasarkan prompt
 * @param {string} imageUrl - URL gambar yang akan diedit
 * @param {string} prompt - Perintah edit (contoh: "jadikan anime", "cantik", "background merah")
 * @returns {Promise<Buffer>} - Buffer gambar hasil edit
 */
export async function editImage(imageUrl, prompt) {
    try {
        if (!imageUrl || imageUrl.trim() === '') {
            throw new Error('URL gambar tidak boleh kosong');
        }
        
        if (!prompt || prompt.trim() === '') {
            throw new Error('Prompt tidak boleh kosong');
        }

        console.log(`🖼️ Mengedit gambar: ${imageUrl}`);
        console.log(`📝 Prompt: ${prompt}`);

        // Panggil API dengan URL dan prompt
        const apiUrl = `${BASE_URL}?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(prompt)}`;
        
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer',
            timeout: 190000, // AI butuh waktu lebih lama
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (response.status === 200 && response.data) {
            console.log('✅ Gambar berhasil diedit');
            return Buffer.from(response.data);
        }
        
        throw new Error(`Gagal mengedit gambar: HTTP ${response.status}`);

    } catch (error) {
        console.error('Error editImage:', error.message);
        throw new Error(`Gagal mengedit gambar: ${error.message}`);
    }
}

/**
 * Mengedit foto dan mengembalikan sebagai base64
 * @param {string} imageUrl - URL gambar
 * @param {string} prompt - Perintah edit
 * @returns {Promise<string>} - Base64 string gambar
 */
export async function editImageToBase64(imageUrl, prompt) {
    const buffer = await editImage(imageUrl, prompt);
    return buffer.toString('base64');
}

/**
 * Mengedit foto dan simpan ke file
 * @param {string} imageUrl - URL gambar
 * @param {string} prompt - Perintah edit
 * @param {string} outputPath - Path untuk menyimpan file (opsional)
 * @returns {Promise<string>} - Path file yang disimpan
 */
export async function editImageAndSave(imageUrl, prompt, outputPath = null) {
    const buffer = await editImage(imageUrl, prompt);
    
    if (!outputPath) {
        const fs = await import('fs');
        const path = await import('path');
        const timestamp = Date.now();
        const safePrompt = prompt.replace(/[^a-z0-9]/gi, '_').slice(0, 20);
        outputPath = path.join(process.cwd(), 'temp', `edit_${safePrompt}_${timestamp}.jpg`);
        
        // Pastikan folder temp ada
        const tempDir = path.join(process.cwd(), 'temp');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }
    }
    
    const fs = await import('fs');
    fs.writeFileSync(outputPath, buffer);
    console.log(`💾 Gambar hasil edit disimpan: ${outputPath}`);
    
    return outputPath;
}

export default {
    editImage,
    editImageToBase64,
    editImageAndSave
};