// uploader.js
import axios from 'axios';
import FormData from 'form-data';
import fs from 'fs';
import path from 'path';
import ApiAutoresbotModule from 'api-autoresbot';
const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;
import config from '../config.js';

// Maksimal ukuran file: 5MB
const MAX_FILE_SIZE_BYTES = 5 * 1024 * 1024;

// Fungsi delay
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// Fungsi untuk cek ukuran file
function checkFileSize(filePath) {
    const stats = fs.statSync(filePath);
    if (stats.size > MAX_FILE_SIZE_BYTES) {
        const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
        throw new Error(`Ukuran file melebihi batas maksimal 5MB (${fileSizeMB}MB)`);
    }
    return true;
}

// Fungsi untuk melakukan request dengan retry mechanism (3 kali)
async function requestWithRetry(requestFn, maxRetries = 3, delayMs = 3000) {
  let lastError = null;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🔄 Percobaan ke-${attempt}/${maxRetries}`);
      const result = await requestFn();
      console.log(`✅ Berhasil pada percobaan ke-${attempt}`);
      return result;
    } catch (error) {
      lastError = error;
      console.log(`❌ Percobaan ke-${attempt} gagal: ${error.message}`);
      
      if (attempt === maxRetries) {
        console.log(`Gagal setelah ${maxRetries} kali percobaan`);
        break;
      }
      
      console.log(`⏳ Menunggu ${delayMs/1000} detik sebelum mencoba lagi...`);
      await delay(delayMs);
    }
  }
  
  throw lastError;
}

/**
 * Upload ke Catbox (fallback)
 * @param {string} filePath - Path file yang akan diupload
 * @returns {Promise<string>} - URL hasil upload
 */
async function uploadToCatbox(filePath) {
  try {
    console.log('📤 Mencoba upload ke Catbox (fallback)...');
    
    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", fs.createReadStream(filePath));

    const response = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: {
        ...form.getHeaders(),
      },
      timeout: 60000
    });
    
    if (!response.data || response.data.includes('error')) {
      throw new Error('Upload ke Catbox gagal');
    }
    
    console.log('✅ Upload ke Catbox berhasil');
    return response.data;
  } catch (error) {
    console.error("❌ Catbox upload failed:", error.response ? error.response.data : error.message);
    throw new Error("Upload ke Catbox gagal.");
  }
}

/**
 * Upload ke Autoresbot (primary)
 * @param {string} filePath - Path file yang akan diupload
 * @returns {Promise<string>} - URL hasil upload
 */
async function uploadToAutoresbot(filePath) {
  try {
    console.log('📤 Mencoba upload ke Autoresbot (primary)...');
    
    const api = new ApiAutoresbot(config.APIKEY);
    const upload = await api.tmpUpload(filePath);
    
    if (!upload || upload.code !== 200) {
      throw new Error('Upload failed: ' + (upload?.message || 'Unknown error'));
    }
    
    console.log('✅ Upload ke Autoresbot berhasil');
    return upload.data.url;

  } catch (error) {
    console.error('❌ Autoresbot upload failed:', error.message);
    throw error;
  }
}

/**
 * Upload file dengan prioritas Autoresbot, fallback Catbox
 * @param {string} filePath - Path file yang akan diupload
 * @returns {Promise<string>} - URL hasil upload
 */
export async function uploadFile(filePath) {
    try {
        if (!fs.existsSync(filePath)) {
            throw new Error(`File tidak ditemukan: ${filePath}`);
        }

        // CEK UKURAN FILE (MAKS 5MB)
        checkFileSize(filePath);

        // Coba upload ke Autoresbot dulu (dengan retry 3 kali)
        try {
            const autoresbotUrl = await requestWithRetry(
                () => uploadToAutoresbot(filePath),
                3,
                3000
            );
            return autoresbotUrl;
        } catch (autoresbotError) {
            console.log('⚠️ Autoresbot gagal setelah 3 percobaan, beralih ke Catbox...');
            
            // Fallback ke Catbox (dengan retry 3 kali)
            const catboxUrl = await requestWithRetry(
                () => uploadToCatbox(filePath),
                3,
                3000
            );
            return catboxUrl;
        }

    } catch (error) {
        console.error('❌ Error upload file:', error.message);
        throw error;
    }
}

/**
 * Upload buffer sebagai file
 * @param {Buffer} buffer - Buffer data file
 * @param {string} filename - Nama file (contoh: 'audio.mp3')
 * @returns {Promise<string>} - URL hasil upload
 */
export async function uploadBuffer(buffer, filename) {
    try {
        // CEK UKURAN BUFFER (MAKS 5MB)
        if (buffer.length > MAX_FILE_SIZE_BYTES) {
            const bufferSizeMB = (buffer.length / (1024 * 1024)).toFixed(2);
            throw new Error(`Ukuran buffer melebihi batas maksimal 5MB (${bufferSizeMB}MB)`);
        }

        // Simpan buffer ke file temporary terlebih dahulu
        const tempDir = './storage/tmp';
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }
        
        const tempFilePath = path.join(tempDir, filename);
        fs.writeFileSync(tempFilePath, buffer);
        
        // Upload file tersebut
        const url = await uploadFile(tempFilePath);
        
        // Hapus file temporary
        fs.unlinkSync(tempFilePath);
        
        return url;

    } catch (error) {
        console.error('Error upload buffer:', error.message);
        throw error;
    }
}

/**
 * Upload file dan hapus file lokal setelah sukses (opsional)
 * @param {string} filePath - Path file
 * @param {boolean} deleteAfter - Hapus setelah upload (default false)
 * @returns {Promise<string>} - URL hasil upload
 */
export async function uploadAndClean(filePath, deleteAfter = false) {
    const url = await uploadFile(filePath);
    
    if (deleteAfter && fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
        console.log(`🗑️ File dihapus: ${filePath}`);
    }
    
    return url;
}

export default {
    uploadFile,
    uploadBuffer,
    uploadAndClean
};