// bgremover.js
import axios from 'axios';

const BASE_URL = 'https://api-faa.my.id/faa/removebg';

/**
 * Menghapus background gambar
 * @param {string} imageUrl - URL gambar yang akan dihapus backgroundnya
 * @returns {Promise<Buffer>} - Buffer gambar hasil tanpa background (PNG)
 */
export async function removeBackground(imageUrl) {
    try {
        if (!imageUrl || imageUrl.trim() === '') {
            throw new Error('URL gambar tidak boleh kosong');
        }

        console.log(`🖼️ Menghapus background: ${imageUrl}`);

        // Panggil API untuk mendapatkan URL hasil
        const apiUrl = `${BASE_URL}?url=${encodeURIComponent(imageUrl)}`;
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (!response.data?.status || !response.data?.url) {
            throw new Error('Gagal memproses gambar: response tidak valid');
        }

        const resultUrl = response.data.url;
        console.log(`📥 Mendownload hasil: ${resultUrl}`);

        // Download gambar hasil
        const imageResponse = await axios.get(resultUrl, {
            responseType: 'arraybuffer',
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (imageResponse.status === 200 && imageResponse.data) {
            console.log('✅ Background berhasil dihapus');
            return Buffer.from(imageResponse.data);
        }

        throw new Error(`Gagal mendownload hasil: HTTP ${imageResponse.status}`);

    } catch (error) {
        console.error('Error removeBackground:', error.message);
        throw new Error(`Gagal menghapus background: ${error.message}`);
    }
}

/**
 * Menghapus background dan mengembalikan sebagai base64
 * @param {string} imageUrl - URL gambar
 * @returns {Promise<string>} - Base64 string gambar PNG
 */
export async function removeBackgroundToBase64(imageUrl) {
    const buffer = await removeBackground(imageUrl);
    return buffer.toString('base64');
}

/**
 * Menghapus background dan simpan ke file
 * @param {string} imageUrl - URL gambar
 * @param {string} outputPath - Path untuk menyimpan file (opsional)
 * @returns {Promise<string>} - Path file yang disimpan
 */
export async function removeBackgroundAndSave(imageUrl, outputPath = null) {
    const buffer = await removeBackground(imageUrl);
    
    if (!outputPath) {
        const fs = await import('fs');
        const path = await import('path');
        const timestamp = Date.now();
        outputPath = path.join(process.cwd(), 'temp', `nobg_${timestamp}.png`);
        
        // Pastikan folder temp ada
        const tempDir = path.join(process.cwd(), 'temp');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }
    }
    
    const fs = await import('fs');
    fs.writeFileSync(outputPath, buffer);
    console.log(`💾 Gambar tanpa background disimpan: ${outputPath}`);
    
    return outputPath;
}

/**
 * Mendapatkan URL hasil tanpa mendownload (jika hanya perlu URL)
 * @param {string} imageUrl - URL gambar
 * @returns {Promise<string>} - URL gambar hasil
 */
export async function getRemoveBgUrl(imageUrl) {
    try {
        if (!imageUrl || imageUrl.trim() === '') {
            throw new Error('URL gambar tidak boleh kosong');
        }

        const apiUrl = `${BASE_URL}?url=${encodeURIComponent(imageUrl)}`;
        const response = await axios.get(apiUrl, {
            timeout: 30000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (!response.data?.status || !response.data?.url) {
            throw new Error('Gagal memproses gambar');
        }

        return response.data.url;

    } catch (error) {
        console.error('Error getRemoveBgUrl:', error.message);
        throw new Error(`Gagal mendapatkan URL: ${error.message}`);
    }
}

export default {
    removeBackground,
    removeBackgroundToBase64,
    removeBackgroundAndSave,
    getRemoveBgUrl
};