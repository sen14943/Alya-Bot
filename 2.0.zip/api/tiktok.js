import axios from "axios";
import * as cheerio from "cheerio";

const MAX_RETRY = 5; // bisa ubah kalau mau lebih banyak
const RETRY_DELAY = 3000; // 15 detik
const TIMEOUT = 120000; // 120 detik

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function requestWithRetry(config, attempt = 1) {
  try {
    return await axios({
      timeout: TIMEOUT,
      ...config,
    });
  } catch (err) {
    if (attempt >= MAX_RETRY) {
      throw new Error(`Gagal setelah ${MAX_RETRY}x percobaan: ${err.message}`);
    }

    console.log(`⚠️ Retry ${attempt}/${MAX_RETRY} - Tunggu 15 detik...`);
    await delay(RETRY_DELAY);
    return requestWithRetry(config, attempt + 1);
  }
}

/**
 * TikTok Downloader
 */
async function tiktok(url) {
  const params = new URLSearchParams();
  params.set("url", url);
  params.set("hd", "1");

  const response = await requestWithRetry({
    method: "POST",
    url: "https://tikwm.com/api/",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      Cookie: "current_language=en",
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
    },
    data: params,
  });

  const data = response?.data?.data;
  if (!data) throw new Error("Data video tidak ditemukan.");

  return {
    title: data.title,
    cover: data.cover,
    origin_cover: data.origin_cover,
    no_watermark: data.play,
    watermark: data.wmplay,
    music: data.music,
  };
}

/**
 * TikTok Search
 */
async function tiktokSearch(keywords) {
  const response = await requestWithRetry({
    method: "POST",
    url: "https://tikwm.com/api/feed/search",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      Cookie: "current_language=en",
      "User-Agent":
        "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
    },
    data: {
      keywords,
      count: 50,
      cursor: 0,
      HD: 1,
    },
  });

  const videos = response?.data?.data?.videos;
  if (!videos || videos.length === 0)
    throw new Error("Tidak ada video ditemukan.");

  const selected = videos[Math.floor(Math.random() * videos.length)];

  return {
    title: selected.title,
    cover: selected.cover,
    origin_cover: selected.origin_cover,
    no_watermark: selected.play,
    watermark: selected.wmplay,
    music: selected.music,
  };
}

/**
 * TikTok Slide Downloader
 */
async function ttslide(url) {
  const response = await requestWithRetry({
    method: "GET",
    url: `https://dlpanda.com/id?url=${url}&token=G7eRpMaa`,
  });

  const $ = cheerio.load(response.data);
  const images = [];
  const creator = "Jikarinka";

  $("div.col-md-12 > img").each((_, el) => {
    const src = $(el).attr("src");
    if (src) images.push(src);
  });

  if (images.length === 0)
    throw new Error("Tidak ada gambar ditemukan.");

  return {
    creator,
    images: images.map(img => ({ img, creator })),
  };
}

export { tiktok, tiktokSearch, ttslide };