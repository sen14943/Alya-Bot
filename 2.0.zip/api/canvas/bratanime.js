import axios from 'axios';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function fetchImage(url, maxRetries = 2) {
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`🔄 BRATANIME percobaan ke-${attempt}/${maxRetries}`);
            
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });
            
            if (response.status !== 200) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const buffer = Buffer.from(response.data);
            
            if (!buffer || buffer.length < 5000) {
                throw new Error('Buffer kosong atau terlalu kecil');
            }
            
            console.log(`✅ BRATANIME berhasil (${buffer.length} bytes)`);
            return buffer;
            
        } catch (error) {
            lastError = error;
            console.log(`❌ Percobaan ke-${attempt} gagal: ${error.message}`);
            
            if (attempt < maxRetries) {
                await delay(2000);
            }
        }
    }
    
    throw lastError;
}

/**
 * Generate stiker BRAT versi anime
 * @param {string} text - Teks untuk stiker
 * @returns {Promise<Buffer>}
 */
export async function generateBratAnime(text) {
    if (!text?.trim()) {
        throw new Error('Teks tidak boleh kosong');
    }
    
    const url = `https://api.ourin.my.id/api/bratanime?text=${encodeURIComponent(text)}`;
    const buffer = await fetchImage(url);
    
    return buffer;
}

export default {
    generateBratAnime
};