import axios from 'axios';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const MAX_RETRIES = 2;
const RETRY_DELAY = 2000;
const TIMEOUT = 30000;

async function fetchImage(url, maxRetries = MAX_RETRIES) {
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`🔄 QUOTES percobaan ke-${attempt}/${maxRetries}`);
            
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: TIMEOUT,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (response.status !== 200) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const buffer = Buffer.from(response.data);
            
            if (!buffer || buffer.length < 5000) {
                throw new Error('Buffer kosong atau file terlalu kecil');
            }
            
            console.log(`✅ QUOTES berhasil (${buffer.length} bytes)`);
            return buffer;
            
        } catch (error) {
            lastError = error;
            console.log(`❌ Percobaan ke-${attempt} gagal: ${error.message}`);
            
            if (attempt < maxRetries) {
                console.log(`⏳ Menunggu ${RETRY_DELAY}ms sebelum retry...`);
                await delay(RETRY_DELAY);
            }
        }
    }
    
    throw new Error(`Gagal setelah ${maxRetries} percobaan: ${lastError?.message}`);
}

/**
 * Generate gambar quotes
 * @param {string} text - Teks quote
 * @param {string} author - Nama author/pembuat quote
 * @returns {Promise<Buffer>}
 */
export async function generateQuote(text, author = "User") {
    if (!text || text.trim() === '') {
        throw new Error('Teks quote tidak boleh kosong');
    }
    
    const url = `https://api.azbry.com/api/maker/quotesmaker?text=${encodeURIComponent(text)}&author=${encodeURIComponent(author)}`;
    console.log(`📱 Memanggil API Quotes dengan teks: "${text}", author: "${author}"`);
    
    const buffer = await fetchImage(url);
    return buffer;
}

export default {
    generateQuote
};