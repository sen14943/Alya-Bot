import axios from 'axios';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import fs from 'fs/promises';

// ==================== CONFIG ====================
const MAX_RETRIES = 1;
const RETRY_DELAY = 3000; // 3 detik delay antara retry
const TIMEOUT = 15000; // 15 detik timeout per request
const FIRST_API_DELAY = 6000; // 6 detik tunggu API pertama

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ==================== CACHE SYSTEM ====================
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// File cache untuk BRAT sticker
const BRAT_CACHE_FILE = join(__dirname, 'brat_performance.json');
// File cache untuk BRAT video
const BRAT_VIDEO_CACHE_FILE = join(__dirname, 'brat_video_performance.json');

// Cache structures
let bratCache = {
    fastestApi: null,
    lastUpdated: null,
    hitCount: {},
    avgResponseTime: {},
    totalRequests: 0
};

let bratVideoCache = {
    fastestApi: null,
    lastUpdated: null,
    hitCount: {},
    avgResponseTime: {},
    totalRequests: 0
};

// ==================== CACHE FUNCTIONS ====================
async function loadCache(cacheFile, cacheObject) {
    try {
        const exists = await fs.access(cacheFile).then(() => true).catch(() => false);
        
        if (exists) {
            const data = await fs.readFile(cacheFile, 'utf-8');
            const loaded = JSON.parse(data);
            cacheObject.fastestApi = loaded.fastestApi || null;
            cacheObject.lastUpdated = loaded.lastUpdated || null;
            cacheObject.hitCount = loaded.hitCount || {};
            cacheObject.avgResponseTime = loaded.avgResponseTime || {};
            cacheObject.totalRequests = loaded.totalRequests || 0;
            console.log(`📂 Cache berhasil dimuat dari ${cacheFile}:`, {
                fastestApi: cacheObject.fastestApi,
                totalRequests: cacheObject.totalRequests
            });
        } else {
            console.log(`📂 File cache tidak ditemukan: ${cacheFile}`);
            await saveCache(cacheFile, cacheObject);
        }
    } catch (error) {
        console.log(`⚠️ Gagal load cache: ${error.message}`);
    }
}

async function saveCache(cacheFile, cacheObject) {
    try {
        await fs.writeFile(cacheFile, JSON.stringify(cacheObject, null, 2), 'utf-8');
        console.log(`💾 Cache berhasil disimpan ke ${cacheFile}`);
    } catch (error) {
        console.log(`⚠️ Gagal menyimpan cache: ${error.message}`);
    }
}

async function recordPerformance(cacheObject, cacheFile, apiName, responseTime) {
    if (!cacheObject.hitCount[apiName]) {
        cacheObject.hitCount[apiName] = 0;
        cacheObject.avgResponseTime[apiName] = 0;
    }
    
    // Update hit count
    cacheObject.hitCount[apiName]++;
    cacheObject.totalRequests++;
    
    // Update average response time (moving average)
    const currentAvg = cacheObject.avgResponseTime[apiName];
    const newAvg = ((currentAvg * (cacheObject.hitCount[apiName] - 1)) + responseTime) / cacheObject.hitCount[apiName];
    cacheObject.avgResponseTime[apiName] = Math.round(newAvg);
    
    // Update fastest API
    let fastest = null;
    let fastestTime = Infinity;
    for (const [api, avgTime] of Object.entries(cacheObject.avgResponseTime)) {
        if (avgTime < fastestTime && cacheObject.hitCount[api] >= 1) {
            fastestTime = avgTime;
            fastest = api;
        }
    }
    
    if (fastest && fastest !== cacheObject.fastestApi) {
        cacheObject.fastestApi = fastest;
        cacheObject.lastUpdated = new Date().toISOString();
        console.log(`🏆 API tercepat baru: ${fastest} (avg: ${fastestTime}ms)`);
        await saveCache(cacheFile, cacheObject);
    }
    
    console.log(`📊 Performa: ${apiName} -> ${responseTime}ms (avg: ${cacheObject.avgResponseTime[apiName]}ms, hits: ${cacheObject.hitCount[apiName]})`);
    
    await saveCache(cacheFile, cacheObject);
}

function getApiOrder(apis, cacheObject) {
    if (!cacheObject.fastestApi || cacheObject.totalRequests < 3) {
        console.log(`📋 Menggunakan urutan default (belum cukup data: ${cacheObject.totalRequests} request)`);
        return apis;
    }
    
    const sorted = [...apis].sort((a, b) => {
        const timeA = cacheObject.avgResponseTime[a.name] || Infinity;
        const timeB = cacheObject.avgResponseTime[b.name] || Infinity;
        return timeA - timeB;
    });
    
    console.log(`📋 Urutan prioritas: ${sorted.map(a => `${a.name}(${cacheObject.avgResponseTime[a.name] || '?'}ms)`).join(' → ')}`);
    return sorted;
}

// ==================== FETCH WITH TIMEOUT ====================
async function fetchMedia(url, timeout = TIMEOUT) {
    const startTime = Date.now();
    
    try {
        console.log(`🔄 Mencoba: ${url.substring(0, 80)}...`);
        
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: timeout,
            headers: { 
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });
        
        if (response.status !== 200) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const buffer = Buffer.from(response.data);
        
        if (!buffer || buffer.length < 5000) {
            throw new Error('Buffer kosong atau terlalu kecil');
        }
        
        const responseTime = Date.now() - startTime;
        console.log(`✅ Berhasil (${buffer.length} bytes) dalam ${responseTime}ms`);
        
        return { buffer, responseTime };
        
    } catch (error) {
        const responseTime = Date.now() - startTime;
        if (error.code === 'ECONNABORTED') {
            console.log(`❌ Timeout setelah ${responseTime}ms`);
            throw new Error('Timeout setelah 15 detik');
        }
        console.log(`❌ Gagal dalam ${responseTime}ms: ${error.message}`);
        throw error;
    }
}

// ==================== MAIN EXPORTS ====================
/**
 * Generate sticker BRAT gambar dengan sistem prioritas API tercepat
 */
export async function generateBratSticker(text) {
    if (!text?.trim()) throw new Error('Teks tidak boleh kosong');
    
    // Load cache
    await loadCache(BRAT_CACHE_FILE, bratCache);
    
    const apis = [
        {
            url: `https://api-faa.my.id/faa/brathd?text=${encodeURIComponent(text)}`,
            name: 'FAA API'
        },
        {
            url: `https://api.nexray.eu.cc/maker/brathd?text=${encodeURIComponent(text)}`,
            name: 'Nexray API'
        }
    ];
    
    // Urutkan API berdasarkan performa
    const orderedApis = getApiOrder(apis, bratCache);
    
    try {
        console.log(`📷 Memulai generate BRAT sticker dengan prioritas tertinggi: ${orderedApis[0].name}`);
        
        // Coba API pertama (prioritas tertinggi)
        try {
            const { buffer, responseTime } = await fetchMedia(orderedApis[0].url, TIMEOUT);
            await recordPerformance(bratCache, BRAT_CACHE_FILE, orderedApis[0].name, responseTime);
            console.log(`✅ Berhasil dari ${orderedApis[0].name}`);
            return buffer;
        } catch (error1) {
            console.log(`❌ ${orderedApis[0].name} gagal: ${error1.message}`);
            
            // Coba API kedua
            if (orderedApis[1]) {
                try {
                    console.log(`⏳ Mencoba ${orderedApis[1].name}...`);
                    const { buffer, responseTime } = await fetchMedia(orderedApis[1].url, TIMEOUT);
                    await recordPerformance(bratCache, BRAT_CACHE_FILE, orderedApis[1].name, responseTime);
                    console.log(`✅ Berhasil dari ${orderedApis[1].name}`);
                    return buffer;
                } catch (error2) {
                    console.log(`❌ ${orderedApis[1].name} gagal: ${error2.message}`);
                }
            }
        }
        
        // Jika semua gagal, lakukan retry dengan delay
        console.log(`🔄 Semua API gagal, memulai retry dengan delay ${RETRY_DELAY}ms...`);
        
        for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            console.log(`📡 Percobaan ke-${attempt}/${MAX_RETRIES}`);
            
            for (const api of orderedApis) {
                try {
                    console.log(`🔄 Mencoba ulang ${api.name}...`);
                    const { buffer, responseTime } = await fetchMedia(api.url, TIMEOUT);
                    await recordPerformance(bratCache, BRAT_CACHE_FILE, api.name, responseTime);
                    console.log(`✅ ${api.name} berhasil pada percobaan ke-${attempt}`);
                    return buffer;
                } catch (err) {
                    console.log(`❌ ${api.name} gagal: ${err.message}`);
                }
            }
            
            if (attempt < MAX_RETRIES) {
                console.log(`⏳ Menunggu ${RETRY_DELAY}ms sebelum retry berikutnya...`);
                await delay(RETRY_DELAY);
            }
        }
        
        throw new Error('Semua API gagal setelah percobaan maksimal');
        
    } catch (error) {
        console.error(`❌ Error fatal: ${error.message}`);
        throw error;
    }
}

/**
 * Generate sticker video BRAT dengan sistem prioritas API tercepat
 */
export async function generateBratVideoSticker(text) {
    if (!text?.trim()) throw new Error('Teks tidak boleh kosong');
    
    // Load cache
    await loadCache(BRAT_VIDEO_CACHE_FILE, bratVideoCache);
    
    const apis = [
        {
            url: `https://api-faa.my.id/faa/bratvid?text=${encodeURIComponent(text)}`,
            name: 'FAA API (Video)'
        },
        {
            url: `https://api.yupra.my.id/api/video/bratv?text=${encodeURIComponent(text)}`,
            name: 'Yupra API (Video)'
        }
    ];
    
    // Urutkan API berdasarkan performa
    const orderedApis = getApiOrder(apis, bratVideoCache);
    
    try {
        console.log(`🎬 Memulai generate BRAT video dengan prioritas tertinggi: ${orderedApis[0].name}`);
        
        // Coba API pertama (prioritas tertinggi)
        try {
            const { buffer, responseTime } = await fetchMedia(orderedApis[0].url, TIMEOUT);
            await recordPerformance(bratVideoCache, BRAT_VIDEO_CACHE_FILE, orderedApis[0].name, responseTime);
            console.log(`✅ Berhasil dari ${orderedApis[0].name}`);
            return buffer;
        } catch (error1) {
            console.log(`❌ ${orderedApis[0].name} gagal: ${error1.message}`);
            
            // Coba API kedua
            if (orderedApis[1]) {
                try {
                    console.log(`⏳ Mencoba ${orderedApis[1].name}...`);
                    const { buffer, responseTime } = await fetchMedia(orderedApis[1].url, TIMEOUT);
                    await recordPerformance(bratVideoCache, BRAT_VIDEO_CACHE_FILE, orderedApis[1].name, responseTime);
                    console.log(`✅ Berhasil dari ${orderedApis[1].name}`);
                    return buffer;
                } catch (error2) {
                    console.log(`❌ ${orderedApis[1].name} gagal: ${error2.message}`);
                }
            }
        }
        
        // Jika semua gagal, lakukan retry dengan delay
        console.log(`🔄 Semua API video gagal, memulai retry dengan delay ${RETRY_DELAY}ms...`);
        
        for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
            console.log(`📡 Percobaan video ke-${attempt}/${MAX_RETRIES}`);
            
            for (const api of orderedApis) {
                try {
                    console.log(`🔄 Mencoba ulang ${api.name}...`);
                    const { buffer, responseTime } = await fetchMedia(api.url, TIMEOUT);
                    await recordPerformance(bratVideoCache, BRAT_VIDEO_CACHE_FILE, api.name, responseTime);
                    console.log(`✅ ${api.name} video berhasil pada percobaan ke-${attempt}`);
                    return buffer;
                } catch (err) {
                    console.log(`❌ ${api.name} video gagal: ${err.message}`);
                }
            }
            
            if (attempt < MAX_RETRIES) {
                console.log(`⏳ Menunggu ${RETRY_DELAY}ms sebelum retry video berikutnya...`);
                await delay(RETRY_DELAY);
            }
        }
        
        throw new Error('Semua API video gagal setelah percobaan maksimal');
        
    } catch (error) {
        console.error(`❌ Error fatal video: ${error.message}`);
        throw error;
    }
}

// ==================== UTILITY FUNCTIONS ====================
export async function getBratPerformanceStats() {
    await loadCache(BRAT_CACHE_FILE, bratCache);
    await loadCache(BRAT_VIDEO_CACHE_FILE, bratVideoCache);
    
    return {
        sticker: {
            fastestApi: bratCache.fastestApi,
            lastUpdated: bratCache.lastUpdated,
            hitCount: { ...bratCache.hitCount },
            avgResponseTime: { ...bratCache.avgResponseTime },
            totalRequests: bratCache.totalRequests
        },
        video: {
            fastestApi: bratVideoCache.fastestApi,
            lastUpdated: bratVideoCache.lastUpdated,
            hitCount: { ...bratVideoCache.hitCount },
            avgResponseTime: { ...bratVideoCache.avgResponseTime },
            totalRequests: bratVideoCache.totalRequests
        }
    };
}

export async function resetBratPerformanceCache() {
    bratCache = {
        fastestApi: null,
        lastUpdated: null,
        hitCount: {},
        avgResponseTime: {},
        totalRequests: 0
    };
    bratVideoCache = {
        fastestApi: null,
        lastUpdated: null,
        hitCount: {},
        avgResponseTime: {},
        totalRequests: 0
    };
    await saveCache(BRAT_CACHE_FILE, bratCache);
    await saveCache(BRAT_VIDEO_CACHE_FILE, bratVideoCache);
    console.log('🔄 Semua cache performa BRAT telah direset');
}

export default {
    generateBratSticker,
    generateBratVideoSticker,
    getBratPerformanceStats,
    resetBratPerformanceCache
};