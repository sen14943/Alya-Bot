import axios from 'axios';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const MAX_RETRIES = 2;
const RETRY_DELAY = 2000;
const TIMEOUT = 30000;

async function fetchImage(url, maxRetries = MAX_RETRIES) {
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`🔄 BRATSQUID percobaan ke-${attempt}/${maxRetries}`);
            
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: TIMEOUT,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (response.status !== 200) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const buffer = Buffer.from(response.data);
            
            if (!buffer || buffer.length < 5000) {
                throw new Error('Buffer kosong atau terlalu kecil');
            }
            
            console.log(`✅ BRATSQUID berhasil (${buffer.length} bytes)`);
            return buffer;
            
        } catch (error) {
            lastError = error;
            console.log(`❌ Percobaan ke-${attempt} gagal: ${error.message}`);
            
            if (attempt < maxRetries) {
                await delay(RETRY_DELAY);
            }
        }
    }
    
    throw new Error(`Gagal: ${lastError?.message}`);
}

export async function generateSquidward(text) {
    if (!text?.trim()) {
        throw new Error('Teks tidak boleh kosong');
    }
    
    const url = `https://api.ourin.my.id/api/bratsquidward?text=${encodeURIComponent(text)}`;
    console.log(`🦑 Memanggil API Squidward dengan teks: "${text}"`);
    
    return await fetchImage(url);
}

export default {
    generateSquidward
};