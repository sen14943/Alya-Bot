import axios from 'axios';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;
const TIMEOUT = 60000;

async function fetchImage(url, maxRetries = MAX_RETRIES) {
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`🔄 FETCH percobaan ke-${attempt}/${maxRetries}`);
            
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: TIMEOUT,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (response.status !== 200) {
                throw new Error(`HTTP ${response.status}`);
            }
            
            const buffer = Buffer.from(response.data);
            
            if (!buffer || buffer.length < 5000) {
                throw new Error('Buffer kosong atau terlalu kecil');
            }
            
            console.log(`✅ FETCH berhasil (${buffer.length} bytes)`);
            return buffer;
            
        } catch (error) {
            lastError = error;
            console.log(`❌ Percobaan ke-${attempt} gagal: ${error.message}`);
            
            if (attempt < maxRetries) {
                await delay(RETRY_DELAY);
            }
        }
    }
    
    throw new Error(`Gagal: ${lastError?.message}`);
}

/**
 * Generate gambar FakeFF (single)
 * @param {string} name - Nama karakter
 * @returns {Promise<Buffer>}
 */
export async function generateFakeFF(name) {
    if (!name?.trim()) throw new Error('Nama tidak boleh kosong');
    
    // PRIORITAS 1: API ourin (single)
    const primaryUrl = `https://api.ourin.my.id/api/fake-free-fire-2?text=${encodeURIComponent(name)}&bg=random`;
    console.log(`📱 [SINGLE] Mencoba API utama: ${primaryUrl}`);
    
    try {
        return await fetchImage(primaryUrl);
    } catch (error) {
        console.log(`⚠️ [SINGLE] API utama error: ${error.message}`);
        console.log(`🔄 [SINGLE] Fallback ke API cadangan...`);
        
        // FALLBACK: API azbry
        const fallbackUrl = `https://api.azbry.com/api/maker/fakeff?name=${encodeURIComponent(name)}`;
        return await fetchImage(fallbackUrl);
    }
}

/**
 * Generate gambar FakeFF Duo (2 karakter)
 * @param {string} name1 - Nama karakter kiri
 * @param {string} name2 - Nama karakter kanan
 * @returns {Promise<Buffer>}
 */
export async function generateFakeFFDuo(name1, name2) {
    if (!name1?.trim() || !name2?.trim()) {
        throw new Error('Kedua nama tidak boleh kosong');
    }
    
    // API ourin untuk duo
    const url = `https://api.ourin.my.id/api/fake-ff-duo-2?name1=${encodeURIComponent(name1)}&name2=${encodeURIComponent(name2)}&bg=random`;
    console.log(`📱 [DUO] Memanggil API: ${url}`);
    
    return await fetchImage(url);
}

/**
 * Generate gambar FakeFF dengan auto-deteksi mode
 * @param {string} name1 - Nama pertama (wajib)
 * @param {string|null} name2 - Nama kedua (opsional, untuk mode duo)
 * @returns {Promise<Buffer>}
 */
export async function generateFakeFFAuto(name1, name2 = null) {
    if (name2 && name2.trim()) {
        return await generateFakeFFDuo(name1, name2);
    } else {
        return await generateFakeFF(name1);
    }
}

export default {
    generateFakeFF,
    generateFakeFFDuo,
    generateFakeFFAuto
};