import axios from 'axios';

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// ==================== CONFIG ====================
const MAX_RETRIES = 2;
const RETRY_DELAY = 2000;
const TIMEOUT = 30000;

/**
 * Fetch gambar dengan retry mechanism
 * @param {string} url - URL API
 * @param {number} maxRetries - Jumlah maksimal percobaan
 * @returns {Promise<Buffer>}
 */
async function fetchImage(url, maxRetries = MAX_RETRIES) {
    let lastError = null;
    
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            console.log(`🔄 CEWEKBRAT percobaan ke-${attempt}/${maxRetries}`);
            
            const response = await axios.get(url, {
                responseType: 'arraybuffer',
                timeout: TIMEOUT,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });
            
            if (response.status !== 200) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const buffer = Buffer.from(response.data);
            
            // Validasi buffer tidak kosong dan minimal 5KB
            if (!buffer || buffer.length < 5000) {
                throw new Error('Buffer kosong atau file terlalu kecil');
            }
            
            console.log(`✅ CEWEKBRAT berhasil (${buffer.length} bytes)`);
            return buffer;
            
        } catch (error) {
            lastError = error;
            console.log(`❌ Percobaan ke-${attempt} gagal: ${error.message}`);
            
            if (attempt < maxRetries) {
                console.log(`⏳ Menunggu ${RETRY_DELAY}ms sebelum retry...`);
                await delay(RETRY_DELAY);
            }
        }
    }
    
    throw new Error(`Gagal setelah ${maxRetries} percobaan: ${lastError?.message}`);
}

/**
 * Generate stiker BRAT versi cewek cantik
 * @param {string} text - Teks untuk stiker
 * @returns {Promise<Buffer>}
 */
export async function generateCewekBrat(text) {
    if (!text || text.trim() === '') {
        throw new Error('Teks tidak boleh kosong');
    }
    
    // URL API Cewek Brat
    const url = `https://api.deline.web.id/maker/cewekbrat?text=${encodeURIComponent(text)}`;
    console.log(`📱 Memanggil API CewekBrat dengan teks: "${text}"`);
    
    const buffer = await fetchImage(url);
    return buffer;
}

export default {
    generateCewekBrat
};