import axios from 'axios';
import { uploadBuffer } from '../uploader.js';

// ========== FUNGSI UTAMA ==========

/**
 * Membuat fake ML profile card menggunakan API
 * @param {string} name - Nama yang akan ditampilkan
 * @param {Buffer} avatarBuffer - Buffer gambar avatar
 * @returns {Promise<Buffer>} - Buffer gambar hasil
 */
export async function createFakeML(name, avatarBuffer) {
    try {
        // Upload avatar menggunakan uploader.js
        console.log('📤 Uploading avatar...');
        const avatarUrl = await uploadBuffer(avatarBuffer, 'avatar.jpg');
        
        if (!avatarUrl) {
            throw new Error('Gagal upload avatar');
        }
        
        console.log('✅ Avatar uploaded:', avatarUrl);
        
        // Panggil API fakeml
        const apiUrl = `https://api.nexray.web.id/maker/fakelobyml?avatar=${encodeURIComponent(avatarUrl)}&nickname=${encodeURIComponent(name)}`;
        
        console.log('🎨 Generating fake ML card...');
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer',
            timeout: 60000,
            headers: {
                'User-Agent': 'Mozilla/5.0'
            }
        });
        
        if (response.status === 200 && response.data) {
            console.log('✅ Fake ML card generated successfully');
            return Buffer.from(response.data);
        } else {
            throw new Error(`API response: ${response.status}`);
        }
        
    } catch (error) {
        console.error('[FAKEML] Error:', error.message);
        throw error;
    }
}

/**
 * Membuat fake ML profile dari URL avatar
 * @param {string} name - Nama player
 * @param {string} avatarUrl - URL avatar
 * @returns {Promise<Buffer>}
 */
export async function createFakeMLFromUrl(name, avatarUrl) {
    try {
        // Download avatar dari URL
        const response = await axios.get(avatarUrl, {
            responseType: 'arraybuffer',
            timeout: 30000
        });
        
        const avatarBuffer = Buffer.from(response.data);
        return createFakeML(name, avatarBuffer);
        
    } catch (error) {
        console.error('[FAKEML] Error from URL:', error.message);
        throw error;
    }
}

/**
 * Membuat fake ML profile dari WhatsApp profile picture
 * @param {Object} sock - Socket WhatsApp
 * @param {string} jid - JID pengirim
 * @param {string} name - Nama player
 * @returns {Promise<Buffer>}
 */
export async function createFakeMLFromWA(sock, jid, name) {
    try {
        let avatarBuffer;
        
        try {
            // Coba ambil foto profil WhatsApp
            const avatarUrl = await sock.profilePictureUrl(jid, 'image');
            const response = await axios.get(avatarUrl, {
                responseType: 'arraybuffer',
                timeout: 30000
            });
            avatarBuffer = Buffer.from(response.data);
            console.log('✅ Avatar dari WhatsApp berhasil diambil');
            
        } catch (error) {
            // Kalau gagal, pakai default avatar
            console.log('⚠️ Gagal ambil foto profil, pakai default');
            const defaultRes = await axios.get('https://i.imgur.com/8Km9tLL.png', {
                responseType: 'arraybuffer'
            });
            avatarBuffer = Buffer.from(defaultRes.data);
        }
        
        return createFakeML(name, avatarBuffer);
        
    } catch (error) {
        console.error('[FAKEML] Error from WA:', error.message);
        throw error;
    }
}

/**
 * Membuat fake ML profile dengan custom parameter
 * @param {Object} params - Parameter
 * @param {string} params.name - Nama player
 * @param {Buffer} params.avatar - Buffer avatar
 * @param {string} params.background - Background URL (opsional)
 * @returns {Promise<Buffer>}
 */
export async function createCustomFakeML({ name, avatar, background = null }) {
    try {
        const avatarUrl = await uploadBuffer(avatar, 'avatar.jpg');
        
        let apiUrl = `https://api.nexray.web.id/maker/fakelobyml?avatar=${encodeURIComponent(avatarUrl)}&nickname=${encodeURIComponent(name)}`;
        
        if (background) {
            apiUrl += `&background=${encodeURIComponent(background)}`;
        }
        
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer',
            timeout: 60000
        });
        
        if (response.status === 200 && response.data) {
            return Buffer.from(response.data);
        } else {
            throw new Error('Gagal generate gambar');
        }
        
    } catch (error) {
        console.error('[FAKEML] Error custom:', error);
        throw error;
    }
}

// Export semua fungsi
export default {
    createFakeML,
    createFakeMLFromUrl,
    createFakeMLFromWA,
    createCustomFakeML
};