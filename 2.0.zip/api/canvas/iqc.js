import axios from 'axios';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const MIN_FILE_SIZE = 20 * 1024; // 20KB dalam bytes
const API_TIMEOUT = 15000; // 15 detik timeout per API
const RETRY_DELAY = 3000; // 3 detik delay sebelum retry paralel

// Path file cache
const CACHE_FILE_PATH = path.join(__dirname, 'iqc.json');

// Cache struktur
let apiPerformanceCache = {
    fastestApi: null,
    lastUpdated: null,
    hitCount: {},
    avgResponseTime: {},
    totalRequests: 0
};

// Fungsi untuk load cache dari file
async function loadCacheFromFile() {
    try {
        const exists = await fs.access(CACHE_FILE_PATH).then(() => true).catch(() => false);
        
        if (exists) {
            const data = await fs.readFile(CACHE_FILE_PATH, 'utf-8');
            const loaded = JSON.parse(data);
            apiPerformanceCache = {
                fastestApi: loaded.fastestApi || null,
                lastUpdated: loaded.lastUpdated || null,
                hitCount: loaded.hitCount || {},
                avgResponseTime: loaded.avgResponseTime || {},
                totalRequests: loaded.totalRequests || 0
            };
            console.log('📂 Cache performa API berhasil dimuat dari file:', {
                fastestApi: apiPerformanceCache.fastestApi,
                totalRequests: apiPerformanceCache.totalRequests,
                stats: apiPerformanceCache.avgResponseTime
            });
        } else {
            console.log('📂 File cache tidak ditemukan, menggunakan cache baru');
            await saveCacheToFile();
        }
    } catch (error) {
        console.log('⚠️ Gagal load cache dari file:', error.message);
    }
}

// Fungsi untuk save cache ke file
async function saveCacheToFile() {
    try {
        await fs.writeFile(CACHE_FILE_PATH, JSON.stringify(apiPerformanceCache, null, 2), 'utf-8');
        console.log('💾 Cache performa API berhasil disimpan ke file');
    } catch (error) {
        console.log('⚠️ Gagal menyimpan cache ke file:', error.message);
    }
}

// Fungsi untuk mencatat performa API
async function recordApiPerformance(apiName, responseTime) {
    if (!apiPerformanceCache.hitCount[apiName]) {
        apiPerformanceCache.hitCount[apiName] = 0;
        apiPerformanceCache.avgResponseTime[apiName] = 0;
    }
    
    // Update hit count
    apiPerformanceCache.hitCount[apiName]++;
    apiPerformanceCache.totalRequests++;
    
    // Update average response time (moving average)
    const currentAvg = apiPerformanceCache.avgResponseTime[apiName];
    const newAvg = ((currentAvg * (apiPerformanceCache.hitCount[apiName] - 1)) + responseTime) / apiPerformanceCache.hitCount[apiName];
    apiPerformanceCache.avgResponseTime[apiName] = Math.round(newAvg);
    
    // Update fastest API berdasarkan response time tercepat
    let fastest = null;
    let fastestTime = Infinity;
    for (const [api, avgTime] of Object.entries(apiPerformanceCache.avgResponseTime)) {
        if (avgTime < fastestTime && apiPerformanceCache.hitCount[api] >= 1) {
            fastestTime = avgTime;
            fastest = api;
        }
    }
    
    if (fastest && fastest !== apiPerformanceCache.fastestApi) {
        apiPerformanceCache.fastestApi = fastest;
        apiPerformanceCache.lastUpdated = new Date().toISOString();
        console.log(`🏆 API tercepat baru: ${fastest} (avg: ${fastestTime}ms)`);
        await saveCacheToFile();
    }
    
    console.log(`📊 Performa API: ${apiName} -> ${responseTime}ms (avg: ${apiPerformanceCache.avgResponseTime[apiName]}ms, hits: ${apiPerformanceCache.hitCount[apiName]})`);
    
    // Save ke file setiap ada update (bisa dioptimalkan dengan debounce)
    await saveCacheToFile();
}

// Fungsi untuk mendapatkan urutan API berdasarkan performa
function getApiOrder(apis) {
    if (!apiPerformanceCache.fastestApi || apiPerformanceCache.totalRequests < 3) {
        // Jika belum cukup data, urutan default: FAA, Brat, AZBRY
        console.log(`📋 Menggunakan urutan default (belum cukup data: ${apiPerformanceCache.totalRequests} request)`);
        return apis;
    }
    
    // Urutkan berdasarkan response time tercepat
    const sorted = [...apis].sort((a, b) => {
        const timeA = apiPerformanceCache.avgResponseTime[a.name] || Infinity;
        const timeB = apiPerformanceCache.avgResponseTime[b.name] || Infinity;
        return timeA - timeB;
    });
    
    console.log(`📋 Urutan prioritas berdasarkan performa: ${sorted.map(a => `${a.name}(${apiPerformanceCache.avgResponseTime[a.name] || '?'}ms)`).join(' → ')}`);
    return sorted;
}

async function fetchImage(url, timeout = API_TIMEOUT) {
    const startTime = Date.now();
    
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer',
            timeout: timeout,
            headers: { 'User-Agent': 'Mozilla/5.0' }
        });
        
        if (response.status !== 200) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const buffer = Buffer.from(response.data);
        
        if (!buffer || buffer.length < 5000) {
            throw new Error('Buffer kosong atau terlalu kecil');
        }
        
        // CEK UKURAN FILE DI BAWAH 20KB
        if (buffer.length < MIN_FILE_SIZE) {
            throw new Error(`File terlalu kecil: ${buffer.length} bytes (< 20KB) - Gambar error/corrupt`);
        }
        
        const responseTime = Date.now() - startTime;
        console.log(`✅ Berhasil (${buffer.length} bytes) dalam ${responseTime}ms`);
        
        return { buffer, responseTime };
        
    } catch (error) {
        const responseTime = Date.now() - startTime;
        console.log(`❌ Gagal dalam ${responseTime}ms: ${error.message}`);
        throw error;
    }
}

async function tryApiWithDelay(url, apiName, delayMs = 5000) {
    console.log(`📱 Mencoba ${apiName}...`);
    if (delayMs > 0) await delay(delayMs);
    
    try {
        const { buffer, responseTime } = await fetchImage(url);
        await recordApiPerformance(apiName, responseTime);
        return { success: true, data: buffer, api: apiName, responseTime };
    } catch (error) {
        return { success: false, error: error.message, api: apiName };
    }
}

async function retryAllParallel(apis, timeout = 15000) {
    console.log(`🔄 Melakukan retry paralel ke ${apis.length} API dengan timeout ${timeout}ms...`);
    
    const promises = apis.map(async ({ url, name }) => {
        const startTime = Date.now();
        try {
            const { buffer, responseTime } = await fetchImage(url, timeout);
            await recordApiPerformance(name, responseTime);
            return { success: true, data: buffer, api: name, responseTime };
        } catch (error) {
            return { success: false, error: error.message, api: name };
        }
    });
    
    // Race condition - ambil yang tercepat berhasil
    const result = await Promise.race([
        Promise.all(promises).then(results => {
            const success = results.find(r => r.success);
            if (success) return success;
            throw new Error('Semua API gagal dalam retry paralel');
        }),
        delay(timeout + 1000).then(() => {
            throw new Error(`Timeout retry paralel setelah ${timeout + 1000}ms`);
        })
    ]);
    
    return result;
}

export async function createQuote(text) {
    if (!text || text.trim() === '') {
        throw new Error('Teks tidak boleh kosong');
    }
    
    // Pastikan cache sudah dimuat
    if (apiPerformanceCache.totalRequests === 0 && !apiPerformanceCache.lastUpdated) {
        await loadCacheFromFile();
    }
    
    // API definitions
    const apis = [
        { url: `https://api-faa.my.id/faa/iqc?prompt=${encodeURIComponent(text)}`, name: 'API FAA' },
        { url: `https://brat.siputzx.my.id/iphone-quoted?time=07:00&messageText=${encodeURIComponent(text)}`, name: 'API Brat' },
        { url: `https://api.azbry.com/api/maker/iqc?text=${encodeURIComponent(text)}`, name: 'API AZBRY' }
    ];
    
    // Urutkan API berdasarkan performa tercepat yang tercatat
    const orderedApis = getApiOrder(apis);
    
    try {
        // Tahap 1: Sequential dengan delay 5 detik antar API (prioritas API tercepat)
        console.log('🚀 Tahap 1: Sequential dengan delay 5 detik antar API');
        
        // Hit API pertama langsung tanpa delay
        const firstApi = orderedApis[0];
        const result1 = await tryApiWithDelay(firstApi.url, firstApi.name, 0);
        if (result1.success) {
            console.log(`✅ Berhasil dari ${result1.api} (waktu: ${result1.responseTime}ms)`);
            return result1.data;
        }
        
        // Hit API kedua dengan delay 5 detik
        if (orderedApis[1]) {
            const result2 = await tryApiWithDelay(orderedApis[1].url, orderedApis[1].name, 5000);
            if (result2.success) {
                console.log(`✅ Berhasil dari ${result2.api} (waktu: ${result2.responseTime}ms)`);
                return result2.data;
            }
        }
        
        // Hit API ketiga dengan delay 5 detik
        if (orderedApis[2]) {
            const result3 = await tryApiWithDelay(orderedApis[2].url, orderedApis[2].name, 5000);
            if (result3.success) {
                console.log(`✅ Berhasil dari ${result3.api} (waktu: ${result3.responseTime}ms)`);
                return result3.data;
            }
        }
        
        console.log(`❌ Tahap 1 gagal semua`);
        
        // Tahap 2: Retry paralel - hit semua API barengan
        console.log('🚀 Tahap 2: Retry paralel - hit semua API bersamaan');
        await delay(RETRY_DELAY); // Delay 3 detik sebelum retry paralel
        
        const parallelResult = await retryAllParallel(apis, API_TIMEOUT);
        
        if (parallelResult.success) {
            console.log(`✅ Berhasil dari ${parallelResult.api} pada retry paralel (waktu: ${parallelResult.responseTime}ms)`);
            return parallelResult.data;
        }
        
        throw new Error(`Semua API gagal setelah sequential dan retry paralel`);
        
    } catch (error) {
        throw new Error(`Gagal membuat quote: ${error.message}`);
    }
}

// Fungsi untuk melihat statistik performa API (debugging)
export async function getApiPerformanceStats() {
    await loadCacheFromFile();
    return {
        fastestApi: apiPerformanceCache.fastestApi,
        lastUpdated: apiPerformanceCache.lastUpdated,
        hitCount: { ...apiPerformanceCache.hitCount },
        avgResponseTime: { ...apiPerformanceCache.avgResponseTime },
        totalRequests: apiPerformanceCache.totalRequests,
        cachePath: CACHE_FILE_PATH
    };
}

// Fungsi untuk reset cache performa (jika diperlukan)
export async function resetPerformanceCache() {
    apiPerformanceCache = {
        fastestApi: null,
        lastUpdated: null,
        hitCount: {},
        avgResponseTime: {},
        totalRequests: 0
    };
    await saveCacheToFile();
    console.log('🔄 Cache performa API telah direset');
}

// Inisialisasi load cache saat module diimport
loadCacheFromFile().catch(console.error);

// Fungsi tambahan untuk cek ukuran file sebelum digunakan
export async function validateImageSize(buffer, minSize = MIN_FILE_SIZE) {
    if (!buffer || buffer.length < minSize) {
        throw new Error(`Invalid image size: ${buffer?.length || 0} bytes (minimum ${minSize} bytes)`);
    }
    return true;
}

export default {
    createQuote,
    validateImageSize,
    getApiPerformanceStats,
    resetPerformanceCache,
    MIN_FILE_SIZE
};