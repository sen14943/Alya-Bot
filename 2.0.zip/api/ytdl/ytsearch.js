// ytsearch.js - Tanpa sharp, tanpa crop (lebih cepat)
import yts from 'yt-search';
import axios from 'axios';

/**
 * Mencari video YouTube dan mengembalikan hasil teratas
 * @param {string} query - Kata kunci pencarian
 * @returns {Promise<Object>} - Detail video teratas
 */
export async function searchTopVideo(query) {
    if (!query || query.trim() === '') {
        throw new Error('Query pencarian tidak boleh kosong');
    }
    
    const search = await yts(query);
    const results = search.all;
    
    if (!results || results.length === 0) {
        throw new Error('Tidak ada hasil ditemukan');
    }
    
    // Ambil hasil teratas (index 0)
    const top = results[0];
    
    let thumbnailBuffer = null;
    
    // Coba ambil thumbnail sddefault (kualitas lebih bagus)
    try {
        const sdUrl = `https://img.youtube.com/vi/${top.videoId}/sddefault.jpg`;
        const response = await axios.get(sdUrl, {
            responseType: 'arraybuffer',
            timeout: 10000
        });
        thumbnailBuffer = Buffer.from(response.data);
        console.log(`✅ [sddefault] Thumbnail berhasil diambil`);
    } catch (err) {
        console.log(`⚠️ [sddefault] Gagal: ${err.message}`);
    }
    
    // Fallback ke thumbnail dari yt-search
    if (!thumbnailBuffer) {
        console.log(`🔄 [FALLBACK] Pakai thumbnail dari yt-search`);
        try {
            const response = await axios.get(top.thumbnail, {
                responseType: 'arraybuffer',
                timeout: 10000
            });
            thumbnailBuffer = Buffer.from(response.data);
        } catch (err) {
            console.log(`❌ Gagal ambil thumbnail: ${err.message}`);
            thumbnailBuffer = null;
        }
    }
    
    return {
        title: top.title,
        url: top.url,
        videoId: top.videoId,
        type: top.type,
        duration: top.timestamp,
        durationSeconds: top.durationSeconds,
        thumbnail: top.thumbnail,
        thumbnailBuffer: thumbnailBuffer,
        views: top.views,
        author: top.author,
        publishedAt: top.ago,
        description: top.description
    };
}

/**
 * Mendapatkan thumbnail dalam bentuk buffer
 * @param {string} query - Kata kunci pencarian
 * @returns {Promise<Buffer|null>} - Buffer thumbnail
 */
export async function getThumbnail(query) {
    const video = await searchTopVideo(query);
    return video.thumbnailBuffer;
}

/**
 * Mencari video dan mengembalikan URL saja (paling simpel)
 * @param {string} query - Kata kunci pencarian
 * @returns {Promise<string>} - URL video teratas
 */
export async function getTopVideoUrl(query) {
    const video = await searchTopVideo(query);
    return video.url;
}

/**
 * Mencari video dan mengembalikan beberapa hasil teratas
 * @param {string} query - Kata kunci pencarian
 * @param {number} limit - Jumlah hasil (default 5)
 * @returns {Promise<Array>} - Daftar video
 */
export async function searchMultiple(query, limit = 5) {
    if (!query || query.trim() === '') {
        throw new Error('Query pencarian tidak boleh kosong');
    }
    
    const search = await yts(query);
    const results = search.all;
    
    if (!results || results.length === 0) {
        throw new Error('Tidak ada hasil ditemukan');
    }
    
    // Proses thumbnail untuk semua hasil (parallel)
    const videos = results.slice(0, limit);
    const processedVideos = await Promise.all(
        videos.map(async (video) => {
            let thumbnailBuffer = null;
            
            // Coba sddefault dulu
            try {
                const sdUrl = `https://img.youtube.com/vi/${video.videoId}/sddefault.jpg`;
                const response = await axios.get(sdUrl, {
                    responseType: 'arraybuffer',
                    timeout: 10000
                });
                thumbnailBuffer = Buffer.from(response.data);
            } catch(e) {
                // Fallback ke thumbnail asli
                try {
                    const response = await axios.get(video.thumbnail, {
                        responseType: 'arraybuffer',
                        timeout: 10000
                    });
                    thumbnailBuffer = Buffer.from(response.data);
                } catch(err) {
                    console.log(`⚠️ Gagal ambil thumbnail untuk ${video.videoId}`);
                    thumbnailBuffer = null;
                }
            }
            
            return {
                title: video.title,
                url: video.url,
                videoId: video.videoId,
                type: video.type,
                duration: video.timestamp,
                thumbnail: video.thumbnail,
                thumbnailBuffer: thumbnailBuffer,
                views: video.views,
                author: video.author,
                publishedAt: video.ago
            };
        })
    );
    
    return processedVideos;
}

/**
 * Cek thumbnail dengan resolusi terbaik
 * @param {string} videoId - ID video YouTube
 * @returns {Promise<Object>} - URL thumbnail berbagai resolusi
 */
export function getThumbnailUrls(videoId) {
    return {
        default: `https://img.youtube.com/vi/${videoId}/default.jpg`,
        medium: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
        high: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        standard: `https://img.youtube.com/vi/${videoId}/sddefault.jpg`,
        maxres: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`
    };
}

export default {
    searchTopVideo,
    getTopVideoUrl,
    searchMultiple,
    getThumbnail,
    getThumbnailUrls
};