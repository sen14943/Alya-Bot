// ytdl.js
import axios from 'axios';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { Agent } from 'https';
import { createWriteStream } from 'fs';
import { pipeline } from 'stream/promises';
import ApiAutoresbotModule from 'api-autoresbot';
import { uploadBuffer } from '../uploader.js';

const ApiAutoresbot = ApiAutoresbotModule.default || ApiAutoresbotModule;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ========== KONFIGURASI ==========
const httpsAgent = new Agent({
    keepAlive: true,
    keepAliveMsecs: 1000,
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 60000
});

const axiosInstance = axios.create({
    httpsAgent,
    timeout: 60000,
    headers: { 
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Connection': 'keep-alive',
        'Accept-Encoding': 'gzip, deflate'
    }
});

// Load config
let config = null;
try {
    const configPath = path.join(__dirname, '../..', 'config.js');
    const configModule = await import(`file://${configPath}`);
    config = configModule.default;
} catch (error) {
    console.log('⚠️ Gagal load config:', error.message);
}

const ROOT_DIR = path.join(__dirname, '../..');
const TEMP_DIR = path.join(ROOT_DIR, 'storage', 'ytdl', 'temp');
const CACHE_METADATA_FILE = path.join(ROOT_DIR, 'storage', 'ytdl', 'external_cache.json');
const BASE_URL = 'https://api-faa.my.id/faa';
const NEXRAY_API = 'https://api.nexray.web.id/downloader';

// Buat folder
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });

// ========== METADATA CACHE EXTERNAL ==========
let metadataCache = null;
let cacheTimestamp = 0;
const METADATA_TTL = 5000;

function loadMetadata() {
    const now = Date.now();
    if (metadataCache && (now - cacheTimestamp) < METADATA_TTL) {
        return metadataCache;
    }
    
    if (fs.existsSync(CACHE_METADATA_FILE)) {
        try {
            const data = fs.readFileSync(CACHE_METADATA_FILE, 'utf8');
            metadataCache = JSON.parse(data);
        } catch (e) {
            metadataCache = {};
        }
    } else {
        metadataCache = {};
    }
    
    cacheTimestamp = now;
    return metadataCache;
}

function saveMetadata(metadata) {
    metadataCache = metadata;
    cacheTimestamp = Date.now();
    try {
        const dir = path.dirname(CACHE_METADATA_FILE);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(CACHE_METADATA_FILE, JSON.stringify(metadata, null, 2));
    } catch (e) {
        console.log('⚠️ Gagal simpan metadata:', e.message);
    }
}

// ========== FUNGSI BANTUAN ==========
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

const TIMEOUTS = {
    nexray: 60000,
    fa: 60000,
    autoresbot: 60000
};

async function retryWithBackoff(fn, maxRetries = 2, baseDelay = 500) {
    for (let i = 0; i < maxRetries; i++) {
        try {
            return await fn();
        } catch (error) {
            if (i === maxRetries - 1) throw error;
            await delay(baseDelay * Math.pow(2, i));
        }
    }
}

function extractVideoId(url) {
    const patterns = [
        /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/
    ];
    for (const pattern of patterns) {
        const match = url.match(pattern);
        if (match) return match[1];
    }
    return null;
}

// ========== AMBIL INFO VIDEO (DENGAN CACHE) ==========
const videoInfoCache = new Map();

async function getVideoInfo(videoId) {
    if (videoInfoCache.has(videoId)) {
        const cached = videoInfoCache.get(videoId);
        if (Date.now() - cached.timestamp < 3600000) {
            return cached.data;
        }
    }
    
    try {
        const url = `https://www.youtube.com/watch?v=${videoId}`;
        
        // Coba dari Nexray
        const nexrayInfo = await fetchFromNexray(url, 'mp3', 10000);
        const result = {
            title: nexrayInfo.title,
            thumbnail: nexrayInfo.thumbnail,
            duration: nexrayInfo.duration
        };
        
        videoInfoCache.set(videoId, { data: result, timestamp: Date.now() });
        return result;
    } catch (e) {
        // Fallback ke FA
        try {
            const apiUrl = `${BASE_URL}/ytmp3?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}`;
            const response = await axiosInstance.get(apiUrl, { timeout: 10000 });
            if (response.data?.status && response.data?.result) {
                const result = {
                    title: response.data.result.title,
                    thumbnail: response.data.result.thumbnail,
                    duration: response.data.result.duration
                };
                videoInfoCache.set(videoId, { data: result, timestamp: Date.now() });
                return result;
            }
        } catch (error) {}
        return null;
    }
}

// ========== API FETCHERS ==========
async function fetchFromNexray(url, type, resolution = '360', timeout = TIMEOUTS.nexray) {
    const endpoint = type === 'mp3' ? 'ytmp3' : 'ytmp4';
    let apiUrl = `${NEXRAY_API}/${endpoint}?url=${encodeURIComponent(url)}`;
    if (type === 'mp4' && resolution) apiUrl += `&resolusi=${resolution}`;
    
    const response = await axiosInstance.get(apiUrl, { timeout });
    
    if (type === 'mp3') {
        if (response.data?.result?.url) {
            return {
                url: response.data.result.url,
                title: response.data.result.title,
                thumbnail: response.data.result.thumbnail,
                duration: response.data.result.duration
            };
        }
    } else {
        if (response.data?.result?.url || response.data?.result?.download_url) {
            return {
                url: response.data.result.url || response.data.result.download_url,
                title: response.data.result.title,
                thumbnail: response.data.result.thumbnail,
                duration: response.data.result.duration
            };
        }
    }
    throw new Error('Nexray response invalid');
}

async function fetchFromFA(url, type, timeout = TIMEOUTS.fa) {
    const endpoint = type === 'mp3' ? 'ytmp3' : 'ytmp4';
    const apiUrl = `${BASE_URL}/${endpoint}?url=${encodeURIComponent(url)}`;
    const response = await axiosInstance.get(apiUrl, { timeout });
    
    if (type === 'mp3') {
        if (response.data?.status && response.data?.result?.mp3) {
            return {
                url: response.data.result.mp3,
                title: response.data.result.title,
                thumbnail: response.data.result.thumbnail,
                duration: response.data.result.duration
            };
        }
    } else {
        if (response.data?.status && response.data?.result?.download_url) {
            return {
                url: response.data.result.download_url,
                title: response.data.result.title,
                thumbnail: response.data.result.thumbnail,
                duration: response.data.result.duration
            };
        }
    }
    throw new Error('FA response invalid');
}

async function fetchFromAutoresbot(url, type, timeout = TIMEOUTS.autoresbot) {
    if (!config || !config.APIKEY) throw new Error('APIKEY tidak tersedia');
    
    const api = new ApiAutoresbot(config.APIKEY);
    const endpoint = type === 'mp3' ? '/api/downloader/ytplay' : '/api/downloader/ytmp4';
    const params = type === 'mp3' ? { url: url, format: 'm4a' } : { url: url };
    
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error(`Autoresbot timeout`)), timeout);
    });
    
    const requestPromise = api.get(endpoint, params);
    const response = await Promise.race([requestPromise, timeoutPromise]);
    
    if (response && response.status && response.data.url) {
        return { url: response.data.url };
    }
    throw new Error('Autoresbot response invalid');
}

// ========== DOWNLOAD FILE KE TEMPORARY ==========
async function downloadFileToTemp(url, videoId) {
    const tempPath = path.join(TEMP_DIR, `${videoId}_${Date.now()}.tmp`);
    
    try {
        const response = await axiosInstance({
            method: 'GET',
            url: url,
            responseType: 'stream',
            timeout: 60000
        });
        
        const writer = createWriteStream(tempPath);
        await pipeline(response.data, writer);
        
        const buffer = fs.readFileSync(tempPath);
        if (buffer.length < 100 * 1024) {
            throw new Error(`File terlalu kecil: ${(buffer.length / 1024).toFixed(2)}KB`);
        }
        
        return { buffer, tempPath };
    } catch (error) {
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        throw error;
    }
}

// ========== CACHE KE EXTERNAL STORAGE ==========
async function saveToExternalCache(videoId, buffer, title, thumbnail) {
    console.log(`📤 Menyimpan ke external cache: ${videoId}`);
    const filename = `${videoId}.mp3`;
    const externalUrl = await uploadBuffer(buffer, filename);
    
    const metadata = loadMetadata();
    metadata[videoId] = {
        id: videoId,
        title: title,
        externalUrl: externalUrl,
        thumbnail: thumbnail,
        fileSize: buffer.length,
        cachedAt: Date.now(),
        lastAccessed: Date.now()
    };
    saveMetadata(metadata);
    
    console.log(`✅ Tersimpan di external: ${externalUrl}`);
    return externalUrl;
}

async function getFromExternalCache(videoId) {
    const metadata = loadMetadata();
    const cached = metadata[videoId];
    
    if (!cached || !cached.externalUrl) {
        console.log(`📦 External cache MISS: ${videoId}`);
        return null;
    }
    
    console.log(`📦 External cache HIT: ${videoId}`);
    
    try {
        // Validasi: coba download dulu dari external URL
        const response = await axiosInstance.get(cached.externalUrl, {
            responseType: 'arraybuffer',
            timeout: 30000,
            validateStatus: status => status === 200
        });
        
        if (response.data && response.data.length > 0) {
            // Update lastAccessed
            cached.lastAccessed = Date.now();
            saveMetadata(metadata);
            
            return {
                buffer: Buffer.from(response.data),
                fromCache: true,
                title: cached.title,
                thumbnail: cached.thumbnail,
                externalUrl: cached.externalUrl
            };
        }
        throw new Error('File tidak valid');
        
    } catch (error) {
        console.log(`⚠️ External cache INVALID: ${videoId} - ${error.message}`);
        // Hapus dari metadata karena file sudah gak valid
        delete metadata[videoId];
        saveMetadata(metadata);
        return null;
    }
}

// ========== DELETE DARI EXTERNAL CACHE ==========
export function deleteFromExternalCache(videoId) {
    const metadata = loadMetadata();
    if (metadata[videoId]) {
        delete metadata[videoId];
        saveMetadata(metadata);
        console.log(`🗑️ Dihapus dari external cache: ${videoId}`);
        return true;
    }
    return false;
}

// ========== CLEANUP TEMP FILES ==========
function cleanTempFiles() {
    if (!fs.existsSync(TEMP_DIR)) return;
    const files = fs.readdirSync(TEMP_DIR);
    const now = Date.now();
    let deleted = 0;
    
    for (const file of files) {
        const filePath = path.join(TEMP_DIR, file);
        const stats = fs.statSync(filePath);
        if (now - stats.mtimeMs > 3600000) {
            fs.unlinkSync(filePath);
            deleted++;
        }
    }
    if (deleted > 0) console.log(`🗑️ Hapus ${deleted} file temp`);
}

// Cleanup tiap 2 jam
setInterval(cleanTempFiles, 2 * 60 * 60 * 1000);
setTimeout(cleanTempFiles, 60000);

// ========== MAIN FUNCTIONS ==========
export async function ytmp3(input, retries = 2) {
    return retryWithBackoff(async () => {
        let videoId = input;
        let url = input;
        
        if (input.includes('youtube.com') || input.includes('youtu.be')) {
            videoId = extractVideoId(input);
            url = input;
        } else {
            url = `https://www.youtube.com/watch?v=${videoId}`;
        }
        
        if (!videoId) throw new Error('Invalid YouTube URL or ID');
        
        // 1. Cek external cache dulu
        const cached = await getFromExternalCache(videoId);
        if (cached) {
            return {
                buffer: cached.buffer,
                title: cached.title,
                thumbnail: cached.thumbnail,
                videoId: videoId,
                fromCache: true,
                usedApi: null
            };
        }
        
        // 2. Dapetin info video
        const info = await getVideoInfo(videoId);
        const title = info?.title || videoId;
        const thumbnail = info?.thumbnail || null;
        
        // 3. Download via API (prioritas Nexray -> FA -> Autoresbot)
        const apis = [
            { name: 'Nexray', func: () => fetchFromNexray(url, 'mp3') },
            { name: 'FA', func: () => fetchFromFA(url, 'mp3') },
            { name: 'Autoresbot', func: () => fetchFromAutoresbot(url, 'mp3') }
        ];
        
        let downloadUrl = null;
        let usedApi = null;
        let lastError = null;
        
        for (const api of apis) {
            try {
                console.log(`🌐 Download via ${api.name}: ${videoId}`);
                const result = await api.func();
                downloadUrl = result.url;
                usedApi = api.name;
                break;
            } catch (error) {
                lastError = error;
                console.log(`⚠️ ${api.name} gagal: ${error.message}`);
            }
        }
        
        if (!downloadUrl) throw new Error(`Semua API gagal: ${lastError?.message}`);
        
        // 4. Download ke temp
        const { buffer, tempPath } = await downloadFileToTemp(downloadUrl, videoId);
        
        // 5. Simpan ke external cache
        try {
            await saveToExternalCache(videoId, buffer, title, thumbnail);
        } catch (cacheError) {
            console.log(`⚠️ Gagal simpan ke external cache: ${cacheError.message}`);
        }
        
        // 6. Hapus temp file
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        
        return {
            buffer: buffer,
            title: title,
            thumbnail: thumbnail,
            videoId: videoId,
            fromCache: false,
            usedApi: usedApi
        };
        
    }, retries);
}

export async function ytmp4(input, resolution = '360', retries = 2) {
    return retryWithBackoff(async () => {
        let videoId = input;
        let url = input;
        
        if (input.includes('youtube.com') || input.includes('youtu.be')) {
            videoId = extractVideoId(input);
            url = input;
        } else {
            url = `https://www.youtube.com/watch?v=${videoId}`;
        }
        
        if (!videoId) throw new Error('Invalid YouTube URL or ID');
        
        const apis = [
            { name: 'Nexray', func: () => fetchFromNexray(url, 'mp4', resolution) },
            { name: 'FA', func: () => fetchFromFA(url, 'mp4') },
            { name: 'Autoresbot', func: () => fetchFromAutoresbot(url, 'mp4') }
        ];
        
        let downloadUrl = null;
        let usedApi = null;
        let title = null;
        let thumbnail = null;
        let lastError = null;
        
        for (const api of apis) {
            try {
                console.log(`🌐 Download MP4 via ${api.name}: ${videoId} (${resolution}p)`);
                const result = await api.func();
                downloadUrl = result.url;
                title = result.title;
                thumbnail = result.thumbnail;
                usedApi = api.name;
                break;
            } catch (error) {
                lastError = error;
                console.log(`⚠️ ${api.name} gagal: ${error.message}`);
            }
        }
        
        if (!downloadUrl) throw new Error(`Semua API gagal: ${lastError?.message}`);
        
        const { buffer, tempPath } = await downloadFileToTemp(downloadUrl, videoId);
        if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
        
        if (buffer.length < 50 * 1024) {
            throw new Error(`File terlalu kecil: ${(buffer.length / 1024).toFixed(2)}KB`);
        }
        
        return {
            buffer,
            title,
            thumbnail,
            videoId,
            usedApi,
            resolution
        };
        
    }, retries);
}

// ========== SEARCH FUNCTIONS (DIPERBAIKI) ==========
// Title dan thumbnail DIPAKSA menggunakan hasil dari searchTopVideo
// BUKAN dari API download yang sering error / return videoId

export async function ytmp3ByQuery(query, retries = 2) {
    const { searchTopVideo } = await import('./ytsearch.js');
    const video = await searchTopVideo(query);
    const result = await ytmp3(video.videoId, retries);
    
    // 🔥 PERBAIKAN: Override title dan thumbnail dari hasil search
    // Karena API download sering return title yang salah atau cuma videoId
    result.title = video.title;
    result.thumbnail = video.thumbnail;
    
    return result;
}

export async function ytmp4ByQuery(query, resolution = '360', retries = 2) {
    const { searchTopVideo } = await import('./ytsearch.js');
    const video = await searchTopVideo(query);
    const result = await ytmp4(video.videoId, resolution, retries);
    
    // 🔥 PERBAIKAN: Override title dan thumbnail dari hasil search
    result.title = video.title;
    result.thumbnail = video.thumbnail;
    
    return result;
}

// Utility exports
export { deleteFromExternalCache as deleteCache, getFromExternalCache, saveToExternalCache };
export function getCacheMetadata() { return loadMetadata(); }
export function getCacheSize() { 
    const metadata = loadMetadata();
    return Object.keys(metadata).length;
}

export default {
    ytmp3,
    ytmp4,
    ytmp3ByQuery,
    ytmp4ByQuery,
    deleteCache: deleteFromExternalCache,
    getCacheMetadata,
    getCacheSize,
    extractVideoId
};