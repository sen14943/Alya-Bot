// src/scrape/pin.js

const API_FAA = "https://api-faa.my.id/faa/pinterest";
const API_AZBRY = "https://api.azbry.com/api/search/pinterest";

async function fetchFromFaa(query) {
    const res = await fetch(`${API_FAA}?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    
    if (!data.status || !data.result) {
        throw new Error("Faa API error");
    }
    
    return data.result;
}

async function fetchFromAzbry(query) {
    const res = await fetch(`${API_AZBRY}?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    
    if (!data.status || !data.result) {
        throw new Error("Azbry API error");
    }
    
    // Format Azbry result ke format yang sama dengan Faa
    return data.result.map(item => ({
        image: item.image,
        title: item.title,
        source: item.source,
        username: item.username,
        board: item.board,
        id: item.id
    }));
}

export async function searchPinterest(query, limit = 10) {
    if (!query) throw new Error("Query kosong");

    try {
        // Coba pake Faa dulu
        const results = await fetchFromFaa(query);
        return limit ? results.slice(0, limit) : results;
    } catch (error) {
        console.warn("Faa API error, using Azbry fallback:", error.message);
        // Fallback ke Azbry
        const results = await fetchFromAzbry(query);
        return limit ? results.slice(0, limit) : results;
    }
}

export async function searchPinterestFull(query, limit = null) {
    if (!query) throw new Error("Query kosong");

    try {
        // Coba pake Faa dulu
        const results = await fetchFromFaa(query);
        const finalResults = limit ? results.slice(0, limit) : results;
        
        return {
            status: true,
            total: results.length,
            images: finalResults
        };
    } catch (error) {
        console.warn("Faa API error, using Azbry fallback:", error.message);
        // Fallback ke Azbry
        const results = await fetchFromAzbry(query);
        const finalResults = limit ? results.slice(0, limit) : results;
        
        return {
            status: true,
            total: results.length,
            images: finalResults
        };
    }
}

export default { searchPinterest, searchPinterestFull };