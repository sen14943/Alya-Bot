// src/play.js

const API_URL = "https://api.azbry.com/api/download/spoplay";

export async function searchSpotify(query) {
    if (!query) throw new Error("Query kosong");

    const res = await fetch(`${API_URL}?q=${encodeURIComponent(query)}`);
    const data = await res.json();
    
    if (!data.status || !data.result) {
        throw new Error("Gagal ambil data dari Spotify API");
    }
    
    const { result } = data;
    
    return {
        status: true,
        title: result.title,           // ✅ Title diexport
        artist: result.artist,
        album: result.album,
        duration: result.duration,
        thumbnail: result.cover,       // Gambar cover sebagai thumbnail
        audio: result.rawLink,         // Audio dari rawLink
        deezerUrl: result.deezerUrl,
        downloadLink: result.downloadLink
    };
}

export async function getAudioStream(query) {
    const data = await searchSpotify(query);
    
    return {
        title: data.title,              // ✅ Title diexport
        artist: data.artist,
        thumbnail: data.thumbnail,
        streamUrl: data.audio
    };
}

// Untuk download langsung
export async function getDownloadUrl(query) {
    const data = await searchSpotify(query);
    
    return {
        title: `${data.artist} - ${data.title}`,  // ✅ Title diexport
        downloadUrl: data.downloadLink,
        audioUrl: data.audio
    };
}

export default { searchSpotify, getAudioStream, getDownloadUrl };