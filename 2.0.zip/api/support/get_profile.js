// lib/get_profile.js
import axios from 'axios';

/**
 * Ambil foto profil user dalam bentuk base64 & buffer
 * @param {object} sock - Socket connection
 * @param {string} jid - User JID
 * @returns {Promise<{success: boolean, base64: string, buffer: Buffer|null, mime: string, dataUrl: string|null, error: string|null}>}
 */
export async function getProfilePictureAsBase64(sock, jid) {
  try {
    const ppUrl = await sock.profilePictureUrl(jid, 'image');
    const response = await axios.get(ppUrl, {
      responseType: 'arraybuffer',
      timeout: 10000
    });
    
    const buffer = Buffer.from(response.data);
    const base64 = buffer.toString('base64');
    const mimeType = response.headers['content-type'] || 'image/jpeg';
    
    return {
      success: true,
      base64: base64,
      buffer: buffer,
      mime: mimeType,
      dataUrl: `data:${mimeType};base64,${base64}`,
      error: null
    };
    
  } catch (error) {
    console.log('[GET_PROFILE] Gagal ambil foto profil:', error.message);
    
    return {
      success: false,
      base64: null,
      buffer: null,
      mime: 'image/jpeg',
      dataUrl: null,
      error: error.message
    };
  }
}

export async function getProfileBase64(sock, jid) {
  const result = await getProfilePictureAsBase64(sock, jid);
  return result.success ? result.base64 : null;
}

export async function getProfileBuffer(sock, jid) {
  const result = await getProfilePictureAsBase64(sock, jid);
  return result.success ? result.buffer : null;
}

export async function getProfileDataUrl(sock, jid) {
  const result = await getProfilePictureAsBase64(sock, jid);
  return result.success ? result.dataUrl : null;
}

export async function hasProfilePicture(sock, jid) {
  const result = await getProfilePictureAsBase64(sock, jid);
  return result.success;
}