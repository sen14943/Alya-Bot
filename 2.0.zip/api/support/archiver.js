// lib/archiver.js

import fs from 'fs';
import path from 'path';
import archiver from 'archiver';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Membuat file zip dari satu atau lebih file/folder
 * @param {Array<string>} sources - Array path file/folder yang akan di-zip
 * @param {string} outputPath - Path output file zip (opsional, default: temporary)
 * @param {string} zipName - Nama file zip (opsional)
 * @returns {Promise<Object>} - { path, size, filename }
 */
async function createZip(sources, outputPath = null, zipName = null) {
    return new Promise((resolve, reject) => {
        // Validasi input
        if (!sources || sources.length === 0) {
            reject(new Error('Minimal 1 file/folder harus di-zip'));
            return;
        }

        // Tentukan nama file zip
        const finalZipName = zipName || `archive_${Date.now()}.zip`;
        
        // Tentukan path output
        const finalOutputPath = outputPath || path.join(process.cwd(), 'temp', finalZipName);
        
        // Pastikan folder output ada
        const outputDir = path.dirname(finalOutputPath);
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        // Buat stream output
        const output = fs.createWriteStream(finalOutputPath);
        const archive = archiver('zip', {
            zlib: { level: 9 } // Kompresi maksimal
        });

        // Event listener untuk error
        output.on('error', (err) => reject(err));
        archive.on('error', (err) => reject(err));
        
        // Event listener selesai
        output.on('close', () => {
            const stats = fs.statSync(finalOutputPath);
            resolve({
                path: finalOutputPath,
                size: stats.size,
                filename: finalZipName,
                bytes: stats.size,
                kb: (stats.size / 1024).toFixed(2),
                mb: (stats.size / (1024 * 1024)).toFixed(2)
            });
        });

        // Pipe archive ke output
        archive.pipe(output);

        // Proses setiap source
        for (const source of sources) {
            if (!fs.existsSync(source)) {
                reject(new Error(`File/folder tidak ditemukan: ${source}`));
                return;
            }

            const stats = fs.statSync(source);
            const basename = path.basename(source);

            if (stats.isDirectory()) {
                // Jika folder, tambahkan seluruh isi folder
                archive.directory(source, basename);
            } else {
                // Jika file, tambahkan file
                archive.file(source, { name: basename });
            }
        }

        // Finalisasi archive
        archive.finalize();
    });
}

/**
 * Membuat zip dari array file/folder (alias dari createZip)
 * @param {Array<string>} sources - Array path file/folder
 * @param {string} outputPath - Path output
 * @returns {Promise<Object>}
 */
async function toZip(sources, outputPath = null) {
    return createZip(sources, outputPath);
}

/**
 * Membuat zip dari satu file
 * @param {string} filePath - Path file
 * @param {string} outputPath - Path output (opsional)
 * @returns {Promise<Object>}
 */
async function zipFile(filePath, outputPath = null) {
    if (!fs.existsSync(filePath)) {
        throw new Error(`File tidak ditemukan: ${filePath}`);
    }
    return createZip([filePath], outputPath);
}

/**
 * Membuat zip dari satu folder
 * @param {string} folderPath - Path folder
 * @param {string} outputPath - Path output (opsional)
 * @returns {Promise<Object>}
 */
async function zipFolder(folderPath, outputPath = null) {
    if (!fs.existsSync(folderPath)) {
        throw new Error(`Folder tidak ditemukan: ${folderPath}`);
    }
    const stats = fs.statSync(folderPath);
    if (!stats.isDirectory()) {
        throw new Error(`Path bukan folder: ${folderPath}`);
    }
    return createZip([folderPath], outputPath);
}

/**
 * Membuat zip dari multiple file dengan custom nama di dalam zip
 * @param {Array<Object>} files - Array { source: path, name: nama_di_zip }
 * @param {string} outputPath - Path output (opsional)
 * @returns {Promise<Object>}
 */
async function createCustomZip(files, outputPath = null) {
    return new Promise((resolve, reject) => {
        if (!files || files.length === 0) {
            reject(new Error('Minimal 1 file harus di-zip'));
            return;
        }

        const zipName = `archive_${Date.now()}.zip`;
        const finalOutputPath = outputPath || path.join(process.cwd(), 'temp', zipName);
        
        const outputDir = path.dirname(finalOutputPath);
        if (!fs.existsSync(outputDir)) {
            fs.mkdirSync(outputDir, { recursive: true });
        }

        const output = fs.createWriteStream(finalOutputPath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('error', (err) => reject(err));
        archive.on('error', (err) => reject(err));
        output.on('close', () => {
            const stats = fs.statSync(finalOutputPath);
            resolve({
                path: finalOutputPath,
                size: stats.size,
                filename: zipName,
                bytes: stats.size,
                kb: (stats.size / 1024).toFixed(2),
                mb: (stats.size / (1024 * 1024)).toFixed(2)
            });
        });

        archive.pipe(output);

        for (const file of files) {
            if (!fs.existsSync(file.source)) {
                reject(new Error(`File tidak ditemukan: ${file.source}`));
                return;
            }
            archive.file(file.source, { name: file.name || path.basename(file.source) });
        }

        archive.finalize();
    });
}

export default {
    createZip,
    toZip,
    zipFile,
    zipFolder,
    createCustomZip
};

export {
    createZip,
    toZip,
    zipFile,
    zipFolder,
    createCustomZip
};