// hd.js
import axios from 'axios';

const BASE_URL = 'https://api-faa.my.id/faa/hdv3';

/**
 * Meningkatkan kualitas gambar (HD)
 * @param {string} imageUrl - URL gambar yang akan ditingkatkan kualitasnya
 * @returns {Promise<Buffer>} - Buffer gambar hasil HD
 */
export async function enhanceImage(imageUrl) {
    try {
        if (!imageUrl || imageUrl.trim() === '') {
            throw new Error('URL gambar tidak boleh kosong');
        }

        console.log(`🖼️ Memproses gambar: ${imageUrl}`);

        const apiUrl = `${BASE_URL}?image=${encodeURIComponent(imageUrl)}`;
        
        const response = await axios.get(apiUrl, {
            responseType: 'arraybuffer',
            timeout: 90000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        });

        if (response.status === 200 && response.data) {
            console.log('✅ Gambar berhasil ditingkatkan kualitasnya');
            return Buffer.from(response.data);
        }
        
        throw new Error(`Gagal memproses gambar: HTTP ${response.status}`);

    } catch (error) {
        console.error('Error enhanceImage:', error.message);
        throw new Error(`Gagal meningkatkan kualitas gambar: ${error.message}`);
    }
}

/**
 * Meningkatkan kualitas gambar dan mengembalikan sebagai base64
 * @param {string} imageUrl - URL gambar
 * @returns {Promise<string>} - Base64 string gambar
 */
export async function enhanceImageToBase64(imageUrl) {
    const buffer = await enhanceImage(imageUrl);
    return buffer.toString('base64');
}

/**
 * Meningkatkan kualitas gambar dan simpan ke file
 * @param {string} imageUrl - URL gambar
 * @param {string} outputPath - Path untuk menyimpan file (opsional)
 * @returns {Promise<string>} - Path file yang disimpan
 */
export async function enhanceImageAndSave(imageUrl, outputPath = null) {
    const buffer = await enhanceImage(imageUrl);
    
    if (!outputPath) {
        const fs = await import('fs');
        const path = await import('path');
        const timestamp = Date.now();
        outputPath = path.join(process.cwd(), 'temp', `hd_${timestamp}.jpg`);
        
        // Pastikan folder temp ada
        const tempDir = path.join(process.cwd(), 'temp');
        if (!fs.existsSync(tempDir)) {
            fs.mkdirSync(tempDir, { recursive: true });
        }
    }
    
    const fs = await import('fs');
    fs.writeFileSync(outputPath, buffer);
    console.log(`💾 Gambar HD disimpan: ${outputPath}`);
    
    return outputPath;
}

export default {
    enhanceImage,
    enhanceImageToBase64,
    enhanceImageAndSave
};